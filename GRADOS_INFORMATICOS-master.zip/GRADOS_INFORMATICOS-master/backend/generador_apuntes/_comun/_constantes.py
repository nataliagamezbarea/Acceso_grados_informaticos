import os

from backend.configuracion import (
    DIRECTORIO_BASE, DIRECTORIO_DATOS, DIRECTORIO_GI, CONFIGURACION_GRADOS,
    DIRECTORIO_PLANTILLAS, DIRECTORIO_NUEVOS_APUNTES
)

RUTA_CSV_REGISTRO = os.path.join(DIRECTORIO_DATOS, "registro_archivos.csv")
PLANTILLA_LATEX_MAESTRA = os.path.join(DIRECTORIO_PLANTILLAS, "plantilla_apunte.tex")
DIRECTORIO_BIBLIOTECAS_LATEX = os.path.join(DIRECTORIO_BASE, "almacen", "bibliotecas_latex")
DIRECTORIO_LATEX_BASE = os.path.join(DIRECTORIO_BIBLIOTECAS_LATEX, "") if os.path.isdir(DIRECTORIO_BIBLIOTECAS_LATEX) else os.path.join(DIRECTORIO_BASE, "latex")
RUTA_ESTILO_LATEX = os.path.join(DIRECTORIO_LATEX_BASE, "estilo.tex")
DIRECTORIO_PAQUETES_LATEX = os.path.join(DIRECTORIO_BIBLIOTECAS_LATEX, "paquetes")

PAQUETES_LATEX_REQUERIDOS = {
    "fontspec": "fontspec",
    "geometry": "geometry",
    "xcolor": "xcolor",
    "colortbl": "colortbl",
    "booktabs": "booktabs",
    "array": "tools",
    "tikz": "pgf",
    "tikzfill": "tikzfill",
    "tcolorbox": "tcolorbox",
    "enumitem": "enumitem",
    "ragged2e": "ragged2e",
    "parskip": "parskip",
    "eso-pic": "eso-pic",
    "graphicx": "graphics",
}

_paquetes_verificados = False

# Las subcarpetas de NUEVOS_APUNTES por grado SE CREAN SOLO EN GitHub (repo
# utilidades-grado, rama master), no en el disco local: en serverless de solo
# lectura (Vercel) os.makedirs fallaría. Se hace de forma tolerante a errores
# para que un fallo de red/configuración nunca rompa la importación.
try:
    from backend.gestor_datos.github_sync import asegurar_carpeta_en_github, REPO_UTILIDADES_GRADO
    for g in CONFIGURACION_GRADOS:
        try:
            asegurar_carpeta_en_github('NUEVOS_APUNTES/' + g, rama='master',
                                       repo_override=REPO_UTILIDADES_GRADO)
        except Exception:
            pass
except Exception:
    pass

CABECERAS_CSV = [
    "grado", "archivo_original", "nombre_limpio", "es_apunte",
    "nombre_apunte", "txt_apunte", "tex_apunte", "pdf_apunte", "fecha_actualizacion"
]

PALETA_ALEATORIA = [
    "\\paletaBosque",
    "\\paletaCoral",
    "\\paletaLavanda",
    "\\paletaOceano",
]

TITULOS_ALEATORIOS = {
    "primaria": [
        "\\tituloG{{{0}}}{{{1}}}",
        "\\tituloD{{{0}}}",
        "\\tituloF{{{0}}}",
        "\\tituloA{{{0}}}{{{1}}}",
        "\\tituloB{{{0}}}{{{1}}}",
        "\\tituloC{{{0}}}",
    ],
    "secundaria": [
        "\\tituloP{{{0}}}{{{1}}}",
        "\\tituloE{{{0}}}{{{1}}}",
        "\\tituloJ{{{0}}}{{{1}}}",
        "\\tituloK{{{0}}}",
        "\\tituloH{{{0}}}",
        "\\tituloQ{{{0}}}",
    ],
}

TITULOS_LETRAS = ["A", "B", "C", "D", "F", "G", "H", "I", "K", "L", "M", "N", "Q"]
TITULOS_DOS_ARGS = {"A", "B", "G"}

VINETAS_ALEATORIAS = {
    "primaria": [
        ("\\begin{estrellalist}", "\\end{estrellalist}"),
        ("\\begin{bulletlist}", "\\end{bulletlist}"),
        ("\\begin{flechalist}", "\\end{flechalist}"),
        ("\\begin{marcalist}", "\\end{marcalist}"),
    ],
    "secundaria": [
        ("\\begin{alertalist}", "\\end{alertalist}"),
        ("\\begin{preguntalist}", "\\end{preguntalist}"),
        ("\\begin{letralist}", "\\end{letralist}"),
        ("\\begin{tarealist}", "\\end{tarealist}"),
    ],
}

TABLAS_ALEATORIAS = [
    "tablaminimal",
    "tablacabecera",
    "tablacuadricula",
]

ANCHO_MAX_VERBATIM = 92  # caracteres; ajustado al ancho real de página (márgenes de estilo.tex)
