from backend.generador_apuntes.transformacion_txt._procesar_metadatos_bloques import _procesar_metadatos_bloques
from backend.generador_apuntes.transformacion_txt._procesar_tabla_lista_parrafo import _procesar_tabla_lista_parrafo

def _procesar_linea_apunte(linea, linea_bruta, metadatos, estado, cuerpo_latex):
    """Procesa una línea ya limpiada delegando en los helpers de metadatos/bloques y
    de tabla/lista/párrafo. Mutúa 'estado' y 'cuerpo_latex' in-place."""
    if _procesar_metadatos_bloques(linea, linea_bruta, metadatos, estado, cuerpo_latex):
        return
    _procesar_tabla_lista_parrafo(linea, estado, cuerpo_latex)
