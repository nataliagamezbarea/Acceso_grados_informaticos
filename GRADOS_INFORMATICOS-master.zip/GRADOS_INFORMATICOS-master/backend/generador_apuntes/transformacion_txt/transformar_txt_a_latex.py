from backend.generador_apuntes.transformacion_txt._inicializar_metadatos import _inicializar_metadatos
from backend.generador_apuntes.transformacion_txt._procesar_linea_apunte import _procesar_linea_apunte
from backend.generador_apuntes.transformacion_txt._celdas_fila_tabla_markdown import _celdas_fila_tabla_markdown
from backend.generador_apuntes.latex_estilo import (
    construir_titulo_principal, obtener_ruta_estilo_entrada,
)

def transformar_txt_a_latex(contenido_txt, nombre_grado=""):
    """Transforma el archivo TXT estructurado en código LaTeX utilizando la plantilla maestra."""
    lineas = contenido_txt.splitlines()
    metadatos = _inicializar_metadatos(nombre_grado)

    cuerpo_latex = []
    estado = {"en_lista": False, "en_codigo": False, "en_tabla": False, "lista_fin_actual": "", "tabla_cierre_actual": ""}

    for linea_bruta in lineas:
        linea = linea_bruta.strip()
        if not linea or linea.startswith("#"):
            continue

        if estado["en_tabla"] and _celdas_fila_tabla_markdown(linea) is None:
            cuerpo_latex.append(f"{estado['tabla_cierre_actual']}\n\\end{{center}}\n\\vspace{{0.2cm}}\n")
            estado["en_tabla"] = False
            estado["tabla_cierre_actual"] = ""

        _procesar_linea_apunte(linea, linea_bruta, metadatos, estado, cuerpo_latex)

    if estado["en_lista"]:
        cuerpo_latex.append(estado["lista_fin_actual"])
    if estado["en_codigo"]:
        cuerpo_latex.append(r"\end{verbatim}")
    if estado["en_tabla"]:
        cuerpo_latex.append(f"{estado['tabla_cierre_actual']}\n\\end{{center}}\n")

    cuerpo_str = "\n".join(cuerpo_latex)
    ruta_estilo_entrada = obtener_ruta_estilo_entrada(nombre_grado)
    comando_titulo = construir_titulo_principal(metadatos["TITULO"], metadatos["SUBTITULO"])

    plantilla_str = rf"""\documentclass[12pt]{{article}}
\input{{{ruta_estilo_entrada}}}
\usarfondo

\begin{{document}}
\paletaOceano
{comando_titulo}
\vspace{{1mm}}
\begin{{center}}\large\textcolor{{gray}}{{Autor: {metadatos['AUTOR']} | {metadatos['GRADO']}}}\end{{center}}
\vspace{{3mm}}
{cuerpo_str}
\end{{document}}
"""

    return plantilla_str
