import datetime

def _inicializar_metadatos(nombre_grado=""):
    """Crea el diccionario de metadatos por defecto del apunte a partir del grado."""
    return {
        "TITULO": "Apunte de Estudio",
        "SUBTITULO": "Conceptos Teóricos y Ejercicios Prácticos",
        "AUTOR": "Natalia",
        "GRADO": nombre_grado.replace("_", " "),
        "FECHA": datetime.date.today().strftime("%d/%m/%Y"),
    }
