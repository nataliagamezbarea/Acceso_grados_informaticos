def _celdas_fila_tabla_markdown(linea):
    """Devuelve la lista de celdas SOLO si 'linea' es realmente una fila de tabla markdown
    (empieza y termina con '|' y tiene al menos 2 columnas). Si no, devuelve None.

    Antes se detectaba una tabla con solo comprobar si la línea contenía un '|' en
    cualquier parte, lo que borraba silenciosamente frases normales que casualmente
    llevaban una barra vertical (p. ej. "Verdadero | Falso" suelto en el texto, o
    restos de una tabla mal extraída del PDF original) sin imprimir nada en su lugar.
    """
    s = linea.strip()
    if not s.startswith("|") or not s.endswith("|") or s.count("|") < 3:
        return None
    celdas = [c.strip() for c in s.split("|")[1:-1]]
    return celdas if len(celdas) >= 2 else None
