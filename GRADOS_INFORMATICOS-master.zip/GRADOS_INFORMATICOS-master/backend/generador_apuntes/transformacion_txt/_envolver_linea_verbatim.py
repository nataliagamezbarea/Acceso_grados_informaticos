import re
import textwrap

from backend.generador_apuntes._comun import ANCHO_MAX_VERBATIM

def _envolver_linea_verbatim(linea_bruta, ancho=ANCHO_MAX_VERBATIM):
    """Envuelve una línea de bloque de código (```) para que NUNCA sobrepase el margen
    derecho de la página. LaTeX no ajusta líneas dentro de \\begin{verbatim} por sí solo,
    así que el ajuste se hace aquí en Python antes de escribir el .tex, conservando la
    indentación original en las líneas continuadas."""
    if len(linea_bruta) <= ancho:
        return [linea_bruta]
    indent_match = re.match(r"^[ \t]*", linea_bruta)
    indent = indent_match.group(0) if indent_match else ""
    resto = linea_bruta[len(indent):]
    ancho_resto = max(20, ancho - len(indent))
    trozos = textwrap.wrap(
        resto, width=ancho_resto, break_long_words=True,
        break_on_hyphens=False, replace_whitespace=False, drop_whitespace=False
    ) or [""]
    return [indent + trozos[0]] + [indent + "  " + t for t in trozos[1:]]
