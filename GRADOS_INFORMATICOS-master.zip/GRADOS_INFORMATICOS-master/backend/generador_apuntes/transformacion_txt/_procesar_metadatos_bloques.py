import re

from backend.generador_apuntes.latex_estilo import escapar_caracteres_latex

def _procesar_metadatos_bloques(linea, linea_bruta, metadatos, estado, cuerpo_latex):
    """Maneja metadatos y bloques especiales (código, secciones, cuestiones, desarrollo).
    Devuelve True si la línea fue consumida por alguno de estos bloques."""
    if linea.startswith("TITULO:"):
        metadatos["TITULO"] = linea.replace("TITULO:", "").strip()
        return True
    if linea.startswith("SUBTITULO:"):
        metadatos["SUBTITULO"] = linea.replace("SUBTITULO:", "").strip()
        return True
    if linea.startswith("AUTOR:"):
        metadatos["AUTOR"] = linea.replace("AUTOR:", "").strip()
        return True
    if linea.startswith("GRADO:"):
        metadatos["GRADO"] = linea.replace("GRADO:", "").strip()
        return True

    if linea.startswith("```"):
        if estado["en_lista"]:
            cuerpo_latex.append(estado["lista_fin_actual"])
            estado["en_lista"] = False
            estado["lista_fin_actual"] = ""
        if estado["en_codigo"]:
            cuerpo_latex.append(r"\end{verbatim}")
            estado["en_codigo"] = False
        else:
            cuerpo_latex.append(r"\begin{verbatim}")
            estado["en_codigo"] = True
        return True

    if estado["en_codigo"]:
        from backend.generador_apuntes.transformacion_txt._envolver_linea_verbatim import _envolver_linea_verbatim
        for sub_linea in _envolver_linea_verbatim(linea_bruta):
            cuerpo_latex.append(sub_linea)
        return True

    if linea.startswith("SECCION:"):
        if estado["en_lista"]:
            cuerpo_latex.append(estado["lista_fin_actual"])
            estado["en_lista"] = False
            estado["lista_fin_actual"] = ""
        titulo_sec = escapar_caracteres_latex(linea.replace("SECCION:", "").strip())
        cuerpo_latex.append(f"\n\\vspace{{4mm}}\n\\sectionheader{{2.6cm}}{{{titulo_sec}}}\n\\vspace{{4mm}}\n")
        return True

    if linea.startswith("SUBSECCION:"):
        if estado["en_lista"]:
            cuerpo_latex.append(estado["lista_fin_actual"])
            estado["en_lista"] = False
            estado["lista_fin_actual"] = ""
        titulo_subsec = escapar_caracteres_latex(linea.replace("SUBSECCION:", "").strip())
        cuerpo_latex.append(f"\n\\vspace{{3mm}}\n\\sectionheader{{1.8cm}}{{{titulo_subsec}}}\n\\vspace{{3mm}}\n")
        return True

    if linea.startswith("CUESTION") or linea.startswith("PREGUNTA") or linea.startswith("EJERCICIO"):
        if estado["en_lista"]:
            cuerpo_latex.append(estado["lista_fin_actual"])
            estado["en_lista"] = False
            estado["lista_fin_actual"] = ""
        texto_plano = re.sub(r"^(CUESTION|PREGUNTA|EJERCICIO):?\s*", "", linea)
        texto_q = escapar_caracteres_latex(texto_plano)
        cuerpo_latex.append(f"\n\\begin{{tcolorbox}}[colback=bgbox,colframe=primary,title=\\textbf{{{texto_q}}}]")
        cuerpo_latex.append(f"{texto_q}")
        cuerpo_latex.append(r"\end{tcolorbox}")
        return True

    if linea.startswith("DESARROLLO:"):
        if estado["en_lista"]:
            cuerpo_latex.append(estado["lista_fin_actual"])
            estado["en_lista"] = False
            estado["lista_fin_actual"] = ""
        texto_d = escapar_caracteres_latex(linea.replace("DESARROLLO:", "").strip())
        cuerpo_latex.append(f"\\textbf{{Desarrollo y Solución:}} {texto_d}\\par\\vspace{{0.3cm}}\n")
        return True

    return False
