import re

from backend.generador_apuntes.transformacion_txt._celdas_fila_tabla_markdown import _celdas_fila_tabla_markdown
from backend.generador_apuntes.latex_estilo import (
    escapar_caracteres_latex, construir_tabla_aleatoria, construir_lista_aleatoria,
)

def _procesar_tabla_lista_parrafo(linea, estado, cuerpo_latex):
    """Maneja las filas de tabla markdown, listas y párrafos sueltos."""
    celdas_tabla = None if estado["en_codigo"] else _celdas_fila_tabla_markdown(linea)
    if celdas_tabla is not None:
        if estado["en_lista"]:
            cuerpo_latex.append(estado["lista_fin_actual"])
            estado["en_lista"] = False
            estado["lista_fin_actual"] = ""
        if all(re.match(r"^[\-:]+$", c) for c in celdas_tabla):
            return
        if not estado["en_tabla"]:
            num_cols = len(celdas_tabla)
            cols_fmt = "".join(["l"] * num_cols)
            tabla_inicio, tabla_fin = construir_tabla_aleatoria(cols_fmt)
            cuerpo_latex.append(f"\n\\vspace{{0.2cm}}\n\\begin{{center}}\n{tabla_inicio}\n")
            estado["en_tabla"] = True
            estado["tabla_cierre_actual"] = tabla_fin
            celdas_tex = [f"\\tablacab{{{escapar_caracteres_latex(c)}}}" for c in celdas_tabla]
            cuerpo_latex.append(" & ".join(celdas_tex) + " \\\\ \\midrule")
        else:
            celdas_tex = [escapar_caracteres_latex(c) for c in celdas_tabla]
            cuerpo_latex.append(" & ".join(celdas_tex) + " \\\\ \\hline")
        return
    else:
        if estado["en_tabla"]:
            cuerpo_latex.append(f"{estado['tabla_cierre_actual']}\n\\end{{center}}\n\\vspace{{0.2cm}}\n")
            estado["en_tabla"] = False
            estado["tabla_cierre_actual"] = ""

    if linea.startswith("- ") or linea.startswith("* "):
        if not estado["en_lista"]:
            inicio, fin = construir_lista_aleatoria("primaria")
            cuerpo_latex.append(inicio)
            estado["en_lista"] = True
            estado["lista_fin_actual"] = fin
        texto_item = escapar_caracteres_latex(linea[2:].strip())
        cuerpo_latex.append(f"  \\item {texto_item}")
        return
    else:
        if estado["en_lista"]:
            cuerpo_latex.append(estado["lista_fin_actual"])
            estado["en_lista"] = False
            estado["lista_fin_actual"] = ""

    cuerpo_latex.append(f"{escapar_caracteres_latex(linea)}\\par\n")
