import os

from backend.generador_apuntes._comun import DIRECTORIO_NUEVOS_APUNTES, DIRECTORIO_BASE
from backend.generador_apuntes.registros_csv import limpiar_nombre_apunte

def crear_borrador_apunte(grado, archivo_original, nombre_apunte, datos_pdf_original=None, lista_enunciados=None):
    """Crea SOLO el borrador .txt a partir del TXT real o, si no existe, genera uno de ejemplo.
    NUNCA crea el .tex: ese se genera únicamente al pulsar 'HACER / COMPILAR APUNTE (LaTeX)'
    dentro de compilar_apunte_pdf (que lo regenera desde el TXT en cada compilación)."""
    nombre_apunte = limpiar_nombre_apunte(nombre_apunte)
    dir_destino = os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado)
    os.makedirs(dir_destino, exist_ok=True)

    ruta_txt = os.path.join(dir_destino, f"{nombre_apunte}.txt")
    ruta_txt_origen = None

    if archivo_original:
        candidatos = [
            os.path.abspath(archivo_original),
            os.path.join(DIRECTORIO_BASE, archivo_original),
            os.path.join(dir_destino, os.path.basename(archivo_original)),
            os.path.join(DIRECTORIO_BASE, "NUEVOS_APUNTES", grado, os.path.basename(archivo_original)),
        ]
        for candidato in candidatos:
            if os.path.isfile(candidato):
                ruta_txt_origen = candidato
                break

    if ruta_txt_origen and os.path.splitext(ruta_txt_origen)[1].lower() == ".txt":
        try:
            with open(ruta_txt_origen, "r", encoding="utf-8") as f:
                contenido_txt = f.read()
        except UnicodeDecodeError:
            with open(ruta_txt_origen, "r", encoding="latin-1", errors="replace") as f:
                contenido_txt = f.read()
        with open(ruta_txt, "w", encoding="utf-8") as f:
            f.write(contenido_txt)
    elif not os.path.exists(ruta_txt):
        lineas = [
            "# ==============================================================================",
            "# GUÍA DE ESTRUCTURA PARA APUNTE TEÓRICO / PRÁCTICO",
            "# Llena este TXT y pulsa 'APUNTES HECHOS' para compilar el PDF con LaTeX",
            "# ==============================================================================" + "\n",
            f"TITULO: {nombre_apunte.replace('APUNTE_', '').replace('_', ' ')}",
            "SUBTITULO: Guía de Conceptos, Tablas Comparativas y Ejercicios Prácticos",
            "AUTOR: Natalia",
            f"GRADO: {grado.replace('_', ' ')}\n",
            "SECCION: 1. Objetivos y Fundamentos Teóricos",
            "- Descripción conceptual de la unidad y ámbito de aplicación técnica.",
            "- Arquitectura, estándares y protocolos fundamentales involucrados.\n",
            "SECCION: 2. Tabla Comparativa de Conceptos Clave",
            "| Concepto / Protocolo | Capa / Módulo | Propósito y Características |",
            "| -------------------- | ------------- | --------------------------- |",
            "| Elemento Principal   | Capa Base     | Control de flujo y fiabilidad |",
            "| Elemento Auxiliar    | Servicios     | Optimización de rendimiento y latencia |\n",
            "SECCION: 3. Desarrollo y Casos Prácticos",
            "- Explicación detallada del procedimiento y resolución técnica.\n",
            "SECCION: 4. Comandos y Código de Referencia",
            "```bash",
            "# Comandos de prueba y verificación",
            "ip a || ifconfig",
            "```\n",
            "SECCION: 5. Resumen y Puntos Clave",
            "- Puntos críticos a recordar para el repaso y exámenes.",
            "- Buenas prácticas y consideraciones de seguridad."
        ]
        with open(ruta_txt, "w", encoding="utf-8") as f:
            f.write("\n".join(lineas) + "\n")

    return ruta_txt
