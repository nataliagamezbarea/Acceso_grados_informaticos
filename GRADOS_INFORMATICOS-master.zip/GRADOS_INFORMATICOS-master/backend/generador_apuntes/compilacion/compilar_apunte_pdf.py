import os
import shutil

from backend.generador_apuntes._comun import (
    DIRECTORIO_NUEVOS_APUNTES, CONFIGURACION_GRADOS, DIRECTORIO_GI,
)
from backend.generador_apuntes.registros_csv import (
    actualizar_csvs_del_grado, _commit_git_grado, limpiar_nombre_apunte,
)
from backend.generador_apuntes.transformacion_txt import transformar_txt_a_latex
from backend.generador_apuntes.compilacion.resolver_ruta_txt_apunte import resolver_ruta_txt_apunte
from backend.generador_apuntes.compilacion._compilar_xelatex import _compilar_xelatex
from backend.generador_apuntes.compilacion._pdf_fallback import _pdf_fallback

def _generar_latex_del_apunte(grado, nombre_apunte, archivo_original=None):
    """Devuelve (contenido_tex, contenido_txt) a partir del borrador .txt del apunte.
    Reutilizada por el flujo local (compilar_apunte_pdf) y por el flujo
    'Compilar con GitHub Actions' (manejar_compilar_apunte). Si no hay texto de
    origen devuelve (None, None)."""
    nombre_apunte = limpiar_nombre_apunte(nombre_apunte)
    dir_destino = os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado)
    ruta_txt = os.path.join(dir_destino, f"{nombre_apunte}.txt")
    ruta_txt_origen = resolver_ruta_txt_apunte(grado, nombre_apunte, archivo_original)
    fuente_txt = None
    if os.path.exists(ruta_txt_origen) and os.path.isfile(ruta_txt_origen):
        fuente_txt = ruta_txt_origen
    elif os.path.exists(ruta_txt) and os.path.isfile(ruta_txt):
        fuente_txt = ruta_txt

    contenido_txt = None
    if fuente_txt:
        try:
            with open(fuente_txt, encoding="utf-8") as f:
                contenido_txt = f.read()
        except UnicodeDecodeError:
            with open(fuente_txt, encoding="latin-1", errors="replace") as f:
                contenido_txt = f.read()
    else:
        contenido_txt = (f"TITULO: {nombre_apunte.replace('APUNTE_', '').replace('_', ' ')}\n"
                         f"SECCION: Resumen\n- Contenido\n")
    if not contenido_txt:
        return None, None
    contenido_tex = transformar_txt_a_latex(contenido_txt, grado)
    return contenido_tex, contenido_txt


def compilar_apunte_pdf(grado, nombre_apunte, archivo_original=None):
    """Compila el archivo TXT/TEX en el PDF final utilizando la biblioteca LaTeX compartida."""
    nombre_apunte = limpiar_nombre_apunte(nombre_apunte)
    dir_destino = os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado)
    ruta_tex = os.path.join(dir_destino, f"{nombre_apunte}.tex")
    ruta_txt = os.path.join(dir_destino, f"{nombre_apunte}.txt")
    ruta_pdf_salida = os.path.join(dir_destino, f"{nombre_apunte}.pdf")

    # 1. Regenerar siempre el .tex desde el TXT del borrador para evitar stale files.
    contenido_tex, contenido_txt = _generar_latex_del_apunte(grado, nombre_apunte, archivo_original)
    if contenido_tex is None:
        return None
    if os.path.exists(ruta_tex):
        os.remove(ruta_tex)
    with open(ruta_tex, "w", encoding="utf-8") as f:
        f.write(contenido_tex)
    if contenido_txt and os.path.exists(ruta_txt):
        with open(ruta_txt, "w", encoding="utf-8") as f:
            f.write(contenido_txt)

    # 2. Usar la biblioteca LaTeX compartida como única fuente de estilo. El apunte
    #    solo debe mantener el TXT/.tex/.pdf; no se duplican fuentes, imágenes ni estilo.
    compilado = _compilar_xelatex(ruta_tex, ruta_pdf_salida, dir_destino)
    if not compilado:
        _pdf_fallback(ruta_pdf_salida, nombre_apunte, grado, archivo_original, dir_destino)

    # 3. Limpiar archivos temporales y el TXT tras la compilación exitosa
    for extension in [".aux", ".fdb_latexmk", ".fls", ".log", ".tex", ".txt"]:
        ruta_tmp = os.path.join(dir_destino, f"{nombre_apunte}{extension}")
        if os.path.exists(ruta_tmp):
            try: os.remove(ruta_tmp)
            except Exception: pass

    dir_repo_grado = CONFIGURACION_GRADOS[grado]["directorio"] if grado in CONFIGURACION_GRADOS else os.path.join(DIRECTORIO_GI, grado)
    dir_gi_apuntes = os.path.join(dir_repo_grado, "apuntes")
    os.makedirs(dir_gi_apuntes, exist_ok=True)
    destino_gi = os.path.join(dir_gi_apuntes, f"{nombre_apunte}.pdf")
    if os.path.exists(ruta_pdf_salida):
        shutil.copy2(ruta_pdf_salida, destino_gi)
        try: os.remove(ruta_pdf_salida)
        except Exception: pass

    # Si ya no quedan archivos en NUEVOS_APUNTES/<grado>, eliminar la carpeta para no dejar rastro
    try:
        if os.path.exists(dir_destino) and not os.listdir(dir_destino):
            shutil.rmtree(dir_destino)
        if os.path.exists(DIRECTORIO_NUEVOS_APUNTES) and not os.listdir(DIRECTORIO_NUEVOS_APUNTES):
            shutil.rmtree(DIRECTORIO_NUEVOS_APUNTES)
    except Exception:
        pass

    actualizar_csvs_del_grado(grado, archivo_original or nombre_apunte, nombre_apunte=nombre_apunte, apunte_compilado=True, rel_apunte=f"apuntes/{nombre_apunte}.pdf")
    _commit_git_grado(grado, f"Compilar apunte LaTeX: {nombre_apunte}")
    return destino_gi

