import os

from backend.generador_apuntes._comun import CONFIGURACION_GRADOS, DIRECTORIO_GI
from backend.generador_apuntes.registros_csv import (
    generar_propuesta_nombre_apunte, sincronizar_registro_csv, _commit_git_grado,
)
from backend.gestor_datos import (
    cargar_revision, clave_registro, construir_datos_visor, limpiar_nombre_archivo,
)
from backend.generador_apuntes.compilacion.preparar_apunte import preparar_apunte

def compilar_todos_los_apuntes(grado):
    """Prepara todos los apuntes confirmados del grado: TXT + copia tal cual del PDF en GI."""
    rev = cargar_revision()
    datos, _ = construir_datos_visor()
    d = datos.get(grado, {})

    compilados = 0
    errores = []

    todos = d.get("entries", []) + d.get("no_cambian", [])
    for it in todos:
        arch = it.get("archivo", "")
        info_r = rev.get(clave_registro(grado, arch), {})
        if info_r.get("inc_apunte", False):
            nombre_ap = info_r.get("nombre_apunte") or generar_propuesta_nombre_apunte(arch)
            try:
                destino = preparar_apunte(grado, arch, nombre_ap)
                if not destino:
                    raise Exception("no se pudo copiar el PDF original")
                sincronizar_registro_csv(
                    grado, arch, limpiar_nombre_archivo(arch),
                    es_apunte=True, nombre_apunte=nombre_ap, apunte_compilado=True
                )
                compilados += 1
            except Exception as e:
                errores.append(f"{arch}: {e}")

    if compilados:
        _commit_git_grado(grado, f"Entregar {compilados} apuntes en GI/{grado}/apuntes")
    return compilados, errores
