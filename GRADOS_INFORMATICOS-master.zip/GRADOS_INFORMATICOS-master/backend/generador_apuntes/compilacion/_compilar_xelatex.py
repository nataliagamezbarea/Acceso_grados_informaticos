import os
import shutil
import subprocess

from backend.generador_apuntes.latex_estilo import asegurar_paquetes_latex
from backend.configuracion import DIRECTORIO_BASE

def _compilar_xelatex(ruta_tex, ruta_pdf_salida, dir_destino):
    """Intenta compilar con xelatex. Devuelve True si el PDF resultante es válido.

    Se compila desde la RAÍZ del repositorio (cwd=DIRECTORIO_BASE) e inyecta
    'bibliotecas_latex' en TEXINPUTS, de modo que estilo.tex y las fuentes
    (Path=./bibliotecas_latex/fonts/) se resuelven con rutas RELATIVAS al repo.
    Así el mismo estilo funciona tanto en local como en el runner Docker de
    GitHub Actions (que hace checkout del repo y compila con cwd=raíz)."""
    if os.path.exists(ruta_pdf_salida):
        os.remove(ruta_pdf_salida)
    if not (shutil.which("xelatex") and os.path.exists(ruta_tex)):
        return False
    asegurar_paquetes_latex()
    entorno = os.environ.copy()
    ruta_biblioteca_latex = os.path.join(DIRECTORIO_BASE, "bibliotecas_latex")
    if os.path.isdir(ruta_biblioteca_latex):
        entorno["TEXINPUTS"] = ruta_biblioteca_latex + os.pathsep
    try:
        subprocess.run(
            ["xelatex", "-interaction=nonstopmode", "-output-directory", dir_destino, ruta_tex],
            capture_output=True, timeout=90, cwd=DIRECTORIO_BASE, env=entorno
        )
        if os.path.exists(ruta_pdf_salida):
            import pymupdf as fitz_module
            doc_check = fitz_module.open(ruta_pdf_salida)
            valido = len(doc_check) > 0 and doc_check[0].get_text().strip()
            doc_check.close()
            return bool(valido)
    except Exception:
        pass
    return False
