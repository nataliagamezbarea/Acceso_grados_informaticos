import os

from backend.generador_apuntes._comun import DIRECTORIO_NUEVOS_APUNTES, DIRECTORIO_BASE
from backend.generador_apuntes.registros_csv import limpiar_nombre_apunte

def resolver_ruta_txt_apunte(grado, nombre_apunte, archivo_original=None):
    """Resuelve la ruta del TXT que debe usarse como origen del apunte.

    IMPORTANTE: esta función SOLO puede devolver rutas a archivos .txt. Antes,
    los candidatos construidos a partir de 'archivo_original' (que normalmente
    es el PDF original subido, p. ej. 'Asignacion_IP.pdf') no se filtraban por
    extensión: si ese PDF existía en disco, se devolvía TAL CUAL como si fuera
    el borrador de texto. compilar_apunte_pdf lo abría entonces como texto
    (con fallback a latin-1, que nunca falla), colando los bytes binarios crudos
    del PDF dentro del .tex compilado -> se veía el propio PDF (%PDF-1.7...)
    pegado como contenido del apunte. Filtrando aquí por '.txt' se garantiza que
    solo se usa un borrador de texto real como origen."""
    nombre_apunte = limpiar_nombre_apunte(nombre_apunte)
    dir_destino = os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado)
    rutas = []

    if archivo_original and os.path.splitext(archivo_original)[1].lower() == ".txt":
        rutas.append(os.path.abspath(archivo_original))
        rutas.append(os.path.join(DIRECTORIO_BASE, archivo_original))
        rutas.append(os.path.join(dir_destino, os.path.basename(archivo_original)))

    rutas.append(os.path.join(dir_destino, f"{nombre_apunte}.txt"))
    rutas.append(os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado, f"{nombre_apunte}.txt"))

    for ruta in rutas:
        if ruta and os.path.splitext(ruta)[1].lower() == ".txt" and os.path.exists(ruta):
            return ruta
    return os.path.join(dir_destino, f"{nombre_apunte}.txt")
