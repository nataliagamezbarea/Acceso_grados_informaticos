import os

from backend.generador_apuntes._comun import DIRECTORIO_NUEVOS_APUNTES, CONFIGURACION_GRADOS, DIRECTORIO_GI
from backend.generador_apuntes.registros_csv import limpiar_nombre_apunte
from backend.generador_apuntes.compilacion._leer_pdf_original_robusto import _leer_pdf_original_robusto

def preparar_apunte(grado, archivo_original, nombre_apunte, hacia_gi=True, rel_origen=None):
    """Prepara un apunte marcado como tal:
    1. Asegura el borrador .txt de muestra en NUEVOS_APUNTES (sin pisar ediciones).
    2. Copia el PDF del archivo original TAL CUAL:
       - hacia_gi=True  -> GI/<grado>/apuntes/<nombre_original>.pdf  (entrega)
       - hacia_gi=False -> NUEVOS_APUNTES/<grado>/<nombre_original>.pdf (recolecta)
    NO genera ningún PDF desde el TXT y NUNCA renombra el PDF a APUNTE_*:
    el PDF entregado es el del propio archivo, con su propio nombre.
    Devuelve la ruta del PDF copiado (o None)."""

    arch_base = os.path.basename(archivo_original)
    nombre_apunte = limpiar_nombre_apunte(nombre_apunte)

    # 1. Borrador .txt de muestra (solo si aún no existe)
    dir_na = os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado)
    os.makedirs(dir_na, exist_ok=True)
    ruta_txt = os.path.join(dir_na, f"{nombre_apunte}.txt")
    if not os.path.exists(ruta_txt):
        datos = _leer_pdf_original_robusto(grado, arch_base, rel_origen)
        texto = ""
        if datos:
            try:
                import pymupdf as fitz
                doc = fitz.open(stream=datos, filetype="pdf")
                texto = "\n".join(p.get_text("text") for p in doc)
                doc.close()
            except Exception:
                texto = ""
        if not texto.strip():
            texto = f"TITULO: {nombre_apunte.replace('APUNTE_', '').replace('_', ' ')}\nSECCION: Contenido\n- (Completa este borrador)\n"
        with open(ruta_txt, "w", encoding="utf-8") as f:
            f.write(texto)

    # 2. Copia TAL CUAL del PDF original (mismo nombre, sin transformación)
    dir_repo = CONFIGURACION_GRADOS[grado]["directorio"] if grado in CONFIGURACION_GRADOS else os.path.join(DIRECTORIO_GI, grado)
    datos_pdf = _leer_pdf_original_robusto(grado, arch_base, rel_origen)
    if not datos_pdf:
        return None

    if hacia_gi:
        destino = os.path.join(dir_repo, "apuntes", arch_base)
        if os.path.abspath(destino) == os.path.abspath(os.path.join(dir_repo, "archivos", arch_base)):
            return None
        os.makedirs(os.path.dirname(destino), exist_ok=True)
    else:
        destino = os.path.join(dir_na, arch_base)
    with open(destino, "wb") as f:
        f.write(datos_pdf)
    return destino
