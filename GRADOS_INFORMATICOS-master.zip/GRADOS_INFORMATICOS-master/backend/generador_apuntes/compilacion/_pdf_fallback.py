import os
import datetime

def _pdf_fallback(ruta_pdf_salida, nombre_apunte, grado, archivo_original, dir_destino):
    """Genera un PDF mínimo con el texto real del apunte; NO reutiliza main.pdf de la librería."""
    contenido_fuente = ""
    if archivo_original and os.path.exists(os.path.abspath(archivo_original)):
        try:
            with open(os.path.abspath(archivo_original), encoding="utf-8") as f:
                contenido_fuente = f.read()
        except Exception:
            pass
    if not contenido_fuente and os.path.exists(os.path.join(dir_destino, f"{nombre_apunte}.txt")):
        try:
            with open(os.path.join(dir_destino, f"{nombre_apunte}.txt"), encoding="utf-8") as f:
                contenido_fuente = f.read()
        except Exception:
            pass
    if not contenido_fuente:
        contenido_fuente = nombre_apunte.replace("_", " ")

    lineas = [l.strip() for l in contenido_fuente.splitlines() if l.strip()]
    import pymupdf as fitz
    doc = fitz.open()
    pagina = doc.new_page(width=595, height=842)
    y = 55
    pagina.draw_rect(fitz.Rect(0, 0, 595, 75), color=(0.12, 0.23, 0.54), fill=(0.12, 0.23, 0.54))
    pagina.insert_textbox(fitz.Rect(35, 18, 560, 42), nombre_apunte.replace("_", " "), fontsize=16, color=(1, 1, 1), fontname="hebo")
    pagina.insert_textbox(fitz.Rect(35, 45, 560, 65), f"Apunte de Estudio | {grado.replace('_', ' ')} | Autor: Natalia", fontsize=10, color=(0.85, 0.90, 1.0), fontname="helv")

    for linea in lineas[:35]:
        pagina.insert_textbox(fitz.Rect(40, y, 555, y + 20), linea[:200], fontsize=11, color=(0.15, 0.15, 0.15), fontname="helv")
        y += 18
        if y > 760:
            break

    if y < 790:
        pagina.draw_line(fitz.Point(35, 800), fitz.Point(560, 800), color=(0.7, 0.7, 0.7), width=0.8)
        pagina.insert_textbox(fitz.Rect(35, 805, 560, 825), f"Documento generado automáticamente - {datetime.date.today().isoformat()}", fontsize=8, color=(0.5, 0.5, 0.5), fontname="heit")

    doc.save(ruta_pdf_salida)
    doc.close()
