import os

from backend.generador_apuntes._comun import CONFIGURACION_GRADOS, DIRECTORIO_GI
from backend.gestor_datos import leer_archivo_original

def _leer_pdf_original_robusto(grado, arch_base, rel_origen=None):
    """Lee el PDF original probando varias ubicaciones relativas conocidas."""
    candidatos = []
    if rel_origen:
        candidatos.append(rel_origen)
        if not rel_origen.startswith("archivos/"):
            candidatos.append("archivos/" + rel_origen)
    candidatos += ["archivos/" + arch_base, arch_base, "apuntes/" + arch_base]
    for rel in candidatos:
        datos = leer_archivo_original(grado, rel)
        if datos:
            return datos
    dir_repo = CONFIGURACION_GRADOS[grado]["directorio"] if grado in CONFIGURACION_GRADOS else os.path.join(DIRECTORIO_GI, grado)
    for sub in ["archivos", "apuntes", ""]:
        try:
            p = os.path.join(dir_repo, sub, arch_base) if sub else os.path.join(dir_repo, arch_base)
            if os.path.exists(p):
                return open(p, "rb").read()
        except Exception:
            pass
    return None
