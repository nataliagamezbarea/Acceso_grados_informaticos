import os
import re
import csv

from backend.generador_apuntes._comun import CONFIGURACION_GRADOS

def actualizar_csvs_del_grado(grado, archivo_original, nombre_limpio=None, nombre_apunte=None, apunte_compilado=False, rel_apunte=None):
    """Actualiza EJERCICIOS_PRACTICAS_PROYECTOS.csv y APUNTES.csv en la carpeta del grado.
    rel_apunte: ruta relativa real del PDF entregado (p.ej. 'apuntes/APUNTE_X.pdf' en el
    flujo LaTeX o 'apuntes/<original>.pdf' en el flujo de copia tal cual)."""
    dir_repo = CONFIGURACION_GRADOS[grado]["directorio"]
    csv_ejercicios = os.path.join(dir_repo, "EJERCICIOS_PRACTICAS_PROYECTOS.csv")
    csv_apuntes = os.path.join(dir_repo, "APUNTES.csv")

    arch_base = os.path.basename(archivo_original)
    tema_nombre = ""
    asignatura = ""
    trimestre = ""
    profesor = ""

    # 1. Actualizar fila en EJERCICIOS_PRACTICAS_PROYECTOS.csv
    if os.path.exists(csv_ejercicios):
        filas = []
        campos = []
        try:
            with open(csv_ejercicios, mode="r", encoding="utf-8", errors="ignore") as f:
                lector = csv.DictReader(f)
                campos = lector.fieldnames or ["NOMBRE","TIPO","FECHA","ASIGNATURA","ARCHIVO","📒 APUNTES","PROFESOR","TRIMESTRE"]
                if nombre_apunte and "📒 APUNTES" not in campos:
                    campos.append("📒 APUNTES")
                for fila in lector:
                        r_arch = os.path.basename(fila.get("ARCHIVO", ""))
                        if r_arch == arch_base or fila.get("ARCHIVO", "") == archivo_original:
                            tema_nombre = fila.get("NOMBRE", "")
                            asignatura = fila.get("ASIGNATURA", "")
                            trimestre = fila.get("TRIMESTRE", "")
                            profesor = fila.get("PROFESOR", "")

                            if nombre_limpio and nombre_limpio != arch_base and not nombre_apunte:
                                prefijo = os.path.dirname(fila.get("ARCHIVO", ""))
                                fila["ARCHIVO"] = f"{prefijo}/{nombre_limpio}" if prefijo else f"archivos/{nombre_limpio}"

                            if nombre_apunte:
                                # El PDF entregado conserva el nombre del archivo original
                                fila["📒 APUNTES"] = rel_apunte or f"apuntes/{arch_base}"
                        filas.append(fila)
            with open(csv_ejercicios, mode="w", newline="", encoding="utf-8") as f:
                escritor = csv.DictWriter(f, fieldnames=campos)
                escritor.writeheader()
                escritor.writerows(filas)
        except Exception as e:
            print(f"Error actualizando {csv_ejercicios}: {e}")

    # 2. Si el apunte está compilado, registrarlo en APUNTES.csv
    if apunte_compilado and nombre_apunte and os.path.exists(csv_apuntes):
        rel_final = rel_apunte or f"apuntes/{arch_base}"
        filas_ap = []
        campos_ap = ["NOMBRE","ARCHIVO","ASIGNATURA","TRIMESTRE","PROFESOR"]
        existe = False
        try:
            with open(csv_apuntes, mode="r", encoding="utf-8", errors="ignore") as f:
                lector = csv.DictReader(f)
                if lector.fieldnames: campos_ap = lector.fieldnames
                for fila in lector:
                    if fila.get("ARCHIVO", "").strip() == rel_final:
                        existe = True
                        if tema_nombre: fila["NOMBRE"] = tema_nombre
                        if asignatura: fila["ASIGNATURA"] = asignatura
                        if trimestre: fila["TRIMESTRE"] = trimestre
                        if profesor: fila["PROFESOR"] = profesor
                    filas_ap.append(fila)

            if not existe:
                nombre_mostrar = tema_nombre if tema_nombre else nombre_apunte.replace("APUNTE_", "").replace("_", " ")
                filas_ap.append({
                    "NOMBRE": nombre_mostrar,
                    "ARCHIVO": rel_final,
                    "ASIGNATURA": asignatura,
                    "TRIMESTRE": trimestre,
                    "PROFESOR": profesor
                })

            with open(csv_apuntes, mode="w", newline="", encoding="utf-8") as f:
                escritor = csv.DictWriter(f, fieldnames=campos_ap)
                escritor.writeheader()
                escritor.writerows(filas_ap)
        except Exception as e:
            print(f"Error actualizando {csv_apuntes}: {e}")
