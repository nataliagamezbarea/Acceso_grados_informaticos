import re

def limpiar_nombre_apunte(nombre):
    """Limpia y valida el nombre del apunte con prefijo APUNTE_."""
    limpio = re.sub(r"[^\w\.\-]+", "_", nombre.strip())
    limpio = re.sub(r"_+", "_", limpio).strip("_")
    if limpio.lower().endswith(".pdf"): limpio = limpio[:-4]
    if limpio.lower().endswith(".txt"): limpio = limpio[:-4]
    if limpio.lower().endswith(".tex"): limpio = limpio[:-4]
    if not limpio.upper().startswith("APUNTE_"):
        limpio = "APUNTE_" + limpio
    return limpio
