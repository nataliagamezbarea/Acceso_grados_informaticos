import os
import re

def generar_propuesta_nombre_apunte(archivo):
    """Genera una propuesta limpia de nombre de apunte."""
    base = os.path.splitext(os.path.basename(archivo))[0]
    base = re.sub(r"^(?:APUNTE|ENTREGA|PRACTICA|ACTIVIDAD|EJERCICIO)[_\-\s]*", "", base, flags=re.IGNORECASE)
    limpio = re.sub(r"[^\w]+", "_", base).strip("_").upper()
    return f"APUNTE_{limpio}" if limpio else "APUNTE_NUEVO"
