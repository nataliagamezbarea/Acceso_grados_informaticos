import subprocess

from backend.generador_apuntes._comun import CONFIGURACION_GRADOS

def _commit_git_grado(grado, mensaje):
    """Commit de seguridad en el repo del grado tras compilar/entregar un apunte.
    Duplicado deliberadamente respecto a operaciones_git._commit_git para evitar
    un import circular (operaciones_git ya importa de este módulo)."""
    try:
        cfg = CONFIGURACION_GRADOS.get(grado)
        if not cfg:
            return
        dir_repo = cfg["directorio"]
        res = subprocess.run(["git", "-C", dir_repo, "status", "--porcelain"], capture_output=True, text=True)
        if res.returncode == 0 and not res.stdout.strip():
            return
        subprocess.run(["git", "-C", dir_repo, "add", "-A"], capture_output=True)
        subprocess.run(["git", "-C", dir_repo, "commit", "-m", mensaje], capture_output=True)
        subprocess.run(["git", "-C", dir_repo, "branch", "-f", cfg["rama_limpia"], "HEAD"], capture_output=True)
    except Exception:
        pass
