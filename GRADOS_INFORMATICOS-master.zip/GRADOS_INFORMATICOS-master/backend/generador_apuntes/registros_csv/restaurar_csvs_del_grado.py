import os
import csv

from backend.generador_apuntes._comun import CONFIGURACION_GRADOS, DIRECTORIO_NUEVOS_APUNTES
from backend.gestor_datos import limpiar_nombre_archivo
from backend.generador_apuntes.registros_csv.limpiar_nombre_apunte import limpiar_nombre_apunte

def restaurar_csvs_del_grado(grado, archivo_original, nombre_apunte=None):
    """Restaura los CSVs del grado al estado inicial: quita el enlace del apunte,
    elimina la fila de APUNTES.csv y devuelve el ARCHIVO a su nombre original."""
    dir_repo = CONFIGURACION_GRADOS[grado]["directorio"]
    csv_ejercicios = os.path.join(dir_repo, "EJERCICIOS_PRACTICAS_PROYECTOS.csv")
    csv_apuntes = os.path.join(dir_repo, "APUNTES.csv")

    arch_base = os.path.basename(archivo_original)
    # La fila puede estar bajo el nombre original o bajo el renombrado
    nombres_posibles = {arch_base, limpiar_nombre_archivo(arch_base)}

    if os.path.exists(csv_ejercicios):
        filas = []
        campos = []
        try:
            with open(csv_ejercicios, mode="r", encoding="utf-8", errors="ignore") as f:
                lector = csv.DictReader(f)
                campos = lector.fieldnames or []
                for fila in lector:
                    r_arch = os.path.basename(fila.get("ARCHIVO", ""))
                    if r_arch in nombres_posibles or fila.get("ARCHIVO", "") == archivo_original:
                        if "📒 APUNTES" in fila:
                            fila["📒 APUNTES"] = ""
                        prefijo = os.path.dirname(fila.get("ARCHIVO", ""))
                        fila["ARCHIVO"] = f"{prefijo}/{arch_base}" if prefijo else f"archivos/{arch_base}"
                    filas.append(fila)
            with open(csv_ejercicios, mode="w", newline="", encoding="utf-8") as f:
                escritor = csv.DictWriter(f, fieldnames=campos)
                escritor.writeheader()
                escritor.writerows(filas)
        except Exception as e:
            print(f"Error restaurando {csv_ejercicios}: {e}")

    if nombre_apunte and os.path.exists(csv_apuntes):
        filas_ap = []
        campos_ap = ["NOMBRE","ARCHIVO","ASIGNATURA","TRIMESTRE","PROFESOR"]
        # El apunte puede estar registrado con el nombre original o con nombre APUNTE_ (legado)
        rel_apuntes = {f"apuntes/{n}" for n in nombres_posibles}
        rel_apuntes.add(f"apuntes/{nombre_apunte}.pdf")
        try:
            with open(csv_apuntes, mode="r", encoding="utf-8", errors="ignore") as f:
                lector = csv.DictReader(f)
                if lector.fieldnames: campos_ap = lector.fieldnames
                for fila in lector:
                    if fila.get("ARCHIVO", "").strip() not in rel_apuntes:
                        filas_ap.append(fila)
            with open(csv_apuntes, mode="w", newline="", encoding="utf-8") as f:
                escritor = csv.DictWriter(f, fieldnames=campos_ap)
                escritor.writeheader()
                escritor.writerows(filas_ap)
        except Exception as e:
            print(f"Error restaurando {csv_apuntes}: {e}")
    return True
