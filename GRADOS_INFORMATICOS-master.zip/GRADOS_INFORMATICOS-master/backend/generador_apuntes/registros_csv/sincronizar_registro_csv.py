import os
import datetime

from backend.generador_apuntes._comun import CONFIGURACION_GRADOS, DIRECTORIO_NUEVOS_APUNTES
from backend.generador_apuntes.registros_csv.obtener_registros_csv import obtener_registros_csv
from backend.generador_apuntes.registros_csv.generar_propuesta_nombre_apunte import generar_propuesta_nombre_apunte
from backend.generador_apuntes.registros_csv.limpiar_nombre_apunte import limpiar_nombre_apunte
from backend.generador_apuntes.registros_csv.guardar_registros_csv import guardar_registros_csv
from backend.generador_apuntes.registros_csv.actualizar_csvs_del_grado import actualizar_csvs_del_grado

def sincronizar_registro_csv(grado, archivo_original, nombre_limpio, es_apunte=False, nombre_apunte=None, apunte_compilado=False, actualizar_grado=True, rel_apunte=None):
    """Sincroniza el registro CSV central y los CSVs de grado."""
    registros = obtener_registros_csv()
    k = f"{grado}::{archivo_original}"
    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if not nombre_apunte:
        nombre_apunte = generar_propuesta_nombre_apunte(archivo_original)
    nombre_apunte = limpiar_nombre_apunte(nombre_apunte)

    archivo_txt = os.path.join("almacen", "NUEVOS_APUNTES", grado, f"{nombre_apunte}.txt") if es_apunte else ""
    # El .tex SOLO existe durante la compilación (compilar_apunte_pdf lo genera y lo
    # borra al terminar). El registro solo lo anota si el archivo existe de verdad;
    # así el check "Apunte" nunca da la impresión de haber creado un .tex.
    ruta_tex_real = os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado, f"{nombre_apunte}.tex")
    archivo_tex = os.path.join("almacen", "NUEVOS_APUNTES", grado, f"{nombre_apunte}.tex") if (es_apunte and os.path.exists(ruta_tex_real)) else ""
    # El PDF compilado con LaTeX NUNCA se queda en NUEVOS_APUNTES: compilar_apunte_pdf lo
    # mueve (copia + borra) a GI/<grado>/apuntes/. El registro debe reflejar esa ubicación
    # real, no la ruta intermedia de NUEVOS_APUNTES.
    archivo_pdf = os.path.join("apuntes", f"{nombre_apunte}.pdf") if (es_apunte and apunte_compilado) else ""

    registros[k] = {
        "grado": grado,
        "archivo_original": archivo_original,
        "nombre_limpio": nombre_limpio,
        "es_apunte": "1" if es_apunte else "0",
        "nombre_apunte": nombre_apunte if es_apunte else "",
        "txt_apunte": archivo_txt,
        "tex_apunte": archivo_tex,
        "pdf_apunte": archivo_pdf,
        "fecha_actualizacion": ahora
    }
    guardar_registros_csv(registros)

    if actualizar_grado:
        actualizar_csvs_del_grado(grado, archivo_original, nombre_limpio=nombre_limpio, nombre_apunte=nombre_apunte if es_apunte else None, apunte_compilado=apunte_compilado, rel_apunte=rel_apunte)
    return nombre_apunte
