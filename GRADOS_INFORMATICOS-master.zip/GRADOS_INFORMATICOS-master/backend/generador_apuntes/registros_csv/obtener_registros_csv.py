import os
import csv

from backend.generador_apuntes._comun import RUTA_CSV_REGISTRO

def obtener_registros_csv():
    """Lee el CSV de registro centralizado."""
    if not os.path.exists(RUTA_CSV_REGISTRO):
        return {}
    registros = {}
    try:
        with open(RUTA_CSV_REGISTRO, mode="r", encoding="utf-8") as f:
            lector = csv.DictReader(f)
            for fila in lector:
                k = f"{fila['grado']}::{fila['archivo_original']}"
                registros[k] = fila
    except Exception:
        pass
    return registros
