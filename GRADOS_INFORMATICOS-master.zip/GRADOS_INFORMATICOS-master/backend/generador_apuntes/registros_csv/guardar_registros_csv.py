import os
import csv

from backend.generador_apuntes._comun import DIRECTORIO_DATOS, RUTA_CSV_REGISTRO, CABECERAS_CSV

def guardar_registros_csv(registros):
    """Guarda el CSV de registro centralizado."""
    os.makedirs(DIRECTORIO_DATOS, exist_ok=True)
    with open(RUTA_CSV_REGISTRO, mode="w", newline="", encoding="utf-8") as f:
        escritor = csv.DictWriter(f, fieldnames=CABECERAS_CSV)
        escritor.writeheader()
        for r in registros.values():
            escritor.writerow(r)
