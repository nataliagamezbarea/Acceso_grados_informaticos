"""Paquete generador_apuntes: dividido en módulos por responsabilidad para que ningún
archivo sea excesivamente largo. Este __init__ re-exporta todo lo público exactamente
igual que antes, así que el resto del proyecto (`from backend.generador_apuntes import X`
o `from backend import generador_apuntes as gen`) sigue funcionando sin cambios.

- _comun: imports compartidos y constantes (rutas, paletas, plantillas de título/lista/tabla)
- registros_csv: nombres de apuntes, registro CSV central y CSVs por grado, commits git
- latex_estilo: paquetes LaTeX, escape de texto, títulos/listas/tablas deterministas
- transformacion_txt: conversión del TXT estructurado del apunte a código LaTeX
- compilacion: borrador -> .tex -> PDF, y preparación/entrega de apuntes
"""
from ._comun import (
    RUTA_CSV_REGISTRO, PLANTILLA_LATEX_MAESTRA, DIRECTORIO_BIBLIOTECAS_LATEX,
    DIRECTORIO_LATEX_BASE, RUTA_ESTILO_LATEX, DIRECTORIO_PAQUETES_LATEX,
    PAQUETES_LATEX_REQUERIDOS, CABECERAS_CSV,
    PALETA_ALEATORIA, TITULOS_ALEATORIOS, TITULOS_LETRAS, TITULOS_DOS_ARGS,
    VINETAS_ALEATORIAS, TABLAS_ALEATORIAS, ANCHO_MAX_VERBATIM,
)
from .registros_csv import (
    _commit_git_grado, limpiar_nombre_apunte, generar_propuesta_nombre_apunte,
    obtener_registros_csv, guardar_registros_csv, actualizar_csvs_del_grado,
    sincronizar_registro_csv, restaurar_csvs_del_grado,
)
from .latex_estilo import (
    asegurar_paquetes_latex, obtener_directorio_latex_base, escapar_caracteres_latex,
    seleccionar_letra_titulo, construir_titulo_principal, elegir_aleatorio,
    construir_titulo_aleatorio, construir_lista_aleatoria, construir_tabla_aleatoria,
    obtener_ruta_estilo_entrada,
)
from .transformacion_txt import (
    _envolver_linea_verbatim, _celdas_fila_tabla_markdown, transformar_txt_a_latex,
)
from .compilacion import (
    resolver_ruta_txt_apunte, crear_borrador_apunte, compilar_apunte_pdf,
    _leer_pdf_original_robusto, preparar_apunte, compilar_todos_los_apuntes,
    _generar_latex_del_apunte,
)
