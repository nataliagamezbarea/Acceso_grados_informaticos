import re

def escapar_caracteres_latex(texto):
    """Escapa caracteres especiales de LaTeX en texto plano."""
    if not texto: return ""
    caracteres = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}"
    }
    patron = re.compile("|".join(re.escape(k) for k in caracteres.keys()))
    texto = patron.sub(lambda m: caracteres[m.group(0)], texto)
    texto = re.sub(r"\*\*(.+?)\*\*", r"\\textbf{\1}", texto)
    texto = re.sub(r"\*(.+?)\*", r"\\textit{\1}", texto)
    texto = re.sub(r"`(.+?)`", r"\\texttt{\1}", texto)
    return texto
