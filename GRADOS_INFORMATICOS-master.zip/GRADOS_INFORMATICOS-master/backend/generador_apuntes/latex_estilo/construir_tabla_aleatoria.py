from backend.generador_apuntes.latex_estilo._constantes import TABLAS_ALEATORIAS

def construir_tabla_aleatoria(columnas):
    """Devuelve un entorno de tabla determinista para renderizar contenido."""
    tipo = TABLAS_ALEATORIAS[0]
    if tipo == "tablaminimal":
        return f"\\begin{{tablaminimal}}{{{columnas}}}", "\\end{tablaminimal}"
    if tipo == "tablacabecera":
        return f"\\begin{{tablacabecera}}{{{columnas}}}", "\\end{tablacabecera}"
    return f"\\begin{{tablacuadricula}}{{|{columnas}|}}", "\\end{tablacuadricula}"
