import os

from backend.generador_apuntes._comun import DIRECTORIO_BIBLIOTECAS_LATEX, DIRECTORIO_BASE

def obtener_directorio_latex_base():
    """Devuelve la carpeta de estilos LaTeX activa del proyecto."""
    candidatos = [
        DIRECTORIO_BIBLIOTECAS_LATEX,
        os.path.join(DIRECTORIO_BASE, "latex")
    ]
    for directorio in candidatos:
        if os.path.isdir(directorio):
            return directorio
    return os.path.join(DIRECTORIO_BASE, "latex")
