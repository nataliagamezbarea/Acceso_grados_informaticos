def obtener_ruta_estilo_entrada(nombre_grado=""):
    """Devuelve el nombre del estilo LaTeX para \\input. La resolución real la hace
    xelatex vía TEXINPUTS (compilar_apunte_pdf añade bibliotecas_latex), de modo que
    funciona sin importar dónde esté NUEVOS_APUNTES."""
    return "estilo.tex"
