from backend.generador_apuntes._comun import TITULOS_ALEATORIOS
from backend.generador_apuntes.latex_estilo.escapar_caracteres_latex import escapar_caracteres_latex

def construir_titulo_aleatorio(titulo, subtitulo="", categoria="primaria"):
    """Construye un comando de título de forma determinista según la categoría."""
    titulo = escapar_caracteres_latex(titulo)
    subtitulo = escapar_caracteres_latex(subtitulo or titulo)
    opciones = TITULOS_ALEATORIOS.get(categoria, TITULOS_ALEATORIOS["primaria"])
    patron = opciones[0]
    if "{1}" in patron and not subtitulo:
        subtitulo = titulo
    if "{1}" in patron:
        return patron.format(titulo, subtitulo)
    return patron.format(titulo)
