VINETAS_ALEATORIAS = {
    "primaria": [
        ("\\begin{estrellalist}", "\\end{estrellalist}"),
        ("\\begin{bulletlist}", "\\end{bulletlist}"),
        ("\\begin{flechalist}", "\\end{flechalist}"),
        ("\\begin{marcalist}", "\\end{marcalist}"),
    ],
    "secundaria": [
        ("\\begin{alertalist}", "\\end{alertalist}"),
        ("\\begin{preguntalist}", "\\end{preguntalist}"),
        ("\\begin{letralist}", "\\end{letralist}"),
        ("\\begin{tarealist}", "\\end{tarealist}"),
    ],
}

TABLAS_ALEATORIAS = [
    "tablaminimal",
    "tablacabecera",
    "tablacuadricula",
]
