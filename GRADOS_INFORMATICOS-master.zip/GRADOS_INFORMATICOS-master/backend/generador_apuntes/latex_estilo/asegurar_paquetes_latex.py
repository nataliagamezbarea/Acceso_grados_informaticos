import shutil
import subprocess

from backend.generador_apuntes._comun import PAQUETES_LATEX_REQUERIDOS
from backend.generador_apuntes import _comun

def asegurar_paquetes_latex():
    """Comprueba que los .sty requeridos existen y los instala con tlmgr si faltan."""
    if _comun._paquetes_verificados or not shutil.which("kpsewhich"):
        return
    faltantes = []
    for sty, paquete in PAQUETES_LATEX_REQUERIDOS.items():
        try:
            r = subprocess.run(["kpsewhich", f"{sty}.sty"], capture_output=True, timeout=20)
            if r.returncode != 0 or not r.stdout.strip():
                faltantes.append(paquete)
        except Exception:
            return
    _comun._paquetes_verificados = True
    if faltantes and shutil.which("tlmgr"):
        try:
            subprocess.run(["tlmgr", "install", *sorted(set(faltantes))], capture_output=True, timeout=300)
        except Exception:
            pass
