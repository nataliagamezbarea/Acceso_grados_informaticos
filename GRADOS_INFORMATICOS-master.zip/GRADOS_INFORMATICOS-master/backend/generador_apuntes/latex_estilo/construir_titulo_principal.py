from backend.generador_apuntes._comun import TITULOS_LETRAS, TITULOS_DOS_ARGS
from backend.generador_apuntes.latex_estilo.escapar_caracteres_latex import escapar_caracteres_latex
from backend.generador_apuntes.latex_estilo.seleccionar_letra_titulo import seleccionar_letra_titulo

def construir_titulo_principal(titulo, subtitulo=""):
    """Construye el comando \\tituloX del título principal usando los 17 estilos de la biblioteca."""
    letra = seleccionar_letra_titulo(titulo)
    titulo_esc = escapar_caracteres_latex(titulo)
    if letra in TITULOS_DOS_ARGS:
        subtitulo_esc = escapar_caracteres_latex(subtitulo or titulo)
        return f"\\titulo{letra}{{{titulo_esc}}}{{{subtitulo_esc}}}"
    return f"\\titulo{letra}{{{titulo_esc}}}"
