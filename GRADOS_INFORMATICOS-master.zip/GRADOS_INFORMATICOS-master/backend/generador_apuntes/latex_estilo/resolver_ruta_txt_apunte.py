import os

from backend.generador_apuntes._comun import DIRECTORIO_NUEVOS_APUNTES, DIRECTORIO_BASE
from backend.generador_apuntes.registros_csv import limpiar_nombre_apunte

def resolver_ruta_txt_apunte(grado, nombre_apunte, archivo_original=None):
    """Resuelve la ruta del TXT que debe usarse como origen del apunte."""
    nombre_apunte = limpiar_nombre_apunte(nombre_apunte)
    dir_destino = os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado)
    rutas = []

    if archivo_original:
        rutas.append(os.path.abspath(archivo_original))
        rutas.append(os.path.join(DIRECTORIO_BASE, archivo_original))
        rutas.append(os.path.join(dir_destino, os.path.basename(archivo_original)))

    rutas.append(os.path.join(dir_destino, f"{nombre_apunte}.txt"))
    rutas.append(os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado, f"{nombre_apunte}.txt"))

    for ruta in rutas:
        if ruta and os.path.exists(ruta):
            return ruta
    return os.path.join(dir_destino, f"{nombre_apunte}.txt")
