from backend.generador_apuntes.latex_estilo._constantes import VINETAS_ALEATORIAS

def construir_lista_aleatoria(categoria="primaria"):
    """Devuelve el inicio y cierre deterministas de una lista según la categoría."""
    opciones = VINETAS_ALEATORIAS.get(categoria, VINETAS_ALEATORIAS["primaria"])
    return opciones[0]
