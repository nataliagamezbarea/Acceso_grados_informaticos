import random

def elegir_aleatorio(lista):
    """Devuelve un valor aleatorio de una lista no vacía."""
    if not lista:
        return ""
    return random.choice(lista)
