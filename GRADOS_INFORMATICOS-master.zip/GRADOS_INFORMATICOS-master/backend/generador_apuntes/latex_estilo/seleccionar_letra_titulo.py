import hashlib

from backend.generador_apuntes._comun import TITULOS_LETRAS

def seleccionar_letra_titulo(texto):
    """Selecciona un estilo de título A-Q de forma determinista según el texto."""
    indice = int(hashlib.md5(texto.encode("utf-8")).hexdigest(), 16) % len(TITULOS_LETRAS)
    return TITULOS_LETRAS[indice]
