import os
import json
import urllib.parse
from backend.gestor_datos import construir_datos_visor, leer_archivo_original
from backend.procesador_pdf import (
    obtener_previsualizacion, obtener_informacion_documento,
    generar_miniatura_bytes, extraer_texto_de_recuadro
)

def manejar_doc_info(manejador, ruta, query, bloqueo=None):
    partes = ruta.split("/")
    g = partes[3]
    q = urllib.parse.parse_qs(query)
    archivo = urllib.parse.unquote(q.get("archivo", [""])[0])
    modo = q.get("mode", q.get("modo", ["old"]))[0]
    hacer_enc = (q.get("enc", ["1"])[0] == "1")
    hacer_int = (q.get("int", ["1"])[0] == "1")
    hacer_col = (q.get("col", ["1"])[0] == "1")
    hacer_net = (q.get("net", ["0"])[0] == "1")
    info = obtener_informacion_documento(g, archivo, modo, hacer_enunciado=hacer_enc, hacer_interior=hacer_int, hacer_colegio=hacer_col, hacer_internet=hacer_net)
    manejador.enviar_respuesta_datos(200, "application/json; charset=utf-8", json.dumps(info).encode("utf-8"))

def manejar_previsualizacion(manejador, ruta, query, bloqueo=None):
    partes = ruta.split("/")
    g = partes[3]
    q = urllib.parse.parse_qs(query)
    archivo = urllib.parse.unquote(q.get("archivo", [""])[0])
    modo = q.get("mode", q.get("modo", ["old"]))[0]
    hacer_enc = (q.get("enc", ["1"])[0] == "1")
    hacer_int = (q.get("int", ["1"])[0] == "1")
    hacer_col = (q.get("col", ["1"])[0] == "1")
    hacer_net = (q.get("net", ["0"])[0] == "1")
    es_descarga = (q.get("download", ["0"])[0] == "1")
    nombre_descarga = os.path.basename(archivo) or "documento.pdf"
    cabeceras_extra = [("Content-Disposition", f'attachment; filename="{nombre_descarga}"')] if es_descarga else None

    if modo == "old":
        datos = leer_archivo_original(g, archivo)
        if datos:
            manejador.enviar_respuesta_datos(200, "application/pdf", bytes(datos), cabeceras_extra=cabeceras_extra)
        else:
            manejador.enviar_respuesta_datos(404, "text/plain", b"no")
        return
    datos_p = obtener_previsualizacion(g, archivo, modo, hacer_enunciado=hacer_enc, hacer_interior=hacer_int, hacer_colegio=hacer_col, hacer_internet=hacer_net)
    if datos_p:
        manejador.enviar_respuesta_datos(200, "application/pdf", datos_p, cabeceras_extra=cabeceras_extra)
    else:
        manejador.enviar_respuesta_datos(404, "text/plain", b"no")



def manejar_miniatura(manejador, ruta, query="", bloqueo=None):
    partes = ruta.split("/")
    if len(partes) >= 4:
        g = partes[3]
        archivo = None
        if query:
            q = urllib.parse.parse_qs(query)
            archivo = urllib.parse.unquote(q.get("archivo", [""])[0])
        if not archivo and len(partes) >= 5:
            try:
                idx = int(partes[4])
                datos, _ = construir_datos_visor()
                d = datos.get(g)
                if d:
                    if 0 <= idx < len(d.get("entries", [])):
                        archivo = d["entries"][idx]["archivo"]
                    else:
                        idx_no = idx - len(d.get("entries", []))
                        if 0 <= idx_no < len(d.get("no_cambian", [])):
                            archivo = d["no_cambian"][idx_no]["archivo"]
            except Exception:
                pass
        if archivo:
            png = generar_miniatura_bytes(g, archivo)
            if png:
                manejador.enviar_respuesta_datos(200, "image/png", png)
                return
    manejador.enviar_respuesta_datos(404, "text/plain", b"no")

def manejar_ver_apunte(manejador, ruta, query):
    """Sirve el PDF del APUNTE compilado (NUEVOS_APUNTES/<grado>/<nombre>.pdf).
    Así, al volver atrás a un archivo cuyo apunte ya está hecho (check Apunte +
    LaTeX compilado), el visor permite abrir el apunte directamente."""
    q = urllib.parse.parse_qs(query)
    nombre = os.path.basename(urllib.parse.unquote(q.get("nombre", [""])[0]))
    grado = ruta.split("/")[3]
    if not nombre:
        manejador.enviar_respuesta_datos(404, "text/plain", b"no")
        return
    from backend.configuracion import DIRECTORIO_NUEVOS_APUNTES
    p = os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado, f"{nombre}.pdf")
    # Defensa path-traversal: el resolved debe seguir dentro de NUEVOS_APUNTES/<grado>
    base = os.path.realpath(os.path.join(DIRECTORIO_NUEVOS_APUNTES, grado))
    if not os.path.realpath(p).startswith(base) or not os.path.exists(p):
        manejador.enviar_respuesta_datos(404, "text/plain", b"no")
        return
    manejador.enviar_respuesta_datos(200, "application/pdf", open(p, "rb").read())

def manejar_extraer_texto_recuadro(manejador, cuerpo):
    txt = extraer_texto_de_recuadro(
        cuerpo["grado"], cuerpo["archivo"], int(cuerpo.get("page_num", 0)),
        cuerpo.get("left", 0), cuerpo.get("top", 0),
        cuerpo.get("width", 0), cuerpo.get("height", 0)
    )
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True, "text": txt}).encode("utf-8"))
