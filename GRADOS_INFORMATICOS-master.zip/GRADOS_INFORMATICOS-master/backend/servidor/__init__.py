import sys
import http.server
from backend.configuracion import DIRECTORIO_GI, DIRECTORIO_BACKUPS
from backend.gestor_datos import respaldar_todos_los_originales_al_iniciar
from backend.servidor.manejador_peticiones import ManejadorPeticiones

class ServidorReutilizable(http.server.ThreadingHTTPServer):
    allow_reuse_address = True
    def server_bind(self):
        import socket
        # SOLO SO_REUSEADDR. NUNCA SO_REUSEPORT: con él, dos copias del visor
        # podían abrirse a la vez en el mismo puerto y repartirse las peticiones,
        # corrompiendo la caché mutuamente (PDFs truncados, 'expected object
        # number', sustituciones que aparecían y desaparecían). Ahora, si ya hay
        # otro visor en este puerto, este segundo proceso FALLA de forma visible.
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        super().server_bind()

def iniciar_servidor(puerto_defecto=8080):
    puerto = puerto_defecto
    if len(sys.argv) > 1:
        try:
            puerto = int(sys.argv[1])
        except ValueError:
            pass

    respaldados = respaldar_todos_los_originales_al_iniciar()
    print(f"[INFO] Directorio de Grados: {DIRECTORIO_GI}")
    print(f"[INFO] Copias de seguridad automáticas: {respaldados} nuevas en {DIRECTORIO_BACKUPS}")

    # PURGA DE IMÁGENES DE CACHÉ: el visor renderiza NATIVO con pdf.js desde
    # el PDF, así que la caché NO debe guardar PNGs. Al arrancar se eliminan
    # los restos antiguos; de ahora en adelante solo se guardan PDFs 'new'.
    try:
        from backend.procesador_pdf.renderizado_cache import purgar_imagenes_cache
        borradas = purgar_imagenes_cache()
        if borradas:
            print(f"[INFO] Caché: {borradas} imágenes antiguas eliminadas (solo PDFs 'new' a partir de ahora)")
    except Exception as e:
        print(f"[WARN] No se pudieron purgar las imágenes de caché: {e}")

    ServidorReutilizable.allow_reuse_address = True
    try:
        servidor = ServidorReutilizable(("0.0.0.0", puerto), ManejadorPeticiones)
    except OSError as e:
        print(f"\n[ERROR] El puerto {puerto} ya está ocupado ({e}).")
        print("        Seguramente queda OTRO visor abierto: ciérralo antes")
        print("        (busca procesos 'python' antiguos o reinicia el equipo).")
        raise SystemExit(1)
    print(f"[INFO] Visor disponible en: http://localhost:{puerto} (Ctrl+C para detener)")
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\n[INFO] Servidor detenido.")

