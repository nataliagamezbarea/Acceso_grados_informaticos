from backend.servidor.api_sistema import cache_esta_desactivada

def enviar_respuesta_datos(self, codigo, tipo_contenido, datos, cabeceras_extra=None):
    try:
        self.send_response(codigo)
        self.send_header("Content-Type", tipo_contenido)
        self.send_header("Content-Length", str(len(datos)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
        self.send_header("Access-Control-Allow-Headers", "*")
        if cabeceras_extra:
            for k, v in cabeceras_extra:
                self.send_header(k, v)
        if cache_esta_desactivada():
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")

        self.end_headers()
        self.wfile.write(datos)
    except (BrokenPipeError, ConnectionResetError):
        # El navegador cerró la conexión antes de recibir la respuesta
        # (p.ej. recarga de página a mitad de una carga larga): no es un error.
        pass

