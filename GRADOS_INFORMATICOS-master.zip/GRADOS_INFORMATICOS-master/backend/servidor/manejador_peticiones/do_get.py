import json

def do_GET(self):
    try:
        self._do_GET_internal()
    except Exception as e:
        import traceback
        traceback.print_exc()
        try:
            self.enviar_respuesta_datos(500, "application/json; charset=utf-8", json.dumps({"ok": False, "error": str(e)}).encode("utf-8"))
        except Exception:
            pass
