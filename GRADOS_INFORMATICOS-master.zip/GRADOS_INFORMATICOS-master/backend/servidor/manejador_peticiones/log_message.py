def log_message(self, format, *args):
    pass
