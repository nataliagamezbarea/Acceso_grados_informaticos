import os
import json
import urllib.parse
from backend.configuracion import DIRECTORIO_ESTATICOS
from backend.servidor.api_sistema import (
    manejar_datos_visor, manejar_get_estado_cache, cache_esta_desactivada
)
from backend.servidor.api_documentos import (
    manejar_miniatura, manejar_doc_info, manejar_previsualizacion, manejar_ver_apunte
)
from backend.servidor.manejador_peticiones._constantes import _bloqueo

def _do_GET_internal(self):
    u = urllib.parse.urlparse(self.path)
    ruta = u.path

    if ruta == "/favicon.ico":
        self.enviar_respuesta_datos(204, "image/x-icon", b"")
        return


    if ruta in ["/login", "/login.html"]:

        ruta_login = os.path.join(DIRECTORIO_ESTATICOS, "paginas", "login.html")
        if os.path.exists(ruta_login):
            self.enviar_respuesta_datos(200, "text/html; charset=utf-8", open(ruta_login, "rb").read())
            return

    if ruta == "/" or ruta == "/index.html":
        plantilla_html = os.path.join(DIRECTORIO_ESTATICOS, "index.html")
        if os.path.exists(plantilla_html):
            self.enviar_respuesta_datos(200, "text/html; charset=utf-8", open(plantilla_html, "rb").read())
        else:
            self.enviar_respuesta_datos(404, "text/plain", b"Plantilla index.html no encontrada")
        return


    if ruta.startswith("/static/") or ruta.startswith("/estaticos/"):
        subruta = ruta.replace("/static/", "").replace("/estaticos/", "")
        ruta_estatico = os.path.join(DIRECTORIO_ESTATICOS, subruta)
        if os.path.exists(ruta_estatico) and not os.path.isdir(ruta_estatico):
            tipo_mime = "text/plain"
            if ruta.endswith(".css"): tipo_mime = "text/css"
            elif ruta.endswith(".js"): tipo_mime = "application/javascript"
            elif ruta.endswith(".png"): tipo_mime = "image/png"
            self.enviar_respuesta_datos(200, tipo_mime, open(ruta_estatico, "rb").read())
            return

    if ruta in ["/api/config"]:
        from backend.servidor.manejador_peticiones.api_config import manejar_config
        manejar_config(self)
        return

    if ruta in ["/api/ramas", "/api/branches"]:
        from backend.servidor.api_github import manejar_listar_ramas
        manejar_listar_ramas(self)
        return

    if ruta in ["/api/github_pull", "/api/pull"]:
        from backend.servidor.api_github import manejar_github_pull
        manejar_github_pull(self)
        return

    if ruta in ["/api/data", "/api/datos"]:
        manejar_datos_visor(self, _bloqueo)
        return

    if ruta in ["/api/cache_estado", "/api/cache_state"]:
        manejar_get_estado_cache(self)
        return

    if ruta.startswith("/api/thumb/") or ruta.startswith("/api/miniatura/"):
        manejar_miniatura(self, ruta, u.query, _bloqueo)
        return

    if ruta.startswith("/api/doc_info/") or ruta.startswith("/api/info_doc/"):
        manejar_doc_info(self, ruta, u.query, _bloqueo)
        return

    if ruta.startswith("/api/page_image/") or ruta.startswith("/api/imagen_pagina/"):
        self.enviar_respuesta_datos(410, "text/plain", b"Eliminado: render nativo PDF.js")
        return

    if ruta.startswith("/api/preview/") or ruta.startswith("/api/previsualizar/"):
        manejar_previsualizacion(self, ruta, u.query, _bloqueo)
        return

    if ruta.startswith("/api/apunte_pdf/"):
        manejar_ver_apunte(self, ruta, u.query)
        return

    if ruta.startswith("/api/estado_compilacion") or ruta.startswith("/api/estado_compile"):
        from backend.servidor.api_acciones.apuntes.manejar_estado_compilacion import manejar_estado_compilacion
        manejar_estado_compilacion(self, ruta, u.query, _bloqueo)
        return

    # Servir archivos estáticos del frontend (html, css, js, png, svg, etc.)
    sub = ruta.lstrip("/")
    if not sub:
        sub = "index.html"
    ruta_estatico = os.path.join(DIRECTORIO_ESTATICOS, sub)
    if os.path.isfile(ruta_estatico):
        tipo_mime = "text/plain"
        if sub.endswith(".html"): tipo_mime = "text/html; charset=utf-8"
        elif sub.endswith(".css"): tipo_mime = "text/css"
        elif sub.endswith(".js"): tipo_mime = "application/javascript"
        elif sub.endswith(".png"): tipo_mime = "image/png"
        elif sub.endswith(".jpg") or sub.endswith(".jpeg"): tipo_mime = "image/jpeg"
        elif sub.endswith(".svg"): tipo_mime = "image/svg+xml"
        elif sub.endswith(".json"): tipo_mime = "application/json"
        elif sub.endswith(".pdf"): tipo_mime = "application/pdf"
        self.enviar_respuesta_datos(200, tipo_mime, open(ruta_estatico, "rb").read())
        return

    self.enviar_respuesta_datos(404, "text/plain", b"No encontrado")

