import http.server
from backend.servidor.manejador_peticiones._constantes import _bloqueo
from backend.servidor.manejador_peticiones.log_message import log_message
from backend.servidor.manejador_peticiones.do_get import do_GET
from backend.servidor.manejador_peticiones._do_get_internal import _do_GET_internal
from backend.servidor.manejador_peticiones.do_post import do_POST
from backend.servidor.manejador_peticiones._do_post_internal import _do_POST_internal
from backend.servidor.manejador_peticiones.enviar_respuesta_datos import enviar_respuesta_datos

class ManejadorPeticiones(http.server.BaseHTTPRequestHandler):
    log_message = log_message
    do_GET = do_GET
    _do_GET_internal = _do_GET_internal
    do_POST = do_POST
    _do_POST_internal = _do_POST_internal
    enviar_respuesta_datos = enviar_respuesta_datos
