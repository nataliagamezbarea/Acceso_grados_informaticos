import threading

_bloqueo = threading.Lock()
