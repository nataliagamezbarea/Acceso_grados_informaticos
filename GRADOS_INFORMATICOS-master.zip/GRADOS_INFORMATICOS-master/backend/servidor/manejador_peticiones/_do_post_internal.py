import json
import urllib.parse
from backend.servidor.api_sistema import (
    manejar_purgar_reales, manejar_aplicar_rama, manejar_aplicar_un_archivo,
    manejar_reiniciar_servidor, manejar_set_estado_cache
)
from backend.servidor.api_documentos import (
    manejar_doc_info, manejar_previsualizacion, manejar_miniatura,
    manejar_ver_apunte, manejar_extraer_texto_recuadro
)
from backend.servidor.api_acciones import (
    manejar_inclusion, manejar_renombre, manejar_interior,
    manejar_colegio, manejar_recuadro, manejar_internet, manejar_apunte,
    manejar_compilar_apunte, manejar_compilar_todos_apuntes,
    manejar_visto, manejar_guardar_enunciado, manejar_eliminar_enunciado,
    manejar_restaurar_contenido, manejar_restaurar_nombre, manejar_reset_item,
    manejar_image_action, manejar_upload_image, manejar_check_image_internet,
    manejar_clear_image_actions, manejar_limpiar_datos_revision,
    manejar_update_flags, manejar_quitar_manual, manejar_set_decision
)

from backend.servidor.manejador_peticiones._constantes import _bloqueo

def _do_POST_internal(self):
    u = urllib.parse.urlparse(self.path)
    ruta = u.path
    longitud = int(self.headers.get("Content-Length", 0))
    cuerpo = json.loads(self.rfile.read(longitud)) if longitud > 0 else {}

    rutas_post = {
        "/api/include": manejar_inclusion,
        "/api/incluir": manejar_inclusion,
        "/api/inclusion": manejar_inclusion,
        "/api/renombre": manejar_renombre,
        "/api/renombrar": manejar_renombre,
        "/api/interior": manejar_interior,
        "/api/colegio": manejar_colegio,
        "/api/recuadro": manejar_recuadro,
        "/api/box_geometry": manejar_recuadro,
        "/api/internet": manejar_internet,
        "/api/apunte": manejar_apunte,
        "/api/compile_apunte": manejar_compilar_apunte,
        "/api/compilar_apunte": manejar_compilar_apunte,
        "/api/compile_all_apuntes": manejar_compilar_todos_apuntes,
        "/api/compilar_todos_apuntes": manejar_compilar_todos_apuntes,
        "/api/visto": manejar_visto,
        "/api/guardar_enunciado": manejar_guardar_enunciado,
        "/api/save_enunciado": manejar_guardar_enunciado,
        "/api/eliminar_enunciado": manejar_eliminar_enunciado,
        "/api/delete_enunciado": manejar_eliminar_enunciado,
        "/api/restaurar_contenido": manejar_restaurar_contenido,
        "/api/restore_content": manejar_restaurar_contenido,
        "/api/restaurar_nombre": manejar_restaurar_nombre,
        "/api/restore_name": manejar_restaurar_nombre,
        "/api/restablecer_item": manejar_reset_item,
        "/api/reset_item": manejar_reset_item,
        "/api/image_action": manejar_image_action,
        "/api/upload_image": manejar_upload_image,
        "/api/check_image_internet": manejar_check_image_internet,
        "/api/clear_image_actions": manejar_clear_image_actions,
        "/api/purgar_reales": manejar_purgar_reales,
        "/api/purge_reales": manejar_purgar_reales,
        "/api/aplicar": manejar_aplicar_rama,
        "/api/apply": manejar_aplicar_rama,
        "/api/aplicar_un_archivo": manejar_aplicar_un_archivo,
        "/api/apply_single_file": manejar_aplicar_un_archivo,
        "/api/apply_single_real": manejar_aplicar_un_archivo,
        "/api/restart_server": manejar_reiniciar_servidor,
        "/api/reiniciar_servidor": manejar_reiniciar_servidor,
        "/api/toggle_cache": manejar_set_estado_cache,
        "/api/cache_toggle": manejar_set_estado_cache,
        "/api/github_pull": lambda m, c, b: __import__('backend.servidor.api_github', fromlist=['manejar_github_pull']).manejar_github_pull(m),
        "/api/github_crear_archivo": lambda m, c, b: __import__('backend.servidor.api_github', fromlist=['manejar_github_crear_modificar']).manejar_github_crear_modificar(m, c),
        "/api/github_modificar_archivo": lambda m, c, b: __import__('backend.servidor.api_github', fromlist=['manejar_github_crear_modificar']).manejar_github_crear_modificar(m, c),
        "/api/github_eliminar_archivo": lambda m, c, b: __import__('backend.servidor.api_github', fromlist=['manejar_github_eliminar']).manejar_github_eliminar(m, c),
        "/api/limpiar_datos_revision": manejar_limpiar_datos_revision,
        "/api/clean_revision_data": manejar_limpiar_datos_revision,
        "/api/update_flags": manejar_update_flags,
        "/api/quitar_manual": manejar_quitar_manual,
        "/api/remove_manual": manejar_quitar_manual,
        "/api/set_decision": manejar_set_decision,
    }



    if ruta in rutas_post:
        rutas_post[ruta](self, cuerpo, _bloqueo)
        return

    if ruta == "/api/extract_box_text":
        manejar_extraer_texto_recuadro(self, cuerpo)
        return

    self.enviar_respuesta_datos(404, "text/plain", b"No encontrado")
