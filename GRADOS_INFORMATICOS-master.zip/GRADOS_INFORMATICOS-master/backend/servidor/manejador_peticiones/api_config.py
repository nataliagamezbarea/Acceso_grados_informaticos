import os
import json

_RUTAS_ENV = (
    "/home/natalia/Escritorio/repositorios/Privados/GRADOS_INFORMATICOS-LOGIN/.env",
    "/home/natalia/Escritorio/repositorios/Privados/GRADOS_INFORMATICOS-LOGIN/../.env",
)

def _leer_env_var(nombre_clave, por_defecto=""):
    valor = os.environ.get(nombre_clave, "")
    if valor:
        return valor
    for ruta in _RUTAS_ENV:
        ruta = os.path.abspath(ruta)
        if os.path.exists(ruta):
            try:
                with open(ruta, "r", encoding="utf-8") as f:
                    for linea in f:
                        linea = linea.strip()
                        if linea and not linea.startswith("#") and linea.startswith(nombre_clave + "="):
                            return linea.split("=", 1)[1].strip()
            except Exception:
                continue
    return por_defecto

def manejar_config(manejador):
    # Solo datos publicables para el navegador. El repo/token del ADMIN
    # permanecen en backend y se consultan desde configuracion_privada.
    config = {
        "SUPABASE_URL": _leer_env_var("SUPABASE_URL"),
        "SUPABASE_ANON_KEY": _leer_env_var("SUPABASE_ANON_KEY"),
    }
    manejador.enviar_respuesta_datos(
        200,
        "application/json; charset=utf-8",
        json.dumps(config).encode("utf-8"),
    )
