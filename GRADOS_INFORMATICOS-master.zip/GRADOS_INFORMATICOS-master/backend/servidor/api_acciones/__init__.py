from .enunciados import *
from .flags_recuadros import *
from .imagenes import *
from .apuntes import *
from .restauracion_sistema import *
