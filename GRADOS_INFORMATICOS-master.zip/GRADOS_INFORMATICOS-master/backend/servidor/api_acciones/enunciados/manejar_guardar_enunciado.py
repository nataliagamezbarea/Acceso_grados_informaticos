import json
import os
from backend.gestor_datos import guardar_enunciado_personalizado, cargar_reescrituras, guardar_reescrituras
from backend.procesador_pdf import limpiar_cache_pdf

def manejar_guardar_enunciado(manejador, cuerpo, bloqueo):
    with bloqueo:
        # Guardar la imagen del enunciado personalizado
        ok = guardar_enunciado_personalizado(
            cuerpo["grado"], cuerpo["archivo"],
            cuerpo.get("start", ""), cuerpo.get("end", ""), cuerpo.get("new_text", ""),
            page=cuerpo.get("page"), pct_top=cuerpo.get("pct_top")
        )
        
        # También guardar en el sistema de reescrituras para que el motor lo detecte
        grado = cuerpo["grado"]
        archivo = cuerpo["archivo"]
        start = cuerpo.get("start", "")
        end = cuerpo.get("end", "")
        new_text = cuerpo.get("new_text", "")
        es_custom = bool(cuerpo.get("custom", False))
        
        try:
            rw = cargar_reescrituras(grado)
            # Buscar si ya existe una entrada para este archivo
            encontrado = False
            for entry in rw:
                if os.path.basename(entry.get("archivo", "")) == archivo:
                    # Añadir el enunciado a la lista de enunciados
                    if "enunciados" not in entry:
                        entry["enunciados"] = []
                    
                    # Verificar si ya existe. Al editar, el texto original puede haber
                    # cambiado, así que usamos old_start como identidad antes de crear otro.
                    old_start = str(cuerpo.get("old_start", "") or "").strip()
                    page_in = cuerpo.get("page")
                    enunciado_existente = False
                    for enc in entry["enunciados"]:
                        misma_pagina = (page_in is None or enc.get("page") == page_in)
                        misma_identidad = (
                            (old_start and enc.get("start") == old_start) or
                            (enc.get("start") == start and enc.get("end", "") == end)
                        )
                        if misma_pagina and misma_identidad:
                            enc["start"] = start
                            enc["end"] = end
                            enc["new"] = new_text
                            enc["include"] = True
                            enc["page"] = page_in if page_in is not None else enc.get("page")
                            if cuerpo.get("pct_top") is not None:
                                enc["pct_top"] = cuerpo.get("pct_top")
                            enc["custom"] = bool(enc.get("custom", False) or es_custom)
                            enunciado_existente = True
                            break

                    if not enunciado_existente:
                        entry["enunciados"].append({
                            "start": start,
                            "end": end,
                            "new": new_text,
                            "include": True,
                            "page": page_in,
                            "pct_top": cuerpo.get("pct_top"),
                            "custom": es_custom
                        })
                    
                    encontrado = True
                    break
            
            if not encontrado:
                # Crear nueva entrada para este archivo
                rw.append({
                    "archivo": archivo,
                    "enunciados": [{
                        "start": start,
                        "end": end,
                        "new": new_text,
                        "include": True,
                        "page": cuerpo.get("page"),
                        "pct_top": cuerpo.get("pct_top"),
                        "custom": es_custom
                    }]
                })
            
            guardar_reescrituras(grado, rw)
        except Exception as e:
            print(f"Error guardando enunciado en reescrituras: {e}")
        
        # Limpiar caché para que la previsualización se regenere
        try:
            limpiar_cache_pdf(cuerpo["grado"], cuerpo["archivo"])
        except Exception:
            pass
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": ok}).encode("utf-8"))
