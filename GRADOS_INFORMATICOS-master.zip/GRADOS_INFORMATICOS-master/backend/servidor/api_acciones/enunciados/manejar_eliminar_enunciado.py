import json
import os
from backend.gestor_datos import eliminar_enunciado_personalizado, cargar_reescrituras, guardar_reescrituras
from backend.procesador_pdf import limpiar_cache_pdf

def manejar_eliminar_enunciado(manejador, cuerpo, bloqueo):
    grado = cuerpo.get("grado", "")
    archivo = cuerpo.get("archivo", "")
    start = cuerpo.get("start", "")
    end = cuerpo.get("end", "")
    es_custom = bool(cuerpo.get("custom", False))
    hid, pno = cuerpo.get("hotspot_id"), cuerpo.get("page")
    with bloqueo:
        ok = False
        try:
            rw = cargar_reescrituras(grado) or []
            entry = next((e for e in rw if os.path.basename(e.get("archivo", "")) == os.path.basename(archivo)), None)
            if entry:
                enuncs = entry.get("enunciados", [])
                nuevos = []
                for idx_e, e in enumerate(enuncs):
                    match = (hid is not None and idx_e == hid) or (e.get("start") == start and e.get("end") == end)
                    if not match and start:
                        st_e, st_c = str(e.get("start", "")).strip(), str(start).strip()
                        if st_e == st_c or st_c in st_e or st_e in st_c:
                            if pno is None or int(e.get("page", 0)) == int(pno): match = True
                    if match:
                        ok = True
                        if not (e.get("custom") or es_custom):
                            e_des = dict(e); e_des["include"] = False; e_des["new"] = ""; nuevos.append(e_des)
                    else: nuevos.append(e)
                entry["enunciados"] = nuevos
            if not ok and start:
                if not entry:
                    entry = {"archivo": archivo, "enunciados": []}
                    rw.append(entry)
                entry.setdefault("enunciados", []).append({
                    "start": start, "end": end, "new": "", "include": False, "page": int(pno or 0), "custom": es_custom
                })
                ok = True
            if ok: guardar_reescrituras(grado, rw)
        except Exception: pass
        eliminar_enunciado_personalizado(grado, archivo)
        try:
            limpiar_cache_pdf(grado, archivo)
        except Exception:
            pass
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True}).encode("utf-8"))
