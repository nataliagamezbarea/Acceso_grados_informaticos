from backend.gestor_datos import (
    cargar_revision, clave_registro, guardar_revision
)
from backend.procesador_pdf import limpiar_cache_pdf

def manejar_internet(manejador, cuerpo, bloqueo):
    rev = cargar_revision()
    k = clave_registro(cuerpo["grado"], cuerpo["archivo"])
    if k not in rev: rev[k] = {}
    rev[k]["inc_internet"] = bool(cuerpo.get("inc_internet", False))
    with bloqueo:
        guardar_revision(rev)
        limpiar_cache_pdf(cuerpo["grado"], cuerpo["archivo"])
    manejador.enviar_respuesta_datos(200, "application/json", b'{"ok":true}')
