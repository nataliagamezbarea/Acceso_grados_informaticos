from backend.gestor_datos import cargar_revision, clave_registro, guardar_revision

def manejar_visto(manejador, cuerpo, bloqueo):
    rev = cargar_revision()
    k = clave_registro(cuerpo["grado"], cuerpo["archivo"])
    if k not in rev: rev[k] = {}
    rev[k]["visto"] = bool(cuerpo["visto"])
    if "decision" in cuerpo:
        rev[k]["decision"] = cuerpo["decision"]
    with bloqueo:
        guardar_revision(rev)
    manejador.enviar_respuesta_datos(200, "application/json", b'{"ok":true}')
