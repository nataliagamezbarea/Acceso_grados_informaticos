from backend.gestor_datos import (
    cargar_revision, clave_registro, guardar_revision,
    guardar_estado_inclusion
)
from backend.procesador_pdf import limpiar_cache_pdf

# Mapeo campo corto -> clave en revision.json (None = gestor especial)
_CAMPO_A_CLAVE = {
    'int': 'inc_interior',
    'col': 'inc_colegio',
    'ren': 'inc_renombre',
    'internet': 'inc_internet',
    'apunte': 'inc_apunte',
    'nombre_apunte': 'nombre_apunte',
}

def manejar_update_flags(manejador, cuerpo, bloqueo):
    grado = cuerpo.get('grado', '')
    archivo = cuerpo.get('archivo', '')
    campo = cuerpo.get('campo', '')
    valor = bool(cuerpo.get('valor', True))

    if not grado or not archivo or campo not in _CAMPO_A_CLAVE and campo != 'inc':
        manejador.enviar_respuesta_datos(
            400, 'application/json', b'{"ok":false,"error":"parametros_invalidos"}'
        )
        return

    with bloqueo:
        if campo == 'inc':
            guardar_estado_inclusion(grado, archivo, valor)
        else:
            clave_json = _CAMPO_A_CLAVE[campo]
            rev = cargar_revision()
            k = clave_registro(grado, archivo)
            if k not in rev:
                rev[k] = {}
            rev[k][clave_json] = valor
            guardar_revision(rev)
        limpiar_cache_pdf(grado, archivo)

    manejador.enviar_respuesta_datos(200, 'application/json', b'{"ok":true}')
