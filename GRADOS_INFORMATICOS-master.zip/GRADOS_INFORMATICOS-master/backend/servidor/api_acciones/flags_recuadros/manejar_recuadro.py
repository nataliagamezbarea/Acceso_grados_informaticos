from backend.gestor_datos import (
    cargar_revision, clave_registro, guardar_revision
)
from backend.procesador_pdf import limpiar_cache_pdf

def manejar_recuadro(manejador, cuerpo, bloqueo):
    """Guarda recuadros de nombre, colegio o punto de inicio de reflujo."""
    rev = cargar_revision()
    k = clave_registro(cuerpo["grado"], cuerpo["archivo"])
    if k not in rev: rev[k] = {}
    tipo_raw = str(cuerpo.get("tipo", "")).lower()

    if tipo_raw == "reflujo":
        if cuerpo.get("eliminar"): rev[k].pop("inicio_reflujo", None)
        else:
            try:
                pn = int(cuerpo.get("page_num", 0))
                l, t, w, h = float(cuerpo.get("left", 0)), float(cuerpo.get("top", 0)), float(cuerpo.get("width", 0)), float(cuerpo.get("height", 0))
                if pn >= 0 and w > 0 and h > 0 and (l + t + w + h < 1000):
                    rev[k]["inicio_reflujo"] = {"page": pn, "left": round(l, 3), "top": round(t, 3), "width": round(w, 3), "height": round(h, 3)}
                else: rev[k].pop("inicio_reflujo", None)
            except Exception: rev[k].pop("inicio_reflujo", None)
        with bloqueo:
            guardar_revision(rev)
            limpiar_cache_pdf(cuerpo["grado"], cuerpo["archivo"])
        manejador.enviar_respuesta_datos(200, "application/json", b'{"ok":true}')
        return

    if tipo_raw in ("enunciado", "statement"):
        import os
        from backend.gestor_datos import cargar_reescrituras, guardar_reescrituras
        g, a, pno = cuerpo.get("grado", ""), cuerpo.get("archivo", ""), int(cuerpo.get("page_num", 0))
        nl, nt, nw, nh = round(float(cuerpo.get("left", 0)), 3), round(float(cuerpo.get("top", 0)), 3), round(float(cuerpo.get("width", 0)), 3), round(float(cuerpo.get("height", 0)), 3)
        txt, hid, st = str(cuerpo.get("text", "") or "").strip(), cuerpo.get("hotspot_id"), cuerpo.get("start")
        try:
            rw = cargar_reescrituras(g) or []
            item = next((e for e in rw if os.path.basename(e.get("archivo", "")) == os.path.basename(a)), None)
            if not item:
                item = {"archivo": a, "enunciados": []}
                rw.append(item)
            enuncs = item.setdefault("enunciados", [])
            tgt = None
            if hid is not None and isinstance(hid, int) and 0 <= hid < len(enuncs): tgt = enuncs[hid]
            elif st: tgt = next((e for e in enuncs if e.get("start") == st and int(e.get("page", 0)) == pno), None)
            if not tgt and enuncs: tgt = next((e for e in enuncs if int(e.get("page", 0)) == pno), None)
            if tgt:
                tgt.update({"left": nl, "top": nt, "width": nw, "height": nh, "pct_top": nt})
                if txt:
                    tgt["start"] = txt
                    tgt["old"] = txt
            else:
                enuncs.append({"start": txt, "new": "", "include": True, "page": pno, "pct_top": nt, "left": nl, "top": nt, "width": nw, "height": nh})
            with bloqueo:
                guardar_reescrituras(g, rw)
                limpiar_cache_pdf(g, a)
        except Exception: pass
        manejador.enviar_respuesta_datos(200, "application/json", b'{"ok":true}')
        return

    tipo = "colegio" if tipo_raw == "colegio" else "nombre"
    recuadros = rev[k].setdefault("recuadros", {})
    por_tipo = recuadros.setdefault(tipo, {})
    page_key = str(int(cuerpo.get("page_num", 0)))
    if cuerpo.get("eliminar") or cuerpo.get("accion") == "eliminar":
        por_tipo.pop(page_key, None)
    else:
        coords = [round(float(cuerpo.get("left", 0)), 3), round(float(cuerpo.get("top", 0)), 3),
                  round(float(cuerpo.get("width", 0)), 3), round(float(cuerpo.get("height", 0)), 3)]
        texto = str(cuerpo.get("text", "") or "").strip()
        anterior = por_tipo.get(page_key)
        ant_txt = str(anterior.get("text", "") or "").strip() if isinstance(anterior, dict) else ""
        por_tipo[page_key] = {"coords": coords, "text": texto or ant_txt}
    with bloqueo:
        guardar_revision(rev)
        limpiar_cache_pdf(cuerpo["grado"], cuerpo["archivo"])
    manejador.enviar_respuesta_datos(200, "application/json", b'{"ok":true}')
