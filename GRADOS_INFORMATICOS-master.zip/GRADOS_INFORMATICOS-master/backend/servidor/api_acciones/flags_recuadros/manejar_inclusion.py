from backend.gestor_datos import guardar_estado_inclusion, construir_datos_visor

def manejar_inclusion(manejador, cuerpo, bloqueo):
    # Acepta AMBOS nombres de campo ('include' e 'incluir'): el visor envía
    # 'incluir' y otras partes del sistema 'include'. Antes solo se leía
    # 'include' → excepción KeyError → el check de ENUNCIADOS NUNCA se
    # guardaba en rewrites_<grado>.json y al recargar aparecía desmarcado.
    incluir = bool(cuerpo.get("include", cuerpo.get("incluir", True)))
    
    # Obtener el nombre del archivo desde el índice
    grado = cuerpo["grado"]
    idx = int(cuerpo["idx"])
    datos, _ = construir_datos_visor()
    
    archivo = None
    if grado in datos:
        entries = datos[grado].get("entries", [])
        no_cambian = datos[grado].get("no_cambian", [])
        
        # Buscar en entries primero
        if idx < len(entries):
            archivo = entries[idx]["archivo"]
        else:
            # Buscar en no_cambian
            idx_no_cambian = idx - len(entries)
            if 0 <= idx_no_cambian < len(no_cambian):
                archivo = no_cambian[idx_no_cambian]["archivo"]
    
    if not archivo:
        manejador.enviar_respuesta_datos(400, "application/json", b'{"ok":false,"error":"archivo_no_encontrado"}')
        return
    
    with bloqueo:
        guardar_estado_inclusion(grado, archivo, incluir)
    manejador.enviar_respuesta_datos(200, "application/json", b'{"ok":true}')
