import json
from backend.gestor_datos import cargar_revision, clave_registro, guardar_revision
from backend.procesador_pdf import limpiar_cache_pdf


def manejar_set_decision(manejador, cuerpo, bloqueo):
    """Guarda de forma persistente la decisión tomada sobre un archivo
    ('applied', 'original' o vacío para quitar la marca) para que el check
    se mantenga aunque se recargue la página."""
    grado = cuerpo.get("grado", "")
    archivo = cuerpo.get("archivo", "")
    decision = cuerpo.get("decision") or ""

    if not grado or not archivo:
        manejador.enviar_respuesta_datos(400, "application/json", b'{"ok":false,"error":"parametros_invalidos"}')
        return

    with bloqueo:
        rev = cargar_revision()
        k = clave_registro(grado, archivo)
        if k not in rev:
            rev[k] = {}
        if decision:
            rev[k]["decision"] = decision
        else:
            rev[k].pop("decision", None)
        guardar_revision(rev)
        try:
            limpiar_cache_pdf(grado, archivo)
        except Exception:
            pass

    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True}).encode("utf-8"))
