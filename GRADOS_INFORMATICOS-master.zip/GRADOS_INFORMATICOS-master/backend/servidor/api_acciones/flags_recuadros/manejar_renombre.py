import os
from backend.gestor_datos import (
    cargar_revision, clave_registro, guardar_revision,
    limpiar_nombre_archivo
)
from backend.generador_apuntes import sincronizar_registro_csv

def manejar_renombre(manejador, cuerpo, bloqueo):
    rev = cargar_revision()
    k = clave_registro(cuerpo["grado"], cuerpo["archivo"])
    if k not in rev: rev[k] = {}
    rev[k]["inc_renombre"] = bool(cuerpo.get("inc_renombre", False))
    with bloqueo:
        guardar_revision(rev)
        sincronizar_registro_csv(cuerpo["grado"], cuerpo["archivo"], limpiar_nombre_archivo(cuerpo["archivo"]) if rev[k]["inc_renombre"] else os.path.basename(cuerpo["archivo"]))
    manejador.enviar_respuesta_datos(200, "application/json", b'{"ok":true}')
