import json
from backend.configuracion import CONFIGURACION_GRADOS
from backend.gestor_datos import cargar_revision, clave_registro, guardar_revision

def manejar_clear_image_actions(manejador, cuerpo, bloqueo):
    with bloqueo:
        grado = cuerpo.get("grado", "")
        archivo = cuerpo.get("archivo", "")
        if grado and grado in CONFIGURACION_GRADOS:
            rev = cargar_revision()
            if archivo:
                k = clave_registro(grado, archivo)
                if k in rev and "imagenes" in rev[k]:
                    rev[k]["imagenes"] = {img_id: info for img_id, info in rev[k]["imagenes"].items() if info.get("manual", False)}
            else:
                for k, v in rev.items():
                    if k.startswith(f"{grado}::") and isinstance(v, dict) and "imagenes" in v:
                        v["imagenes"] = {img_id: info for img_id, info in v["imagenes"].items() if info.get("manual", False)}
            guardar_revision(rev)
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True}).encode("utf-8"))
