import json
from backend.verificador_internet import comprobar_imagen_en_internet

def manejar_check_image_internet(manejador, cuerpo, bloqueo):
    grado = cuerpo.get("grado", "")
    archivo = cuerpo.get("archivo", "")
    num_pagina = int(cuerpo.get("page_num", 0))
    img_idx = int(cuerpo.get("img_idx", 0))
    auto_borrar = bool(cuerpo.get("auto_borrar", False))
    with bloqueo:
        res = comprobar_imagen_en_internet(grado, archivo, num_pagina, img_idx, auto_borrar_si_existe=auto_borrar)
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps(res).encode("utf-8"))
