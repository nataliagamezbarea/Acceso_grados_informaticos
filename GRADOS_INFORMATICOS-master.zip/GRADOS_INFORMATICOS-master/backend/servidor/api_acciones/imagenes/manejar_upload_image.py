import os
import base64
import json
from backend.configuracion import DIRECTORIO_IMAGENES_REEMPLAZO
from backend.gestor_datos import guardar_accion_imagen

def manejar_upload_image(manejador, cuerpo, bloqueo):
    grado = cuerpo.get("grado", "")
    archivo = cuerpo.get("archivo", "")
    img_id = cuerpo.get("img_id", "")
    nombre_img = os.path.basename(cuerpo.get("nombre_imagen", "reemplazo.png"))
    b64_data = cuerpo.get("datos_base64", "")
    if "," in b64_data:
        b64_data = b64_data.split(",", 1)[1]
    datos_binarios = base64.b64decode(b64_data)
    dir_destino = os.path.join(DIRECTORIO_IMAGENES_REEMPLAZO, grado)
    os.makedirs(dir_destino, exist_ok=True)
    arch_safe = os.path.basename(archivo).replace(".pdf", "")
    ruta_guardada = os.path.join(dir_destino, f"{arch_safe}_{img_id}_{nombre_img}")
    with open(ruta_guardada, "wb") as f:
        f.write(datos_binarios)
    with bloqueo:
        ok = guardar_accion_imagen(grado, archivo, img_id, "reemplazar", ruta_guardada)
    from backend.gestor_datos.github_sync import subir_archivo_a_github
    rel_repo = f"almacen/imagenes_reemplazo/{grado}/{arch_safe}_{img_id}_{nombre_img}"
    subir_archivo_a_github(ruta_guardada, rel_repo, rama="master", sincrono=True)
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": ok, "ruta": ruta_guardada}).encode("utf-8"))
