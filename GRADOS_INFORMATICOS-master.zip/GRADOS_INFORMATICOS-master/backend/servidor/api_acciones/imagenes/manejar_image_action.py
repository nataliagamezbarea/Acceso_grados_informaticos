import os
import json
from backend.gestor_datos import guardar_accion_imagen
from backend.procesador_pdf import limpiar_cache_pdf

def manejar_image_action(manejador, cuerpo, bloqueo):
    with bloqueo:
        ok = guardar_accion_imagen(
            cuerpo["grado"], cuerpo["archivo"],
            cuerpo["img_id"], cuerpo["accion"],
            ruta_reemplazo=cuerpo.get("ruta"),
            cita_texto=cuerpo.get("cita"),
            manual=True
        )
        # CORRECCIÓN CLAVE: cualquier cambio de acción sobre la imagen debe
        # reflejarse AL INSTANTE en la previsualización → limpiar su caché.
        # Antes solo se limpiaba en el borrado global: por eso 'Borrar' y
        # 'Restaurar Original' parecían no hacer nada hasta reiniciar.
        try:
            limpiar_cache_pdf(cuerpo["grado"], cuerpo["archivo"])
        except Exception:
            pass

        # "Eliminar también en otros PDFs": registra el hash LITERAL de la imagen
        # para que se borre por defecto en cualquier documento donde aparezca.
        if ok and cuerpo.get("accion") == "borrar" and cuerpo.get("global"):
            try:
                from backend.gestor_datos import obtener_hash_imagen_de_archivo, registrar_imagen_borrar_global
                h = obtener_hash_imagen_de_archivo(cuerpo["grado"], cuerpo["archivo"], int(cuerpo.get("page_num", -1)), int(cuerpo.get("img_idx", -1)))
                if h:
                    registrar_imagen_borrar_global(h, cuerpo["grado"], cuerpo["archivo"], cuerpo["img_id"])
                    limpiar_cache_pdf(cuerpo["grado"])
            except Exception as e:
                print(f"[image_action] registro borrar global falló: {e}")

        if ok and cuerpo.get("accion") == "conservar" and cuerpo.get("global"):
            try:
                from backend.gestor_datos import obtener_hash_imagen_de_archivo, registrar_imagen_conservar_global
                h = obtener_hash_imagen_de_archivo(cuerpo["grado"], cuerpo["archivo"], int(cuerpo.get("page_num", -1)), int(cuerpo.get("img_idx", -1)))
                if h:
                    registrar_imagen_conservar_global(h, cuerpo["grado"], cuerpo["archivo"], cuerpo["img_id"])
                    limpiar_cache_pdf(cuerpo["grado"])
            except Exception as e:
                print(f"[image_action] registro conservar global falló: {e}")

        if ok and cuerpo.get("accion") == "restaurar":
            try:
                from backend.gestor_datos import obtener_hash_imagen_de_archivo, quitar_imagen_borrar_global, quitar_imagen_conservar_global
                h = obtener_hash_imagen_de_archivo(cuerpo["grado"], cuerpo["archivo"], int(cuerpo.get("page_num", -1)), int(cuerpo.get("img_idx", -1)))
                if h:
                    quitar_imagen_borrar_global(h)
                    quitar_imagen_conservar_global(h)
                    limpiar_cache_pdf(cuerpo["grado"])
            except Exception as e:
                print(f"[image_action] restauración global falló: {e}")
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": ok}).encode("utf-8"))
