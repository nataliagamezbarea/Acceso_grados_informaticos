import json
from backend.gestor_datos import (
    cargar_revision, clave_registro, guardar_revision, limpiar_nombre_archivo
)
from backend.generador_apuntes import (
    obtener_registros_csv, compilar_apunte_pdf, sincronizar_registro_csv,
    limpiar_nombre_apunte, _generar_latex_del_apunte
)
from backend.gestor_datos.github_sync import (
    subir_json_a_github, disparar_workflow_github, REPO_UTILIDADES_GRADO
)

NOMBRE_WORKFLOW_COMPILAR = "compilar-apunte.yml"
RAMA_WORKFLOW = "master"

def _compilar_via_github_actions(grado, nombre_apunte, archivo_original=None):
    """Genera el .tex, lo sube al repo y dispara el workflow de Docker texlive.
    Devuelve True si se disparó correctamente; False si no se pudo (y habría que
    degradar a compilación local)."""
    nombre = limpiar_nombre_apunte(nombre_apunte)
    contenido_tex, _ = _generar_latex_del_apunte(grado, nombre, archivo_original)
    if contenido_tex is None:
        return False
    ruta_en_repo = f"NUEVOS_APUNTES/{grado}/{nombre}.tex"
    ok_subida = subir_json_a_github(
        contenido_tex, ruta_en_repo, rama=RAMA_WORKFLOW,
        mensaje=f"Apunte .tex para compilar: {grado}/{nombre}",
        sincrono=True, repo_override=REPO_UTILIDADES_GRADO
    )
    if not ok_subida:
        return False
    ok_disparo = disparar_workflow_github(
        NOMBRE_WORKFLOW_COMPILAR, rama=RAMA_WORKFLOW,
        inputs={"grado": grado, "nombre_apunte": nombre},
        repo_override=REPO_UTILIDADES_GRADO
    )
    return bool(ok_disparo)

def manejar_compilar_apunte(manejador, cuerpo, bloqueo):
    g = cuerpo.get("grado", "")
    nombre_ap = cuerpo.get("nombre_apunte", "")
    archivo_orig = cuerpo.get("archivo", "")
    with bloqueo:
        registros = obtener_registros_csv()
        match = next((r for r in registros.values()
                      if r.get("grado") == g and r.get("nombre_apunte") == nombre_ap), None)
        if not match and archivo_orig:
            match = next((r for r in registros.values()
                          if r.get("grado") == g and r.get("archivo_original") == archivo_orig), None)
            if not match:
                match = {"archivo_original": archivo_orig, "nombre_limpio": archivo_orig}
        if not match:
            rev = cargar_revision()
            mk = next((k for k, v in rev.items()
                       if k.startswith(f"{g}::") and isinstance(v, dict) and v.get("nombre_apunte") == nombre_ap), None)
            if mk:
                match = {"archivo_original": mk.split("::", 1)[1], "nombre_limpio": mk.split("::", 1)[1]}
        if not match:
            manejador.enviar_respuesta_datos(404, "application/json", json.dumps({"ok": False, "msg": "Apunte no encontrado"}).encode("utf-8"))
            return
        arch_orig = match["archivo_original"]
        nombre = limpiar_nombre_apunte(nombre_ap)

        # Flujo principal: compilar con GitHub Actions + Docker texlive.
        # El .tex se sube al repo, se dispara el workflow y el PDF queda en
        # GI/<grado>/apuntes/. El front hace polling a /api/estado_compilacion.
        if _compilar_via_github_actions(g, nombre, archivo_original=arch_orig):
            sincronizar_registro_csv(
                g, arch_orig, match.get("nombre_limpio", limpiar_nombre_archivo(arch_orig)),
                es_apunte=True, nombre_apunte=nombre, apunte_compilado=True,
                rel_apunte=f"apuntes/{nombre}.pdf"
            )
            rev = cargar_revision()
            k = clave_registro(g, arch_orig)
            if k not in rev: rev[k] = {}
            rev[k]["latex_compilado"] = True
            guardar_revision(rev)
            manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True, "en_proceso": True, "pdf_path": f"{g}/apuntes/{nombre}.pdf"}).encode("utf-8"))
            return

        # Degradado: compilar localmente (comportamiento previo) si no se pudo
        # disparar GitHub Actions (p.ej. sin token/repo configurados).
        destino = compilar_apunte_pdf(g, nombre, archivo_original=arch_orig)
        if not destino:
            manejador.enviar_respuesta_datos(500, "application/json", json.dumps({"ok": False, "msg": "Fallo la compilación LaTeX del apunte"}).encode("utf-8"))
            return
        sincronizar_registro_csv(
            g, arch_orig, match.get("nombre_limpio", limpiar_nombre_archivo(arch_orig)),
            es_apunte=True, nombre_apunte=nombre, apunte_compilado=True,
            rel_apunte=f"apuntes/{limpiar_nombre_apunte(nombre)}.pdf"
        )
        rev = cargar_revision()
        k = clave_registro(g, arch_orig)
        if k not in rev: rev[k] = {}
        rev[k]["latex_compilado"] = True
        guardar_revision(rev)
        manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True, "pdf_path": destino}).encode("utf-8"))

