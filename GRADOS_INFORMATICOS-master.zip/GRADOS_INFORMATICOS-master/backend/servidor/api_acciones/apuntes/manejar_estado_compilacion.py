import json
import urllib.parse

from backend.gestor_datos.github_sync import existe_pdf_en_github
from backend.generador_apuntes import limpiar_nombre_apunte
from backend.configuracion import CONFIGURACION_GRADOS


def manejar_estado_compilacion(manejador, ruta, query, bloqueo):
    """Polling para el flujo 'Compilar con GitHub Actions'.

    Consulta si el PDF ya existe en GRADOS_INFORMATICOS, rama del grado, en
    apuntes/<nombre>.pdf, que es donde el workflow de Docker texlive lo entrega
    y donde el visor lo lee. Devuelve {"ok": true, "listo": bool}."""
    params = urllib.parse.parse_qs(query)
    grado = (params.get("grado") or [""])[0]
    nombre = (params.get("nombre_apunte") or params.get("nombre") or [""])[0]
    if not grado or not nombre:
        manejador.enviar_respuesta_datos(400, "application/json",
                                         json.dumps({"ok": False, "msg": "Faltan grado o nombre_apunte"}).encode("utf-8"))
        return
    nombre = limpiar_nombre_apunte(nombre)
    rama = grado
    if grado in CONFIGURACION_GRADOS:
        rama = CONFIGURACION_GRADOS[grado].get("rama_origen", grado)
    ruta_pdf = f"apuntes/{nombre}.pdf"
    listo = bool(existe_pdf_en_github(ruta_pdf, rama=rama))
    manejador.enviar_respuesta_datos(200, "application/json",
                                     json.dumps({"ok": True, "listo": listo, "pdf_path": f"{grado}/{ruta_pdf}"}).encode("utf-8"))
