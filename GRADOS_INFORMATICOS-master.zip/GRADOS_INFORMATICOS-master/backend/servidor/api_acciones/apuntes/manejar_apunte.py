import os
import json
from backend.configuracion import DIRECTORIO_GI, DIRECTORIO_NUEVOS_APUNTES
from backend.gestor_datos import (
    cargar_revision, clave_registro, guardar_revision,
    leer_archivo_original, cargar_reescrituras,
    limpiar_nombre_archivo
)
from backend.generador_apuntes import (
    crear_borrador_apunte, preparar_apunte,
    limpiar_nombre_apunte, generar_propuesta_nombre_apunte,
    sincronizar_registro_csv, restaurar_csvs_del_grado
)

def manejar_apunte(manejador, cuerpo, bloqueo):
    rev = cargar_revision()
    k = clave_registro(cuerpo["grado"], cuerpo["archivo"])
    if k not in rev: rev[k] = {}
    es_ap = bool(cuerpo["inc_apunte"])
    rev[k]["inc_apunte"] = es_ap
    # El check del HTML no siempre envía nombre_apunte: usar el guardado
    # (modal de renombrar) o generar la propuesta a partir del archivo.
    nombre_ap = cuerpo.get("nombre_apunte") or rev[k].get("nombre_apunte")
    if es_ap:
        if not nombre_ap:
            nombre_ap = generar_propuesta_nombre_apunte(cuerpo["archivo"])
        rev[k]["nombre_apunte"] = nombre_ap
    else:
        # Al desactivar "Convertir en Apunte" se borran los PDF generados,
        # así que el botón de LaTeX debe dejar de mostrarse como "✓ Aplicado".
        rev[k]["latex_compilado"] = False
    with bloqueo:
        guardar_revision(rev)
        dir_ap = os.path.join(DIRECTORIO_NUEVOS_APUNTES, cuerpo["grado"])
        os.makedirs(dir_ap, exist_ok=True)
        if es_ap:
            # El check recolecta: borrador .txt de MUESTRA (estructura) + copia TAL CUAL
            # del PDF original, ambos en NUEVOS_APUNTES. Sin compilar nada y SIN crear
            # ningún .tex: el LaTeX se genera solo al pulsar "HACER / COMPILAR APUNTE".
            datos_brutos = leer_archivo_original(cuerpo["grado"], cuerpo.get("rel_path", "archivos/" + cuerpo["archivo"]))
            lista_rw = cargar_reescrituras(cuerpo["grado"])
            rw_match = next((x for x in lista_rw if os.path.basename(x.get("archivo", "")) == os.path.basename(cuerpo["archivo"])), None)
            enuncs = rw_match.get("enunciados", []) if rw_match else []
            crear_borrador_apunte(cuerpo["grado"], cuerpo["archivo"], nombre_ap, datos_brutos, enuncs)
            try:
                preparar_apunte(cuerpo["grado"], cuerpo["archivo"], nombre_ap, hacia_gi=False, rel_origen=cuerpo.get("rel_path"))
            except Exception as e:
                print(f"Error copiando PDF del apunte a NUEVOS_APUNTES: {e}")
            sincronizar_registro_csv(
                cuerpo["grado"], cuerpo["archivo"], limpiar_nombre_archivo(cuerpo["archivo"]),
                es_apunte=True, nombre_apunte=nombre_ap, apunte_compilado=False, actualizar_grado=False
            )
        else:
            nombre_ap = sincronizar_registro_csv(cuerpo["grado"], cuerpo["archivo"], limpiar_nombre_archivo(cuerpo["archivo"]), es_apunte=False)
            # Quitar el check tras haber compilado: elimina la fila de APUNTES.csv y el
            # enlace 📒 APUNTES de EJERCICIOS_PRACTICAS_PROYECTOS.csv (el .txt/.tex de
            # borrador NUNCA se borran).
            try:
                restaurar_csvs_del_grado(cuerpo["grado"], cuerpo["archivo"], nombre_ap)
            except Exception as e:
                print(f"Error restaurando CSVs del apunte: {e}")
            # Solo se eliminan los PDF generados; los .txt/.tex de borrador se conservan siempre
            nombre_ap_limpio = limpiar_nombre_apunte(nombre_ap) if nombre_ap else generar_propuesta_nombre_apunte(cuerpo["archivo"])
            prefijos = [p for p in [nombre_ap_limpio, nombre_ap] if p]
            for target_dir in [dir_ap, os.path.join(DIRECTORIO_GI, cuerpo["grado"], "apuntes")]:
                if os.path.exists(target_dir):
                    for fn in os.listdir(target_dir):
                        if not fn.lower().endswith(".pdf"): continue
                        for pfx in prefijos:
                            if pfx and fn.startswith(pfx):
                                try: os.remove(os.path.join(target_dir, fn))
                                except Exception: pass
                                break
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True, "nombre_apunte": nombre_ap}).encode("utf-8"))
