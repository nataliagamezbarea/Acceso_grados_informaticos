import json
from backend.generador_apuntes import compilar_todos_los_apuntes

def manejar_compilar_todos_apuntes(manejador, cuerpo, bloqueo):
    g = cuerpo.get("grado", "")
    with bloqueo:
        tot, errs = compilar_todos_los_apuntes(g)
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True, "compilados": tot, "errores": errs}).encode("utf-8"))
