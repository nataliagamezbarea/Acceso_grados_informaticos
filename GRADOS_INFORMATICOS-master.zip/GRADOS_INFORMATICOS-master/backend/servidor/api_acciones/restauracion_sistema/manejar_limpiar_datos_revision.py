import os
import json
from backend.gestor_datos import cargar_revision, guardar_revision

def manejar_limpiar_datos_revision(manejador, cuerpo, bloqueo):
    g = cuerpo.get("grado", "")
    limpiar_enunciados = bool(cuerpo.get("enunciados", False))
    limpiar_nombres = bool(cuerpo.get("nombres", False))
    limpiar_colegios = bool(cuerpo.get("colegios", False))
    limpiar_imagenes = bool(cuerpo.get("imagenes", False))
    limpiar_todo = bool(cuerpo.get("todo", False))
    subir_github = bool(cuerpo.get("subir_github", True))

    with bloqueo:
        rev = cargar_revision()
        if limpiar_todo:
            if g:
                # Limpiar solo las claves de este grado
                claves_a_borrar = [k for k in rev.keys() if k.startswith(f"{g}::")]
                for k in claves_a_borrar:
                    del rev[k]
            else:
                rev = {}
        else:
            for k, info in list(rev.items()):
                if g and not k.startswith(f"{g}::"):
                    continue
                if not isinstance(info, dict):
                    continue

                if limpiar_enunciados:
                    info.pop("enunciados", None)
                    info.pop("include", None)
                    info.pop("enunciados_custom", None)
                    info.pop("enunciados_eliminados", None)
                if limpiar_nombres:
                    info.pop("inc_interior", None)
                    info.pop("nombres", None)
                if limpiar_colegios:
                    info.pop("inc_colegio", None)
                    info.pop("colegio", None)
                if limpiar_imagenes:
                    info.pop("imagenes", None)
                    info.pop("imagenes_acciones", None)

                # Si el objeto queda vacío, limpiarlo
                if not info:
                    del rev[k]

        guardar_revision(rev)

        # Si se solicita sincronizar con GitHub
        if subir_github:
            try:
                from backend.servidor.api_github import _obtener_config_github
                import urllib.request, base64
                repo, token = _obtener_config_github()
                if repo and token:
                    rama = g or "master"
                    contenido_json = json.dumps(rev, indent=2, ensure_ascii=False)
                    b64_content = base64.b64encode(contenido_json.encode("utf-8")).decode("utf-8")
                    
                    # Intentar obtener SHA
                    sha = None
                    try:
                        req_sha = urllib.request.Request(
                            f"https://api.github.com/repos/{repo}/contents/datos/revision.json?ref={rama}",
                            headers={"Authorization": f"Bearer {token}", "User-Agent": "grados-app"}
                        )
                        with urllib.request.urlopen(req_sha, timeout=4) as resp:
                            if resp.status == 200:
                                sha = json.loads(resp.read().decode("utf-8")).get("sha")
                    except Exception:
                        pass

                    payload = {
                        "message": f"Limpiar datos de revision JSON ({g})",
                        "content": b64_content,
                        "branch": rama
                    }
                    if sha:
                        payload["sha"] = sha

                    req_put = urllib.request.Request(
                        f"https://api.github.com/repos/{repo}/contents/datos/revision.json",
                        data=json.dumps(payload).encode("utf-8"),
                        headers={
                            "Authorization": f"Bearer {token}",
                            "Content-Type": "application/json",
                            "User-Agent": "grados-app"
                        },
                        method="PUT"
                    )
                    urllib.request.urlopen(req_put, timeout=8)
            except Exception as e:
                print(f"[WARN] No se pudo subir revision.json a GitHub: {e}")

    manejador.enviar_respuesta_datos(
        200, "application/json; charset=utf-8",
        json.dumps({"ok": True, "msg": "Datos de revisión limpiados correctamente."}).encode("utf-8")
    )
