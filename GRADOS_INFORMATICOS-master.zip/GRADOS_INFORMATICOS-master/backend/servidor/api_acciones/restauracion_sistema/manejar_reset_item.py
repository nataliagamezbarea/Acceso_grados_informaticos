import json
from backend.gestor_datos import eliminar_de_inicio_archivo
from backend.procesador_pdf import limpiar_cache_pdf

def manejar_reset_item(manejador, cuerpo, bloqueo):
    grado = cuerpo.get("grado", "")
    archivo = cuerpo.get("archivo", "")
    with bloqueo:
        ok = eliminar_de_inicio_archivo(grado, archivo)
        try:
            limpiar_cache_pdf(grado, archivo)
        except Exception:
            pass
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": ok}).encode("utf-8"))
