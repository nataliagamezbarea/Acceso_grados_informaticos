import json
from backend.gestor_datos import restaurar_solo_nombre
from backend.procesador_pdf import limpiar_cache_pdf

def manejar_restaurar_nombre(manejador, cuerpo, bloqueo):
    with bloqueo:
        ok = restaurar_solo_nombre(cuerpo["grado"], cuerpo["archivo"], cuerpo.get("idx"))
        try:
            limpiar_cache_pdf(cuerpo["grado"], cuerpo["archivo"])
        except Exception:
            pass
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": ok}).encode("utf-8"))
