import json
import os
from backend.gestor_datos import cargar_revision, guardar_revision, clave_registro, cargar_reescrituras, guardar_reescrituras
from backend.procesador_pdf import limpiar_cache_pdf


def manejar_quitar_manual(manejador, cuerpo, bloqueo):
    """Elimina UNICAMENTE lo añadido manualmente por el usuario mediante 'Crear'/'Añadir':
    - Recuadros de nombre/colegio dibujados a mano (rev[k]['recuadros']).
    - El punto de inicio de reflujo dibujado a mano (rev[k]['inicio_reflujo']).
    - Enunciados creados manualmente (custom=True) en el sistema de reescrituras.

    NO toca nada que ya viniera detectado/definido en el JSON predeterminado
    (enunciados detectados, checks de inclusión, etc.).
    """
    grado = cuerpo.get("grado", "")
    archivo = cuerpo.get("archivo", "")
    arch_base = os.path.basename(archivo)

    with bloqueo:
        try:
            rev = cargar_revision()
            k = clave_registro(grado, archivo)
            if k in rev:
                rev[k].pop("recuadros", None)
                rev[k].pop("inicio_reflujo", None)
                if not rev[k]:
                    del rev[k]
                guardar_revision(rev)
        except Exception:
            pass

        try:
            rw = cargar_reescrituras(grado) or []
            entry = next((e for e in rw if os.path.basename(e.get("archivo", "")) == arch_base), None)
            if entry:
                enuncs = entry.get("enunciados", [])
                entry["enunciados"] = [e for e in enuncs if not e.get("custom")]
                guardar_reescrituras(grado, rw)
        except Exception:
            pass

        try:
            limpiar_cache_pdf(grado, archivo)
        except Exception:
            pass

    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True}).encode("utf-8"))
