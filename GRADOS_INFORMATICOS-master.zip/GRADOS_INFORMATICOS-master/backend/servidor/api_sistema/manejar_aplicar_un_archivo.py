import json
from backend.procesador_pdf import aplicar_cambios_un_archivo

def manejar_aplicar_un_archivo(manejador, cuerpo, bloqueo):
    g = cuerpo.get("grado", "")
    arch = cuerpo.get("archivo", "")
    subir_github = bool(cuerpo.get("subir_github", False))
    with bloqueo:
        ok, msg = aplicar_cambios_un_archivo(g, arch, subir_github=subir_github)
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": ok, "msg": msg}).encode("utf-8"))
