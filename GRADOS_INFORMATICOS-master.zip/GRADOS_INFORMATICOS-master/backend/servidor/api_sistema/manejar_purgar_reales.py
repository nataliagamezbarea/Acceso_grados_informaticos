import json
from backend.gestor_datos import purgar_archivos_reales

def manejar_purgar_reales(manejador, cuerpo, bloqueo):
    g = cuerpo.get("grado", "")
    with bloqueo:
        ok, msg = purgar_archivos_reales(g)
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": ok, "msg": msg}).encode("utf-8"))
