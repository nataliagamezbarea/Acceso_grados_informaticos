import os
import json
import threading
from backend.configuracion import DIRECTORIO_DATOS

_RUTA_ESTADO_CACHE = os.path.join(DIRECTORIO_DATOS, "estado_cache.json")
_bloqueo_cache = threading.Lock()
_cache_desactivada = True  # valor por defecto si no hay archivo aún


def _cargar_estado_cache_inicial():
    global _cache_desactivada
    try:
        with open(_RUTA_ESTADO_CACHE, "r", encoding="utf-8") as f:
            datos = json.load(f)
            _cache_desactivada = bool(datos.get("desactivada", True))
    except Exception:
        _cache_desactivada = True


_cargar_estado_cache_inicial()


def cache_esta_desactivada():
    with _bloqueo_cache:
        return _cache_desactivada


def manejar_get_estado_cache(manejador):
    manejador.enviar_respuesta_datos(
        200, "application/json; charset=utf-8",
        json.dumps({"desactivada": cache_esta_desactivada()}).encode("utf-8")
    )


def manejar_set_estado_cache(manejador, cuerpo, bloqueo):
    global _cache_desactivada
    desactivada = bool(cuerpo.get("desactivada", True))
    with _bloqueo_cache:
        _cache_desactivada = desactivada
        try:
            with open(_RUTA_ESTADO_CACHE, "w", encoding="utf-8") as f:
                json.dump({"desactivada": desactivada}, f)
        except Exception:
            pass
    manejador.enviar_respuesta_datos(
        200, "application/json; charset=utf-8",
        json.dumps({"ok": True, "desactivada": desactivada}).encode("utf-8")
    )
