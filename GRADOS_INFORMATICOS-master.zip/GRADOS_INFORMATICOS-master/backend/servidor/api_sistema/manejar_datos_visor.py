import json
from backend.gestor_datos import construir_datos_visor

def manejar_datos_visor(manejador, bloqueo=None):
    datos, _ = construir_datos_visor()

    salida = {}
    for g, d in datos.items():
        entradas = []
        for e in d["entries"]:
            if e["cambia"]:
                miniatura_url = f"/api/thumb/{g}/{e['idx']}"
                entradas.append({**e, "thumb": miniatura_url})
            else:
                entradas.append({**e, "thumb": ""})
        salida[g] = {
            "dir": d["dir"],
            "titulo": d.get("titulo", g),
            "total_archivos": d.get("total_archivos", len(entradas) + len(d["no_cambian"])),
            "entries": entradas,
            "no_cambian": [{**n, "thumb": ""} for n in d["no_cambian"]]
        }
    manejador.enviar_respuesta_datos(200, "application/json; charset=utf-8", json.dumps(salida, ensure_ascii=False).encode("utf-8"))
