import json
from backend.procesador_pdf import aplicar_cambios_rama_limpia

def manejar_aplicar_rama(manejador, cuerpo, bloqueo):
    g = cuerpo.get("grado", "")
    with bloqueo:
        ok, msg = aplicar_cambios_rama_limpia(g)
    manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": ok, "msg": msg}).encode("utf-8"))
