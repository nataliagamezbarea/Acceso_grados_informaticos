import os
import sys
import json
import time
import threading

def manejar_reiniciar_servidor(manejador, cuerpo, bloqueo):
    """Reinicia el proceso del servidor (para recoger cambios de código).

    Responde YA (antes de reiniciar) para que el navegador reciba la
    confirmación, y el propio proceso se reemplaza a sí mismo (os.execv)
    medio segundo después, en un hilo aparte, dando tiempo a que la
    respuesta HTTP termine de enviarse."""
    manejador.enviar_respuesta_datos(
        200, "application/json; charset=utf-8",
        json.dumps({"ok": True, "msg": "Reiniciando servidor..."}).encode("utf-8")
    )

    def _reiniciar_proceso():
        time.sleep(0.4)
        print("[INFO] Reiniciando servidor (petición desde el panel de desarrollo)...")
        sys.stdout.flush()
        try:
            manejador.server.server_close()
        except Exception:
            pass
        os.execv(sys.executable, [sys.executable] + sys.argv)

    threading.Thread(target=_reiniciar_proceso, daemon=True).start()
