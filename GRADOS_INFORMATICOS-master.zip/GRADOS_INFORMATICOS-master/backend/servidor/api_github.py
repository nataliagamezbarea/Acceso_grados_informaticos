import os
import json
import base64
import urllib.request
import urllib.error
from backend.configuracion import DIRECTORIO_GI

def _obtener_config_github():
    """Config privada del ADMIN: gh_repo_general + gh_token."""
    try:
        from backend.gestor_datos.leer_config_supabase import leer_config_supabase
        cfg = leer_config_supabase(("gh_repo_general", "gh_token"))
        repo = (cfg.get("gh_repo_general") or "").strip()
        token = (cfg.get("gh_token") or "").strip()
        return repo, token
    except Exception:
        return "", ""

def listar_ramas_github():
    """Obtiene las ramas actuales directamente del repo privado general."""
    repo, token = _obtener_config_github()
    if not repo or not token:
        return []
    ramas = []
    pagina = 1
    while True:
        try:
            req = urllib.request.Request(
                f"https://api.github.com/repos/{repo}/branches?per_page=100&page={pagina}",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept": "application/vnd.github+json",
                    "User-Agent": "grados-informaticos-app"
                }
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            lote = [b["name"] for b in data if b.get("name")]
            ramas.extend(lote)
            if len(lote) < 100:
                break
            pagina += 1
        except Exception:
            break
    return ramas

def manejar_listar_ramas(manejador):
    ramas = listar_ramas_github()
    manejador.enviar_respuesta_datos(200, "application/json; charset=utf-8", json.dumps(ramas).encode("utf-8"))

def manejar_github_pull(manejador):
    resultado = {"ok": True, "mensaje": "Repositorio sincronizado"}
    try:
        import subprocess
        if os.path.exists(DIRECTORIO_GI) and os.path.exists(os.path.join(DIRECTORIO_GI, ".git")):
            subprocess.run(["git", "fetch", "--all"], cwd=DIRECTORIO_GI, check=False, capture_output=True)
            resultado["mensaje"] = "Fetch de ramas remotas completado con éxito."
    except Exception as e:
        resultado = {"ok": False, "error": str(e)}
    manejador.enviar_respuesta_datos(200, "application/json; charset=utf-8", json.dumps(resultado).encode("utf-8"))

def manejar_github_crear_modificar(manejador, cuerpo):
    repo, token = _obtener_config_github()
    rama = cuerpo.get("rama", "master")
    ruta = cuerpo.get("ruta", "").lstrip("/")
    contenido_b64 = cuerpo.get("contenido_b64", "")
    mensaje = cuerpo.get("mensaje", f"Actualizar {ruta} via Visor")

    if not ruta or not token:
        manejador.enviar_respuesta_datos(400, "application/json", json.dumps({"ok": False, "error": "Faltan datos o token"}).encode("utf-8"))
        return

    sha = None
    try:
        url_get = f"https://api.github.com/repos/{repo}/contents/{ruta}?ref={rama}"
        req_get = urllib.request.Request(
            url_get,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "User-Agent": "grados-informaticos-app"
            }
        )
        with urllib.request.urlopen(req_get, timeout=5) as resp:
            if resp.status == 200:
                data = json.loads(resp.read().decode("utf-8"))
                sha = data.get("sha")
    except Exception:
        pass

    payload = {
        "message": mensaje,
        "content": contenido_b64,
        "branch": rama
    }
    if sha:
        payload["sha"] = sha

    try:
        url_put = f"https://api.github.com/repos/{repo}/contents/{ruta}"
        req_put = urllib.request.Request(
            url_put,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "Content-Type": "application/json",
                "User-Agent": "grados-informaticos-app"
            },
            method="PUT"
        )
        with urllib.request.urlopen(req_put, timeout=10) as resp:
            manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True, "status": resp.status}).encode("utf-8"))
    except urllib.error.HTTPError as he:
        manejador.enviar_respuesta_datos(he.code, "application/json", json.dumps({"ok": False, "error": he.read().decode("utf-8", errors="ignore")}).encode("utf-8"))
    except Exception as e:
        manejador.enviar_respuesta_datos(500, "application/json", json.dumps({"ok": False, "error": str(e)}).encode("utf-8"))

def manejar_github_eliminar(manejador, cuerpo):
    repo, token = _obtener_config_github()
    rama = cuerpo.get("rama", "master")
    ruta = cuerpo.get("ruta", "").lstrip("/")
    mensaje = cuerpo.get("mensaje", f"Eliminar {ruta} via Visor")

    if not ruta or not token:
        manejador.enviar_respuesta_datos(400, "application/json", json.dumps({"ok": False, "error": "Faltan datos o token"}).encode("utf-8"))
        return

    sha = cuerpo.get("sha")
    if not sha:
        try:
            url_get = f"https://api.github.com/repos/{repo}/contents/{ruta}?ref={rama}"
            req_get = urllib.request.Request(
                url_get,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept": "application/vnd.github+json",
                    "User-Agent": "grados-informaticos-app"
                }
            )
            with urllib.request.urlopen(req_get, timeout=5) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode("utf-8"))
                    sha = data.get("sha")
        except Exception as e:
            manejador.enviar_respuesta_datos(404, "application/json", json.dumps({"ok": False, "error": f"No se pudo encontrar el archivo: {e}"}).encode("utf-8"))
            return

    if not sha:
        manejador.enviar_respuesta_datos(404, "application/json", json.dumps({"ok": False, "error": "Archivo no encontrado"}).encode("utf-8"))
        return

    payload = {
        "message": mensaje,
        "sha": sha,
        "branch": rama
    }

    try:
        url_del = f"https://api.github.com/repos/{repo}/contents/{ruta}"
        req_del = urllib.request.Request(
            url_del,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "Content-Type": "application/json",
                "User-Agent": "grados-informaticos-app"
            },
            method="DELETE"
        )
        with urllib.request.urlopen(req_del, timeout=10) as resp:
            manejador.enviar_respuesta_datos(200, "application/json", json.dumps({"ok": True, "status": resp.status}).encode("utf-8"))
    except urllib.error.HTTPError as he:
        manejador.enviar_respuesta_datos(he.code, "application/json", json.dumps({"ok": False, "error": he.read().decode("utf-8", errors="ignore")}).encode("utf-8"))
    except Exception as e:
        manejador.enviar_respuesta_datos(500, "application/json", json.dumps({"ok": False, "error": str(e)}).encode("utf-8"))
