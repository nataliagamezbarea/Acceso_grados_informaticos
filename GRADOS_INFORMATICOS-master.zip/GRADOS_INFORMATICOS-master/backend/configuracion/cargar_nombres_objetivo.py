import os
import re

from backend.configuracion import DIRECTORIO_DATOS
from backend.configuracion.normalizar_palabra import normalizar_palabra

def cargar_nombres_objetivo():
    """Carga los nombres de alumnos y profesores a eliminar desde GitHub."""
    nombres_base = []
    try:
        from backend.gestor_datos.github_sync import descargar_json_de_github
        remoto = descargar_json_de_github("almacen/datos/nombres_eliminar.json")
        if isinstance(remoto, list) and remoto:
            nombres_base = remoto
    except Exception:
        pass

    if not nombres_base:
        archivo_nombres = os.path.join(DIRECTORIO_DATOS, "nombres_eliminar.json")
        if os.path.exists(archivo_nombres):
            try:
                import json
                nombres_base = json.load(open(archivo_nombres, encoding="utf-8"))
            except Exception:
                pass

    palabras = set()
    for nombre_completo in nombres_base:
        for p in re.split(r"\s+", nombre_completo):
            np = normalizar_palabra(p)
            if len(np) >= 3:
                palabras.add(np)
    return nombres_base, palabras
