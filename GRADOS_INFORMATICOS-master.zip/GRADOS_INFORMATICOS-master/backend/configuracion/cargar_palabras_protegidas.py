import os, json

def cargar_palabras_protegidas():
    """Descarga de GitHub las palabras protegidas o recurre al json local."""
    try:
        from backend.gestor_datos.github_sync import descargar_json_de_github
        remoto = descargar_json_de_github("almacen/datos/palabras_protegidas.json")
        if isinstance(remoto, list) and remoto:
            return set(remoto)
    except Exception:
        pass
    dir_base = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    p_local = os.path.join(dir_base, "almacen", "datos", "palabras_protegidas.json")
    if os.path.exists(p_local):
        try:
            return set(json.load(open(p_local, encoding="utf-8")))
        except Exception:
            pass
    return set()
