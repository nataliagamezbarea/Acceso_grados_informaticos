import re
import unicodedata

def normalizar_palabra(palabra):
    """Normaliza texto eliminando puntuación y acentos."""
    palabra = re.sub(r"^[^\w]+|[^\w]+$", "", palabra or "")
    return "".join(c for c in unicodedata.normalize("NFD", palabra) if unicodedata.category(c) != "Mn").upper()
