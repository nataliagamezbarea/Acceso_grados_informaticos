import os

# DIRECTORIO_BASE: este __init__ vive en <raiz>/backend/configuracion/__init__.py,
# así que tres `dirname` suben hasta la raíz del repositorio (el .py original
# estaba en <raiz>/backend/configuracion.py, donde bastaban dos `dirname`).
DIRECTORIO_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DIRECTORIO_DATOS = os.path.join(DIRECTORIO_BASE, "almacen", "datos")
# IMPORTANTE: DIRECTORIO_CACHE es SOLO para PDFs generados por el visor
# (previsualizaciones "old"/"new"). Las imágenes (.png) de miniaturas y de
# páginas van SIEMPRE a DIRECTORIO_CACHE_IMAGENES, en una carpeta aparte.
DIRECTORIO_CACHE = os.path.join(DIRECTORIO_BASE, "almacen", "cache_visor")
DIRECTORIO_CACHE_IMAGENES = os.path.join(DIRECTORIO_BASE, "almacen", "cache_visor_imagenes")
DIRECTORIO_BACKUPS = os.path.join(DIRECTORIO_BASE, "almacen", "backups_originales")
DIRECTORIO_ESTATICOS = os.path.join(DIRECTORIO_BASE, "frontend")
DIRECTORIO_PLANTILLAS = os.path.join(DIRECTORIO_BASE, "plantillas")
DIRECTORIO_NUEVOS_APUNTES = os.path.join(DIRECTORIO_BASE, "almacen", "NUEVOS_APUNTES")
DIRECTORIO_IMAGENES_REEMPLAZO = os.path.join(DIRECTORIO_DATOS, "imagenes_reemplazo")

# En entornos serverless de solo lectura (p.ej. Vercel) la creación de
# carpetas bajo el árbol de despliegue puede fallar; nunca debe abortar la
# importación ni la función. Se intenta crear y, si no se puede, se sigue.
def _crear_directorio_si_puede(ruta):
    try:
        os.makedirs(ruta, exist_ok=True)
    except Exception:
        pass

_crear_directorio_si_puede(DIRECTORIO_DATOS)
_crear_directorio_si_puede(DIRECTORIO_CACHE)
_crear_directorio_si_puede(DIRECTORIO_CACHE_IMAGENES)
_crear_directorio_si_puede(DIRECTORIO_BACKUPS)
_crear_directorio_si_puede(DIRECTORIO_NUEVOS_APUNTES)
_crear_directorio_si_puede(DIRECTORIO_IMAGENES_REEMPLAZO)

# Directorio Base de los Repositorios de Grados Informáticos (dinámico y portable)
DIRECTORIO_GI = os.environ.get("DIRECTORIO_GI", os.path.join(os.path.dirname(DIRECTORIO_BASE), "GI"))
if not os.path.exists(DIRECTORIO_GI):
    DIRECTORIO_GI = os.path.join(DIRECTORIO_BASE, "GI")
_crear_directorio_si_puede(DIRECTORIO_GI)


# Configuración por cada Grado
CONFIGURACION_GRADOS = {
    "Primer_grado_medio": {
        "directorio": os.path.join(DIRECTORIO_GI, "Primer_grado_medio"),
        "rama_origen": "Primer_grado_medio",
        "rama_limpia": "Primer_grado_medio_limpia",
        "titulo": "Primer_grado_medio"
    },
    "Segundo_grado_medio": {
        "directorio": os.path.join(DIRECTORIO_GI, "Segundo_grado_medio"),
        "rama_origen": "Segundo_grado_medio",
        "rama_limpia": "Segundo_grado_medio_limpia",
        "titulo": "Segundo_grado_medio"
    },
    "Primer_grado_superior_DAW": {
        "directorio": os.path.join(DIRECTORIO_GI, "Primer_grado_superior_DAW"),
        "rama_origen": "Primer_grado_superior_DAW",
        "rama_limpia": "Primer_grado_superior_DAW_limpia",
        "titulo": "Primer_grado_superior_DAW"
    }
}

LISTA_GRADOS = list(CONFIGURACION_GRADOS.keys())

from backend.configuracion.normalizar_palabra import normalizar_palabra
from backend.configuracion.cargar_nombres_objetivo import cargar_nombres_objetivo
from backend.configuracion.cargar_colegios import cargar_palabras_clave_colegio
from backend.configuracion.cargar_palabras_protegidas import cargar_palabras_protegidas

NOMBRES_COMPLETOS, PALABRAS_NOMBRES = cargar_nombres_objetivo()
PALABRAS_PROTEGIDAS = cargar_palabras_protegidas()
PALABRAS_CLAVE_COLEGIO = cargar_palabras_clave_colegio()
