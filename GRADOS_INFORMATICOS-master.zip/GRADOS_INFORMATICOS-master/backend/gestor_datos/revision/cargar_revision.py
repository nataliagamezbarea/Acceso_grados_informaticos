import os
import json

from .ruta_revision import ruta_revision
from backend.gestor_datos import descargar_json_de_github

_CACHE_REV = None

def cargar_revision(forzar_remoto=False):
    """Carga el registro de revisiones siempre directamente desde GitHub."""
    global _CACHE_REV
    if _CACHE_REV is not None and not forzar_remoto:
        return _CACHE_REV
    remoto = descargar_json_de_github("almacen/datos/revision.json")
    if isinstance(remoto, dict):
        _CACHE_REV = remoto
        return _CACHE_REV
    p = ruta_revision()
    if os.path.exists(p):
        try:
            _CACHE_REV = json.load(open(p, encoding="utf-8"))
            return _CACHE_REV
        except Exception:
            pass
    _CACHE_REV = {}
    return _CACHE_REV

def fijar_cache_revision(rev):
    global _CACHE_REV
    _CACHE_REV = rev
