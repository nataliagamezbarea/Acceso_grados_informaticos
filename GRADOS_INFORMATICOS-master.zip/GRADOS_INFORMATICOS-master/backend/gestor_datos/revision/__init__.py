from .cargar_revision import cargar_revision
from .guardar_revision import guardar_revision
from .ruta_revision import ruta_revision
from .clave_registro import clave_registro
