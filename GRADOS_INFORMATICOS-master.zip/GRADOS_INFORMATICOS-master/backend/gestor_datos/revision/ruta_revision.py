import os

from backend.configuracion import DIRECTORIO_DATOS

def ruta_revision():
    """Ruta del registro de revisiones global (por autor/curso)."""
    return os.path.join(DIRECTORIO_DATOS, "revision.json")
