import os

def clave_registro(grado, archivo):
    """Clave única grado::basename para registros de estado."""
    return f"{grado}::{os.path.basename(archivo)}"
