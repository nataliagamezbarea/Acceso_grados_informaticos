import json

from .ruta_revision import ruta_revision
from .cargar_revision import fijar_cache_revision
from backend.gestor_datos import subir_json_a_github

def guardar_revision(rev):
    """Guarda el registro de revisiones localmente y en GitHub."""
    fijar_cache_revision(rev)
    json.dump(rev, open(ruta_revision(), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    try:
        subir_json_a_github(rev, "almacen/datos/revision.json", sincrono=True)
    except Exception:
        pass
