import os

from backend.configuracion import DIRECTORIO_DATOS

def ruta_reescrituras(grado):
    """Ruta del registro de reescrituras por grado."""
    return os.path.join(DIRECTORIO_DATOS, f"rewrites_{grado}.json")
