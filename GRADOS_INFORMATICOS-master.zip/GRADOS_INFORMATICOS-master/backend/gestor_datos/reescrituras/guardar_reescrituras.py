import json

from .ruta_reescrituras import ruta_reescrituras
from .cargar_reescrituras import _CACHE_RW
from backend.gestor_datos import subir_json_a_github

def guardar_reescrituras(grado, rw):
    """Guarda la lista de reescrituras de un grado localmente y en GitHub."""
    _CACHE_RW[grado] = rw
    json.dump(rw, open(ruta_reescrituras(grado), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    try:
        subir_json_a_github(rw, f"almacen/datos/rewrites_{grado}.json", sincrono=True)
    except Exception:
        pass
