import os

from backend.configuracion import DIRECTORIO_DATOS
from ..revision.clave_registro import clave_registro

def eliminar_enunciado_personalizado(grado, archivo):
    """Elimina el enunciado personalizado (PNG) de un documento si existe."""
    clave = clave_registro(grado, archivo)
    ruta = os.path.join(DIRECTORIO_DATOS, "enunciados", clave + ".png")
    if os.path.exists(ruta):
        os.remove(ruta)
        return True
    return False
