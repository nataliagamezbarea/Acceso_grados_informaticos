import os
import json

from .ruta_reescrituras import ruta_reescrituras
from backend.gestor_datos import descargar_json_de_github

_CACHE_RW = {}

def cargar_reescrituras(grado, forzar_remoto=False):
    """Carga la lista de reescrituras siempre directamente desde GitHub."""
    global _CACHE_RW
    if grado in _CACHE_RW and not forzar_remoto:
        return _CACHE_RW[grado]
    remoto = descargar_json_de_github(f"almacen/datos/rewrites_{grado}.json")
    if isinstance(remoto, list):
        _CACHE_RW[grado] = remoto
        return _CACHE_RW[grado]
    p = ruta_reescrituras(grado)
    if os.path.exists(p):
        try:
            _CACHE_RW[grado] = json.load(open(p, encoding="utf-8"))
            return _CACHE_RW[grado]
        except Exception:
            pass
    _CACHE_RW[grado] = []
    return _CACHE_RW[grado]
