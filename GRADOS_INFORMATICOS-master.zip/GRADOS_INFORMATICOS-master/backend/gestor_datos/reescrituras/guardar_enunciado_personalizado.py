import os

from backend.configuracion import DIRECTORIO_DATOS
from ..revision.clave_registro import clave_registro

def guardar_enunciado_personalizado(grado, archivo, png_data, start="", end="", new_text="", page=None, pct_top=None):
    """Guarda un enunciado personalizado como imagen PNG para el documento."""
    os.makedirs(DIRECTORIO_DATOS, exist_ok=True)
    clave = clave_registro(grado, archivo)
    ruta = os.path.join(DIRECTORIO_DATOS, "enunciados", clave + ".png")
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    
    # Convertir a bytes si es una cadena
    if isinstance(png_data, str):
        # Si es base64 o similar, decodificarlo
        try:
            import base64
            if png_data.startswith("data:"):
                # Extraer la parte base64 de data URL
                png_data = png_data.split(",")[1]
            png_data = base64.b64decode(png_data)
        except Exception:
            # Si falla la decodificación, intentar convertir directamente
            png_data = png_data.encode("utf-8")
    
    open(ruta, "wb").write(png_data)
    return True
