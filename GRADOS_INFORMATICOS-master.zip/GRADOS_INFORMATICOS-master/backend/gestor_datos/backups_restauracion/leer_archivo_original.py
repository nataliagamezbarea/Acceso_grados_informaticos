import os
import subprocess

from backend.configuracion import DIRECTORIO_BACKUPS
from ..visor_datos.obtener_directorio_repo import obtener_directorio_repo
from .guardar_en_backup import guardar_en_backup

def _descargar_de_github(grado, ruta_relativa):
    """Trasladado: baja el PDF desde la rama del grado en GitHub (con varios
    candidatos de ruta) cuando no hay repositorio local (p. ej. Vercel)."""
    try:
        from backend.gestor_datos.github_sync import descargar_bytes_de_github
    except Exception:
        return None
    candidatos = set()
    nombre = os.path.basename(ruta_relativa)
    if ruta_relativa.startswith("archivos/") or ruta_relativa.startswith("apuntes/"):
        candidatos.add(ruta_relativa)
    candidatos.add(nombre)
    candidatos.add(f"archivos/{nombre}")
    candidatos.add(f"apuntes/{nombre}")
    for c in candidatos:
        try:
            b = descargar_bytes_de_github(c, rama=grado)
            if b:
                return b
        except Exception:
            continue
    return None

def leer_archivo_original(grado, ruta_relativa):
    """Lee el contenido del archivo original desde el backup, el directorio de
    trabajo o, como último recurso, desde la rama del grado en GitHub."""
    # 1. Comprobar backup (obsoleto; guardar_en_backup ya no escribe) - se omite
    # 2. Comprobar directorio de trabajo
    dir_repo = obtener_directorio_repo(grado)
    archivo_local = os.path.join(dir_repo, ruta_relativa)
    if os.path.exists(archivo_local):
        try:
            return open(archivo_local, "rb").read()
        except Exception:
            pass

    # 3. Comprobar en subcarpetas archivos o apuntes
    for sub in ["", "archivos", "apuntes"]:
        p = os.path.join(dir_repo, sub, ruta_relativa) if sub else os.path.join(dir_repo, ruta_relativa)
        if os.path.exists(p):
            try:
                return open(p, "rb").read()
            except Exception:
                pass

    # 4. Fallback Git show (repositorio local de trabajo)
    try:
        r = subprocess.run(
            ["git", "-C", dir_repo, "show", f"HEAD:{ruta_relativa}"],
            capture_output=True
        )
        if r.returncode == 0:
            return r.stdout
    except Exception:
        pass

    # 5. Fallback GitHub (rama del grado) - imprescindible en serverless (Vercel)
    return _descargar_de_github(grado, ruta_relativa)
