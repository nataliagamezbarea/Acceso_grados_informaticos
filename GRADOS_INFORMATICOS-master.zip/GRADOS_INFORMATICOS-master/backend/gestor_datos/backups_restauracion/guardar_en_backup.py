import os
import shutil

from backend.configuracion import DIRECTORIO_BACKUPS

def guardar_en_backup(grado, ruta_relativa, datos):
    """Los originales se recuperan con el historial de Git; no se guardan copias
    en disco (desactivado: en serverless el disco es de solo lectura)."""
    return
