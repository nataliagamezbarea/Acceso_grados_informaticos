import os
from .leer_archivo_original import leer_archivo_original
from ..visor_datos.obtener_directorio_repo import obtener_directorio_repo
from ..revision.cargar_revision import cargar_revision
from ..revision.guardar_revision import guardar_revision
from ..revision.clave_registro import clave_registro
from ..reescrituras.cargar_reescrituras import cargar_reescrituras
from ..reescrituras.guardar_reescrituras import guardar_reescrituras

def eliminar_de_inicio_archivo(grado, archivo):
    """Elimina todo el historial (nombres, centro, enunciados, checks) de un archivo."""
    arch_base = os.path.basename(archivo)
    
    # 1. Limpiar revision.json (checks, nombres, colegios, imagenes, reflujo)
    try:
        rev = cargar_revision()
        k = clave_registro(grado, arch_base)
        if k in rev:
            del rev[k]
            guardar_revision(rev)
    except Exception:
        pass

    # 2. Limpiar rewrites_{grado}.json (enunciados personalizados e inclusion)
    #    OJO: rewrites_{grado}.json es una LISTA de entradas
    #    {"archivo": ..., "enunciados": [...], "new": ..., "include": ...},
    #    NO un diccionario con claves "rewrites"/"inclusion".
    try:
        rw = cargar_reescrituras(grado)
        if isinstance(rw, list):
            antes = len(rw)
            rw_filtrado = [e for e in rw if os.path.basename(e.get("archivo", "")) != arch_base]
            if len(rw_filtrado) != antes:
                guardar_reescrituras(grado, rw_filtrado)
    except Exception:
        pass

    # 3. Restaurar PDF físico al original si existe en backup
    try:
        datos = leer_archivo_original(grado, archivo)
        if datos:
            dir_repo = obtener_directorio_repo(grado)
            destino = os.path.join(dir_repo, archivo)
            os.makedirs(os.path.dirname(destino), exist_ok=True)
            open(destino, "wb").write(datos)
    except Exception:
        pass

    return True
