import os
import hashlib
import pymupdf as fitz

from ..visor_datos.obtener_directorio_repo import obtener_directorio_repo
from ..visor_datos.es_curriculum import es_curriculum
from ..visor_datos.limpiar_nombre_archivo import limpiar_nombre_archivo

def _restaurar_pdf_fisico(grado, nombre, datos, hash_borradas, mover_a_carpeta=None):
    """Genera un PDF limpio eliminando imágenes cuyo hash esté en hash_borradas."""
    try:
        src = fitz.open(stream=datos, filetype="pdf")
    except Exception as e:
        return False, f"No se pudo abrir el original: {e}"
    doc = fitz.open()
    total_eliminadas = 0
    for i in range(len(src)):
        p = src[i]
        nueva = doc.new_page(width=p.rect.width, height=p.rect.height)
        nueva.show_pdf_page(nueva.rect, src, i)
        for info in p.get_image_info(xrefs=True):
            xr = info.get("xref", 0)
            if not xr:
                continue
            try:
                stream = src.xref_stream(xr)
            except Exception:
                stream = None
            h = hashlib.md5(stream).hexdigest() if stream else None
            if h and h in hash_borradas:
                rects = info.get("bbox", [])
                for r in (rects if isinstance(rects, list) else [rects]):
                    try:
                        nueva.add_redact_annot(fitz.Rect(r), fill=(1, 1, 1))
                    except Exception:
                        pass
                total_eliminadas += 1
        nueva.apply_redactions()
    destino = os.path.join(obtener_directorio_repo(grado), nombre)
    if mover_a_carpeta:
        os.makedirs(mover_a_carpeta, exist_ok=True)
        destino = os.path.join(mover_a_carpeta, nombre)
    try:
        doc.save(destino, garbage=4, deflate=True)
    except Exception as e:
        return False, f"Error al guardar: {e}"
    src.close()
    doc.close()
    return True, f"{total_eliminadas} imagen(es) eliminada(s)"
