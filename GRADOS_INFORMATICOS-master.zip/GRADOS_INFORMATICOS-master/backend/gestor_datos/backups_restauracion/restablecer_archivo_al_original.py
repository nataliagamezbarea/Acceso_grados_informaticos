import os

from .leer_archivo_original import leer_archivo_original
from ..visor_datos.obtener_directorio_repo import obtener_directorio_repo

def restablecer_archivo_al_original(grado, archivo):
    """Sobrescribe el PDF de trabajo con el original (HEAD o backup)."""
    datos = leer_archivo_original(grado, archivo)
    if not datos:
        return False, "No se encontró el original"
    dir_repo = obtener_directorio_repo(grado)
    destino = os.path.join(dir_repo, archivo)
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    open(destino, "wb").write(datos)
    return True, "Restablecido al original"
