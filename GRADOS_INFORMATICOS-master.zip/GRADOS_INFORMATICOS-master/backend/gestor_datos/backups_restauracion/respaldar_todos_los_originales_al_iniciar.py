import os
import shutil

from backend.configuracion import LISTA_GRADOS, DIRECTORIO_BACKUPS
from ..visor_datos.obtener_directorio_repo import obtener_directorio_repo

def respaldar_todos_los_originales_al_iniciar():
    """El versionado y recuperación de originales se gestiona de forma nativa mediante el historial de Git."""
    return 0

