import os

from backend.configuracion import DIRECTORIO_DATOS
from ..revision.clave_registro import clave_registro

def restaurar_solo_contenido(grado, archivo):
    """Restaura únicamente el contenido (reescrituras) de un documento."""
    clave = clave_registro(grado, archivo)
    ruta = os.path.join(DIRECTORIO_DATOS, "contenido", clave + ".json")
    if os.path.exists(ruta):
        os.remove(ruta)
        return True
    return False
