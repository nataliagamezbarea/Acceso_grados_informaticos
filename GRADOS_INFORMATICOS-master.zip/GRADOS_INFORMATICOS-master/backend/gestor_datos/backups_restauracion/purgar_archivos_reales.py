import os

from backend.configuracion import LISTA_GRADOS
from .leer_archivo_original import leer_archivo_original
from ..visor_datos.obtener_directorio_repo import obtener_directorio_repo
from ..imagenes_globales.cargar_imagenes_borrar_global import cargar_imagenes_borrar_global
from ..imagenes_globales.guardar_imagenes_borrar_global import guardar_imagenes_borrar_global
from ._restaurar_pdf_fisico import _restaurar_pdf_fisico

def purgar_archivos_reales():
    """Elimina físicamente las imágenes marcadas para borrar en todos los grados."""
    total = 0
    for g in LISTA_GRADOS:
        datos = cargar_imagenes_borrar_global()
        if not datos:
            continue
        for archivo, info in list(datos.items()):
            if info.get("grado") != g:
                continue
            originales = leer_archivo_original(g, archivo)
            if not originales:
                continue
            hash_borradas = set(info.get("hashes", []))
            ok, _ = _restaurar_pdf_fisico(g, archivo, originales, hash_borradas)
            if ok:
                datos.pop(archivo, None)
                total += 1
        guardar_imagenes_borrar_global(datos)
    return total
