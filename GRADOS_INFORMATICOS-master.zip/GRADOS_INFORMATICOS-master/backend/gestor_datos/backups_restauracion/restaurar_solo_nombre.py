import os

from backend.configuracion import DIRECTORIO_DATOS
from ..revision.clave_registro import clave_registro
from .leer_archivo_original import leer_archivo_original

def restaurar_solo_nombre(grado, archivo):
    """Elimina el nombre personalizado guardado para un documento."""
    clave = clave_registro(grado, archivo)
    ruta = os.path.join(DIRECTORIO_DATOS, "nombres", clave + ".txt")
    if os.path.exists(ruta):
        os.remove(ruta)
        return True
    return False
