import os, json, base64, urllib.request, urllib.error, threading
from urllib.parse import quote

_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RAMA_DATOS, CARPETA_DATOS_GH = 'master', 'almacen/datos'
REPO_UTILIDADES_GRADO = 'nataliagamezbarea/utilidades-grado'

def _obtener_config_github():
    """Obtiene SIEMPRE el repo general y el token privado desde Supabase.

    El ADMIN trabaja contra el repositorio completo definido en
    configuracion_privada. No se usa configuracion_publica ni un repo/branch
    fijo para descubrir ramas o descargar archivos.
    """
    try:
        from backend.gestor_datos.leer_config_supabase import leer_config_supabase
        cfg = leer_config_supabase(("gh_repo_general", "gh_token"))
        repo = (cfg.get("gh_repo_general") or "").strip()
        token = (cfg.get("gh_token") or "").strip()
        if repo and token:
            return token, repo
    except Exception:
        pass
    return "", ""

def _headers_gh(token):
    return {'Authorization': f'Bearer {token}', 'Accept': 'application/vnd.github+json', 'User-Agent': 'Visor-Grados'}

def descargar_archivo_de_github(ruta_en_repo, rama='master'):
    token, repo = _obtener_config_github()
    if not token or not repo: return None
    url = f'https://api.github.com/repos/{repo}/contents/{ruta_en_repo}?ref={rama}'
    try:
        req = urllib.request.Request(url, headers=_headers_gh(token))
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            b = base64.b64decode(data.get('content', ''))
            local_p = os.path.join(_DIR, ruta_en_repo)
            os.makedirs(os.path.dirname(local_p), exist_ok=True)
            with open(local_p, 'wb') as f: f.write(b)
            return local_p
    except Exception: return None

def descargar_bytes_de_github(ruta_en_repo, rama='master'):
    """Descarga el contenido bruto (bytes) de un archivo desde una rama de GitHub.
    Usa la GitHub Contents API; para archivos que quepan en el límite (~1MB de la
    API) devuelve los bytes decodificados; si no, intenta raw.githubusercontent. De
    vuelve None si no lo encuentra."""
    token, repo = _obtener_config_github()
    if not token or not repo:
        return None
    try:
        url = f'https://api.github.com/repos/{repo}/contents/{quote(ruta_en_repo, safe="/")}?ref={quote(rama, safe="/")}'
        req = urllib.request.Request(url, headers=_headers_gh(token))
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            contenido = data.get('content', '')
            if isinstance(contenido, str) and contenido:
                import base64 as _b64
                return _b64.b64decode(contenido)
            if isinstance(contenido, list):  # objeto (dir) -> no es archivo
                return None
            # Archivos grandes (>1MB): la Contents API no devuelve 'content',
            # solo el download_url. Usarlo para obtener los bytes.
            durl = data.get('download_url')
            if durl:
                reqd = urllib.request.Request(durl, headers=_headers_gh(token))
                with urllib.request.urlopen(reqd, timeout=60) as respd:
                    return respd.read()
            return None
    except urllib.error.HTTPError as e:
        if e.code != 404:
            try:
                from urllib.parse import quote as _q
                raw_url = f'https://raw.githubusercontent.com/{repo}/{_q(rama, safe="/")}/{_q(ruta_en_repo, safe="/")}'
                reqr = urllib.request.Request(raw_url, headers=_headers_gh(token))
                with urllib.request.urlopen(reqr, timeout=60) as resp:
                    return resp.read()
            except Exception:
                pass
        return None
    except Exception:
        return None
    return None


def descargar_json_de_github(ruta_en_repo, rama='master'):
    p = descargar_archivo_de_github(ruta_en_repo, rama)
    if p and os.path.exists(p):
        try: return json.load(open(p, encoding='utf-8'))
        except Exception: pass
    return None

def _obtener_sha(token, repo, ruta_en_repo, rama):
    url = f'https://api.github.com/repos/{repo}/contents/{ruta_en_repo}?ref={rama}'
    try:
        req = urllib.request.Request(url, headers=_headers_gh(token))
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode('utf-8')).get('sha')
    except Exception:
        return None

def _subir_bytes_directo(raw_bytes, ruta_en_repo, rama, mensaje, token, repo):
    url_put = f'https://api.github.com/repos/{repo}/contents/{ruta_en_repo}'
    for intento in range(3):
        sha = _obtener_sha(token, repo, ruta_en_repo, rama)
        payload = {'message': mensaje or f'Actualizar {ruta_en_repo} desde Visor',
                   'content': base64.b64encode(raw_bytes).decode('utf-8'), 'branch': rama}
        if sha: payload['sha'] = sha
        req_put = urllib.request.Request(url_put, data=json.dumps(payload).encode('utf-8'),
                                         headers=_headers_gh(token), method='PUT')
        try:
            with urllib.request.urlopen(req_put, timeout=15): return True
        except urllib.error.HTTPError as e:
            if e.code == 409 and intento < 2: continue
            return False
        except Exception: return False
    return False

def subir_json_a_github(datos_o_ruta, ruta_en_repo, rama='master', mensaje=None, sincrono=False, repo_override=None):
    token, repo = _obtener_config_github()
    if not token or not repo: return False
    if repo_override:
        repo = repo_override
    if isinstance(datos_o_ruta, (dict, list)): raw_text = json.dumps(datos_o_ruta, ensure_ascii=False, indent=2)
    elif os.path.exists(str(datos_o_ruta)): raw_text = open(datos_o_ruta, encoding='utf-8').read()
    else: raw_text = str(datos_o_ruta)
    b = raw_text.encode('utf-8')
    if sincrono: return _subir_bytes_directo(b, ruta_en_repo, rama, mensaje, token, repo)
    threading.Thread(target=_subir_bytes_directo, args=(b, ruta_en_repo, rama, mensaje, token, repo), daemon=True).start()
    return True

def subir_archivo_a_github(ruta_local, ruta_en_repo, rama='master', mensaje=None, sincrono=False, repo_override=None):
    token, repo = _obtener_config_github()
    if not token or not repo or not os.path.exists(ruta_local): return False
    if repo_override:
        repo = repo_override
    with open(ruta_local, 'rb') as f: b = f.read()
    if sincrono: return _subir_bytes_directo(b, ruta_en_repo, rama, mensaje, token, repo)
    threading.Thread(target=_subir_bytes_directo, args=(b, ruta_en_repo, rama, mensaje, token, repo), daemon=True).start()
    return True


def asegurar_carpeta_en_github(ruta_carpeta, rama='master', repo_override=None,
                               archivo_marker='.gitkeep', mensaje=None):
    """Asegura que una carpeta existe en GitHub creando en ella un .gitkeep si
    falta. NO accede al disco local (imprescindible en serverless de solo
    lectura, p.ej. Vercel). Devuelve True si la carpeta ya existía o se creó;
    False si falta configuración o no se pudo escribir. Nunca lanza."""
    token, repo = _obtener_config_github()
    if not token or not repo:
        return False
    if repo_override:
        repo = repo_override
    ruta_marker = ruta_carpeta.rstrip('/') + '/' + archivo_marker
    try:
        url_get = f'https://api.github.com/repos/{repo}/contents/{ruta_marker}?ref={rama}'
        req = urllib.request.Request(url_get, headers=_headers_gh(token))
        with urllib.request.urlopen(req, timeout=15):
            return True
    except urllib.error.HTTPError as e:
        if e.code != 404:
            return False
    except Exception:
        return False
    return _subir_bytes_directo(
        b'', ruta_marker, rama,
        mensaje or f'Asegurar carpeta {ruta_carpeta}', token, repo
    )


def disparar_workflow_github(nombre_workflow, rama='master', inputs=None, repo_override=None):
    """Dispara un GitHub Actions workflow vía la API workflow_dispatch.

    Para que el flujo 'Compilar con GitHub Actions' funcione, el workflow debe
    existir en el repo en .github/workflows/<nombre_workflow>.yml y tener un
    evento workflow_dispatch. Devuelve True si GitHub acepta el disparo (202)."""
    token, repo = _obtener_config_github()
    if not token or not repo:
        return False
    if repo_override:
        repo = repo_override
    url = f'https://api.github.com/repos/{repo}/actions/workflows/{quote(nombre_workflow, safe="")}/dispatches'
    payload = {'ref': rama}
    if inputs:
        payload['inputs'] = inputs
    try:
        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'),
                                     headers=_headers_gh(token), method='POST')
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.status == 204 or resp.status == 202
    except urllib.error.HTTPError as e:
        if e.code == 409:
            return True  # el workflow ya está en cola/ejecutándose
        return False
    except Exception:
        return False


def existe_pdf_en_github(ruta_pdf, rama='master', repo_override=None):
    """Devuelve True si un PDF ya existe en el repo (p.ej. GI/<grado>/apuntes/<x>.pdf).
    Se usa para el polling tras disparar el workflow de compilación."""
    token, repo = _obtener_config_github()
    if not token or not repo:
        return False
    if repo_override:
        repo = repo_override
    url = f'https://api.github.com/repos/{repo}/contents/{quote(ruta_pdf, safe="/")}?ref={quote(rama, safe="/")}'
    try:
        req = urllib.request.Request(url, headers=_headers_gh(token))
        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.status == 200
    except urllib.error.HTTPError as e:
        return e.code == 200
    except Exception:
        return False


def listar_pdfs_de_rama(grado, rama=None, token_override=None, repo_override=None):
    """Lista los PDFs de una rama del repositorio GitHub SIN tocar el disco local
    (imprescindible en serverless de solo lectura, p.ej. Vercel).

    Usa la Git Data API (git/trees?recursive=1) para obtener todos los paths de
    la rama en una sola petición y devuelve una lista de rutas relativas que
    acaban en .pdf y viven bajo 'archivos/' o 'apuntes/'.
    """
    token, repo = _obtener_config_github()
    if not token or not repo:
        return None
    if token_override:
        token = token_override
    if repo_override:
        repo = repo_override
    rama = rama or grado or 'master'
    url = f'https://api.github.com/repos/{repo}/git/trees/{rama}?recursive=1'
    try:
        req = urllib.request.Request(url, headers=_headers_gh(token))
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError:
        return None
    except Exception:
        return None
    arbol = data.get('tree', []) if isinstance(data, dict) else []
    pdfs = []
    for item in arbol:
        if item.get('type') != 'blob':
            continue
        path = item.get('path', '')
        if not path.lower().endswith('.pdf'):
            continue
        if path.startswith('archivos/') or path.startswith('apuntes/'):
            pdfs.append(path)
    return pdfs
