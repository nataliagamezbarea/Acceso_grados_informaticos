import os
import json
import urllib.request
import urllib.parse

_RUTAS_ENV = (
    "/home/natalia/Escritorio/repositorios/Privados/GRADOS_INFORMATICOS-LOGIN/.env",
)

def _leer_env(nombre_clave):
    valor = os.environ.get(nombre_clave, "")
    if valor:
        return valor
    for ruta in _RUTAS_ENV:
        ruta = os.path.abspath(ruta)
        if os.path.exists(ruta):
            try:
                with open(ruta, "r", encoding="utf-8") as f:
                    for linea in f:
                        linea = linea.strip()
                        if linea and not linea.startswith("#") and linea.startswith(nombre_clave + "="):
                            return linea.split("=", 1)[1].strip().strip('"').strip("'")
            except Exception:
                continue
    return ""

def _clave_privada_supabase():
    # Nunca usa la clave publica/anon para leer la configuracion privada.
    for nombre in ("SUPABASE_SERVICE_ROLE_KEY", "SUPABASE_PRIVATE_KEY", "SUPABASE_SERVICE_KEY"):
        valor = _leer_env(nombre)
        if valor:
            return valor
    return ""

def leer_config_supabase(claves=None):
    """Lee configuracion privada de Supabase para el codigo ADMIN.

    Importante: esta funcion NO toca configuracion_publica ni usa la anon key.
    La configuracion se obtiene de grados-informaticos.configuracion_privada
    mediante la clave service-role/private.
    """
    url = _leer_env("SUPABASE_URL")
    clave = _clave_privada_supabase()
    if not url or not clave:
        return {}

    claves = list(claves or ("gh_repo_general", "gh_token"))
    q = urllib.parse.urlencode({
        "clave": "in.(" + ",".join(claves) + ")",
        "select": "clave,valor",
    })
    # La tabla esta en un esquema propio, no en public.
    endpoint = f"{url.rstrip('/')}/rest/v1/configuracion_privada?{q}"
    req = urllib.request.Request(
        endpoint,
        headers={
            "apikey": clave,
            "Authorization": f"Bearer {clave}",
            "Accept": "application/json",
            "Accept-Profile": "grados-informaticos",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            filas = json.loads(resp.read().decode("utf-8"))
        return {r.get("clave"): r.get("valor", "") for r in (filas or []) if r.get("clave")}
    except Exception:
        return {}
