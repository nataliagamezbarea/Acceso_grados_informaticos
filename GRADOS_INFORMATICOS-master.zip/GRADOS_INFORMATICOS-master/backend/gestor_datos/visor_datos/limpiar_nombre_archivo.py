import re

from backend.configuracion import PALABRAS_NOMBRES

def limpiar_nombre_archivo(nombre_archivo):
    """Elimina nombres de autores, apellidos y conectores del nombre de archivo."""
    nombre = nombre_archivo
    fichas = list(PALABRAS_NOMBRES)
    for _ in range(5):
        for tok in fichas:
            pat = rf'(?:[_\-\s\(\)]+(?:JUNTO[_\-\s]+A|CON|Y|I|[_\-])[_\-\s\(\)]+)?(?:^|[_\-\s\(\)\[\]\.])+{tok}(?=$|[_\-\s\(\)\[\]\.])+(?:[_\-\s\(\)]+(?:JUNTO[_\-\s]+A|CON|Y|I|[_\-])[_\-\s\(\)]+)?'
            nombre = re.sub(pat, '_', nombre, flags=re.IGNORECASE)

    nombre = re.sub(r'(?:^|[_\-\s])(?:JUNTO[_\-\s]*A|CON)(?=$|[_\-\s])', '_', nombre, flags=re.IGNORECASE)
    nombre = re.sub(r'[\(\)\[\]]', '', nombre)
    nombre = re.sub(r'[_\-\s]+', '_', nombre)
    nombre = re.sub(r'^[_\-\s]+|[_\-\s]+(?=\.pdf$)', '', nombre, flags=re.IGNORECASE)
    nombre = re.sub(r'\.+pdf$', '.pdf', nombre, flags=re.IGNORECASE)
    if not nombre or nombre.lower() == '.pdf':
        nombre = nombre_archivo
    return nombre
