import os

from backend.configuracion import LISTA_GRADOS, CONFIGURACION_GRADOS
from ..revision.cargar_revision import cargar_revision
from ..reescrituras.cargar_reescrituras import cargar_reescrituras
from .obtener_directorio_repo import obtener_directorio_repo
from .limpiar_nombre_archivo import limpiar_nombre_archivo
from ..revision.clave_registro import clave_registro
from .es_curriculum import es_curriculum
from ..github_sync import listar_pdfs_de_rama


def construir_datos_visor():
    """Genera la estructura de datos completa para el visor interactivo."""
    datos = {}
    datos_brutos = {}
    rev = cargar_revision()

    for g in LISTA_GRADOS:
        dir_repo = obtener_directorio_repo(g)
        rw = cargar_reescrituras(g)
        datos_brutos[g] = rw

        mapa_todos_pdfs = {}
        for raiz, _, archivos in os.walk(dir_repo):
            if '.git' in raiz:
                continue
            for f in archivos:
                if f.lower().endswith(".pdf"):
                    rel = os.path.relpath(os.path.join(raiz, f), dir_repo)
                    mapa_todos_pdfs[f] = rel
                    mapa_todos_pdfs[rel] = rel

        if not mapa_todos_pdfs:
            remotos = listar_pdfs_de_rama(g, rama=CONFIGURACION_GRADOS[g].get("rama_origen", g))
            if remotos:
                for rel in remotos:
                    f = os.path.basename(rel)
                    mapa_todos_pdfs[f] = rel
                    mapa_todos_pdfs[rel] = rel

        entradas = []
        cubiertos = set()
        for i, e in enumerate(rw):
            arch_bruto = e.get("archivo", "")
            arch = os.path.basename(arch_bruto)
            ruta_rel = mapa_todos_pdfs.get(arch, mapa_todos_pdfs.get(arch_bruto, f"archivos/{arch}"))
            cubiertos.add(arch)
            cubiertos.add(ruta_rel)

            nuevo = (e.get("new") or "").strip()
            antiguo = e.get("start", "")
            nombre_limpio = limpiar_nombre_archivo(arch)
            info_rev = rev.get(clave_registro(g, arch), {})
            esta_en_apuntes = ruta_rel.startswith("apuntes/")

            if "inc_apunte" in info_rev:
                es_apunte_val = bool(info_rev["inc_apunte"])
            else:
                es_apunte_val = (esta_en_apuntes or arch.upper().startswith("APUNTE_") or nombre_limpio.upper().startswith("APUNTE_"))

            entradas.append({
                "idx": i,
                "archivo": arch,
                "rel_path": ruta_rel,
                "carpeta": os.path.dirname(ruta_rel) or "raíz",
                "nombre_limpio": nombre_limpio,
                "cambia_nombre": (nombre_limpio != arch),
                "inc_nombre": bool(info_rev.get("inc_nombre", False)),
                "inc_interior": bool(info_rev.get("inc_interior", True)),
                "inc_colegio": bool(info_rev.get("inc_colegio", True)),
                "inc_internet": bool(info_rev.get("inc_internet", False)),
                "inc_apunte": es_apunte_val,
                "nombre_apunte": info_rev.get("nombre_apunte", ""),
                "latex_compilado": bool(info_rev.get("latex_compilado", False)),
                "old": antiguo,
                "new": nuevo,
                "start": e.get("start", ""),
                "end": e.get("end", ""),
                "enunciados_count": len(e.get("enunciados", [])),
                "is_cv": es_curriculum(arch),
                "cambia": bool(nuevo or e.get("enunciados")),
                "include": bool(e.get("include", True)),
                "visto": bool(info_rev.get("visto", False)),
                "decision": info_rev.get("decision", "")
            })

        no_cambian = []
        base_idx = len(entradas)
        for i, (f, ruta_rel) in enumerate(sorted(mapa_todos_pdfs.items())):
            if f in cubiertos or ruta_rel in cubiertos or "/" in f:
                continue
            cubiertos.add(f)
            cubiertos.add(ruta_rel)

            nombre_limpio = limpiar_nombre_archivo(f)
            info_rev = rev.get(clave_registro(g, f), {})
            esta_en_apuntes = ruta_rel.startswith("apuntes/")

            if "inc_apunte" in info_rev:
                es_apunte_val = bool(info_rev["inc_apunte"])
            else:
                es_apunte_val = (esta_en_apuntes or f.upper().startswith("APUNTE_") or nombre_limpio.upper().startswith("APUNTE_"))

            no_cambian.append({
                "idx": base_idx + i,
                "archivo": f,
                "rel_path": ruta_rel,
                "carpeta": os.path.dirname(ruta_rel) or "raíz",
                "nombre_limpio": nombre_limpio,
                "cambia_nombre": (nombre_limpio != f),
                "inc_nombre": bool(info_rev.get("inc_nombre", False)),
                "inc_interior": bool(info_rev.get("inc_interior", False)),
                "inc_colegio": bool(info_rev.get("inc_colegio", False)),
                "inc_internet": bool(info_rev.get("inc_internet", False)),
                "inc_apunte": es_apunte_val,
                "nombre_apunte": info_rev.get("nombre_apunte", ""),
                "latex_compilado": bool(info_rev.get("latex_compilado", False)),
                "is_cv": es_curriculum(f),
                "visto": bool(info_rev.get("visto", False)),
                "decision": info_rev.get("decision", "")
            })

        datos[g] = {
            "dir": dir_repo,
            "titulo": CONFIGURACION_GRADOS[g]["titulo"],
            "total_archivos": len(entradas) + len(no_cambian),
            "entries": entradas,
            "no_cambian": no_cambian
        }
    return datos, datos_brutos
