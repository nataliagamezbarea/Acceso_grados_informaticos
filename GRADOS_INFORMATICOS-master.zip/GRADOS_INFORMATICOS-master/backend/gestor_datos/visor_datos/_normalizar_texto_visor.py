import re

def _normalizar_texto_visor(texto):
    """Normaliza texto para comparación de enunciados en el visor."""
    t = texto.lower()
    t = re.sub(r'[\s]+', ' ', t)
    t = re.sub(r'[^\w\s]', '', t)
    t = re.sub(r'(?:\b|_)(?:ej|ejercicio|problema|practica|p)\b', '', t)
    t = re.sub(r'[\s]+', ' ', t).strip()
    return t
