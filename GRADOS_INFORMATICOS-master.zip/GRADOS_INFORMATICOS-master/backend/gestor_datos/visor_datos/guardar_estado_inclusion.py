import os

from backend.configuracion import DIRECTORIO_DATOS
from ..revision.clave_registro import clave_registro
from ..imagenes_globales.cargar_imagenes_borrar_global import cargar_imagenes_borrar_global
from ..imagenes_globales.guardar_imagenes_borrar_global import guardar_imagenes_borrar_global

def guardar_estado_inclusion(grado, archivo, incluir):
    """Marca un documento como incluido o excluido en la revista."""
    os.makedirs(DIRECTORIO_DATOS, exist_ok=True)
    clave = clave_registro(grado, archivo)
    datos = cargar_imagenes_borrar_global()
    if clave not in datos:
        datos[clave] = {}
    datos[clave]["incluido"] = bool(incluir)
    guardar_imagenes_borrar_global(datos)
    return True
