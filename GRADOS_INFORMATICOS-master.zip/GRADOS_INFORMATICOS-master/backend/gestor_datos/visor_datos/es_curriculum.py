def es_curriculum(nombre_archivo):
    """Determina si un documento es un CV que debe preservarse."""
    fn = nombre_archivo.upper()
    return "CURRICULUM" in fn or "VIDEOCURRICULUM" in fn or "CV" in fn
