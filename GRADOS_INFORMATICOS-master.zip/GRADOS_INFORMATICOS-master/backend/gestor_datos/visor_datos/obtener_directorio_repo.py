import os
from backend.configuracion import CONFIGURACION_GRADOS, DIRECTORIO_GI

def obtener_directorio_repo(grado):
    """Devuelve el directorio del repositorio correspondiente al grado / rama."""
    if grado in CONFIGURACION_GRADOS:
        return CONFIGURACION_GRADOS[grado]["directorio"]
    return os.path.join(DIRECTORIO_GI, grado)

