import re

from ._normalizar_texto_visor import _normalizar_texto_visor

def _pagina_tiene_enunciado_completo(texto_pagina, enunciado):
    """Comprueba si la página contiene el enunciado completo (comparación
    normalizada tolerante a números/etiquetas)."""
    if not enunciado:
        return False
    norm_pag = _normalizar_texto_visor(texto_pagina)
    norm_en = _normalizar_texto_visor(enunciado)
    norm_en = re.sub(r'\s*\d+\s*$', '', norm_en).strip()
    base = norm_en
    if ' ' in base:
        palabras = base.split()
        if len(palabras) > 4:
            base = ' '.join(palabras[:4])
    return base in norm_pag
