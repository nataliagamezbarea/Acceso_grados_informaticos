import json
from .ruta_imagenes_conservar_global import ruta_imagenes_conservar_global

def guardar_imagenes_conservar_global(reg):
    json.dump(reg, open(ruta_imagenes_conservar_global(), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
