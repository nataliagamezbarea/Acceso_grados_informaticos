import os
from ..revision.cargar_revision import cargar_revision
from ..revision.guardar_revision import guardar_revision
from ..revision.clave_registro import clave_registro
from backend.configuracion import DIRECTORIO_CACHE, DIRECTORIO_CACHE_IMAGENES

def guardar_accion_imagen(grado, archivo, img_id, accion, ruta_reemplazo=None, cita_texto=None, auto_internet=False, manual=False):
    """Guarda la acción a realizar sobre una imagen (borrar, reemplazar, citar, restaurar)."""
    arch_base = os.path.basename(archivo)
    rev = cargar_revision()
    k = clave_registro(grado, arch_base)
    if k not in rev:
        rev[k] = {}
    if "imagenes" not in rev[k]:
        rev[k]["imagenes"] = {}

    if accion == "restaurar":
        if img_id in rev[k]["imagenes"]:
            del rev[k]["imagenes"][img_id]
    else:
        info_prev = rev[k]["imagenes"].get(img_id, {})
        rev[k]["imagenes"][img_id] = {
            "accion": accion,
            "ruta": ruta_reemplazo if ruta_reemplazo is not None else info_prev.get("ruta"),
            "cita": cita_texto if cita_texto is not None else info_prev.get("cita"),
            "auto_internet": auto_internet,
            "manual": manual or (not auto_internet),
        }
    guardar_revision(rev)
    try:
        from backend.procesador_pdf import limpiar_cache_pdf
        limpiar_cache_pdf(grado, arch_base)
    except Exception:
        pass
    return True
