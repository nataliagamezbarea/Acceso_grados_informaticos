from .cargar_imagenes_conservar_global import cargar_imagenes_conservar_global
from .guardar_imagenes_conservar_global import guardar_imagenes_conservar_global

def registrar_imagen_conservar_global(hash_img, grado, archivo, img_id):
    if not hash_img:
        return False
    reg = cargar_imagenes_conservar_global()
    reg[hash_img] = {"grado": grado, "archivo": archivo, "img_id": img_id}
    guardar_imagenes_conservar_global(reg)
    return True
