import os
import json
from .ruta_imagenes_conservar_global import ruta_imagenes_conservar_global

def cargar_imagenes_conservar_global():
    p = ruta_imagenes_conservar_global()
    if os.path.exists(p):
        try:
            return json.load(open(p, encoding="utf-8"))
        except Exception:
            return {}
    return {}
