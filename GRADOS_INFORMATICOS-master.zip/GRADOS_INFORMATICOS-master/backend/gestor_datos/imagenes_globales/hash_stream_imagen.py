import hashlib

def hash_stream_imagen(doc, xref):
    """Hash MD5 del STREAM binario de la imagen (identidad literal del archivo
    de imagen dentro del PDF). Devuelve None si no puede extraerse."""
    try:
        datos = doc.xref_stream(int(xref))
        if datos:
            return hashlib.md5(datos).hexdigest()
    except Exception:
        pass
    try:
        pix = __import__("pymupdf").Pixmap(doc, int(xref))
        h = hashlib.md5(pix.samples).hexdigest()
        return h
    except Exception:
        return None
