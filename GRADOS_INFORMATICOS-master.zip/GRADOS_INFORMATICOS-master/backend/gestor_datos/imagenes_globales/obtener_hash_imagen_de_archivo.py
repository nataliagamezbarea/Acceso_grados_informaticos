import os
import tempfile
import pymupdf as fitz

from ..backups_restauracion.leer_archivo_original import leer_archivo_original
from .hash_stream_imagen import hash_stream_imagen

def obtener_hash_imagen_de_archivo(grado, archivo, num_pagina, img_idx):
    """Abre el PDF ORIGINAL y calcula el hash de la imagen (page, idx) tal y como
    las enumera el visor (mismo orden que get_image_info / get_images)."""
    datos = leer_archivo_original(grado, archivo)
    if not datos:
        return None
    tf_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tf:
            tf.write(datos)
            tf_path = tf.name
        doc = fitz.open(tf_path)
        if not (0 <= num_pagina < len(doc)):
            doc.close()
            return None
        pagina = doc[num_pagina]
        infos = pagina.get_image_info(xrefs=True)
        if 0 <= img_idx < len(infos):
            xr = infos[img_idx].get("xref", 0)
            if xr:
                h = hash_stream_imagen(doc, xr)
                doc.close()
                return h
        # Fallback al orden de get_images()
        imgs = pagina.get_images(full=True)
        if 0 <= img_idx < len(imgs):
            h = hash_stream_imagen(doc, imgs[img_idx][0])
            doc.close()
            return h
        doc.close()
    except Exception:
        pass
    finally:
        try:
            if tf_path and os.path.exists(tf_path):
                os.remove(tf_path)
        except Exception:
            pass
    return None
