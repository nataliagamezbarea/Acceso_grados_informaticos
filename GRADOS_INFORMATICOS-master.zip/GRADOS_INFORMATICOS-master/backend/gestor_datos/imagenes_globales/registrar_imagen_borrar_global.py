from .cargar_imagenes_borrar_global import cargar_imagenes_borrar_global
from .guardar_imagenes_borrar_global import guardar_imagenes_borrar_global

def registrar_imagen_borrar_global(hash_img, grado, archivo, img_id):
    """Registra el hash de una imagen que el usuario ha borrado para que, en
    adelante, se elimine POR DEFECTO de todos los PDFs donde aparezca igual."""
    if not hash_img:
        return False
    reg = cargar_imagenes_borrar_global()
    reg[hash_img] = {"grado": grado, "archivo": archivo, "img_id": img_id}
    guardar_imagenes_borrar_global(reg)
    return True
