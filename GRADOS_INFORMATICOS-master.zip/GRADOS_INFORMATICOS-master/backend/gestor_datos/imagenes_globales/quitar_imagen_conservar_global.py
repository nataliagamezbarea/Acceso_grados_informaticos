from .cargar_imagenes_conservar_global import cargar_imagenes_conservar_global
from .guardar_imagenes_conservar_global import guardar_imagenes_conservar_global

def quitar_imagen_conservar_global(hash_img):
    if not hash_img:
        return False
    reg = cargar_imagenes_conservar_global()
    if hash_img in reg:
        del reg[hash_img]
        guardar_imagenes_conservar_global(reg)
        return True
    return False
