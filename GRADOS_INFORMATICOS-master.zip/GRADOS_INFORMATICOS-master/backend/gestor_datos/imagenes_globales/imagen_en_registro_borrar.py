from .cargar_imagenes_borrar_global import cargar_imagenes_borrar_global

def imagen_en_registro_borrar(hash_img):
    if not hash_img:
        return False
    return hash_img in cargar_imagenes_borrar_global()
