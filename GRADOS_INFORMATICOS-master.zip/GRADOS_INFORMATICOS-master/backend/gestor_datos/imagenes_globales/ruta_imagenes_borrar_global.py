import os

from backend.configuracion import DIRECTORIO_DATOS

def ruta_imagenes_borrar_global():
    return os.path.join(DIRECTORIO_DATOS, "imagenes_borrar_globales.json")
