import os
from backend.configuracion import DIRECTORIO_DATOS

def ruta_imagenes_conservar_global():
    return os.path.join(DIRECTORIO_DATOS, "imagenes_conservar_globales.json")
