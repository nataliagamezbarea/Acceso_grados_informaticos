import json

from .ruta_imagenes_borrar_global import ruta_imagenes_borrar_global
from backend.gestor_datos import subir_json_a_github

def guardar_imagenes_borrar_global(reg):
    json.dump(reg, open(ruta_imagenes_borrar_global(), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    try:
        subir_json_a_github(reg, "almacen/datos/imagenes_borrar_globales.json", sincrono=True)
    except Exception:
        pass
