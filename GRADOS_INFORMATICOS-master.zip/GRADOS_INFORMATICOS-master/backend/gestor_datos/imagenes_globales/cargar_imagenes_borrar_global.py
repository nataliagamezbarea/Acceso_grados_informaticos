import os
import json

from .ruta_imagenes_borrar_global import ruta_imagenes_borrar_global
from backend.gestor_datos import descargar_json_de_github

_CACHE_IMG_BORRAR = None

def cargar_imagenes_borrar_global(forzar_remoto=False):
    global _CACHE_IMG_BORRAR
    if _CACHE_IMG_BORRAR is not None and not forzar_remoto:
        return _CACHE_IMG_BORRAR
    remoto = descargar_json_de_github("almacen/datos/imagenes_borrar_globales.json")
    if isinstance(remoto, dict):
        _CACHE_IMG_BORRAR = remoto
        return _CACHE_IMG_BORRAR
    p = ruta_imagenes_borrar_global()
    if os.path.exists(p):
        try:
            _CACHE_IMG_BORRAR = json.load(open(p, encoding="utf-8"))
            return _CACHE_IMG_BORRAR
        except Exception:
            pass
    _CACHE_IMG_BORRAR = {}
    return _CACHE_IMG_BORRAR
