from .cargar_imagenes_borrar_global import cargar_imagenes_borrar_global
from .guardar_imagenes_borrar_global import guardar_imagenes_borrar_global

def quitar_imagen_borrar_global(hash_img):
    """Desregistra un hash del registro global de borrados (al pulsar
    'Restaurar Original' sobre la imagen): deja de auto-borrarse en TODOS los
    PDFs y vuelve a aparecer al regenerar las previsualizaciones."""
    if not hash_img:
        return False
    reg = cargar_imagenes_borrar_global()
    if hash_img in reg:
        del reg[hash_img]
        guardar_imagenes_borrar_global(reg)
        return True
    return False
