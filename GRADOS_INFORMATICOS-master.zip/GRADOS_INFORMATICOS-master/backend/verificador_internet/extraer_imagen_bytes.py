import os
import pymupdf as fitz

from backend.gestor_datos import leer_archivo_original
from backend.verificador_internet.buscar_ruta_pdf import buscar_ruta_pdf

def extraer_imagen_bytes(grado, nombre_archivo, num_pagina, img_idx):
    """Extrae los bytes y extensión de una imagen concreta de un PDF."""
    datos_pdf = leer_archivo_original(grado, nombre_archivo)
    if not datos_pdf:
        ruta_pdf = buscar_ruta_pdf(grado, nombre_archivo)
        if ruta_pdf and os.path.exists(ruta_pdf):
            try:
                datos_pdf = open(ruta_pdf, "rb").read()
            except Exception:
                pass
    if not datos_pdf:
        return None, None

    try:
        doc = fitz.open(stream=datos_pdf, filetype="pdf")
        if num_pagina < 0 or num_pagina >= len(doc):
            doc.close()
            return None, None
        pagina = doc[num_pagina]
        
        xref = None
        try:
            img_infos = pagina.get_image_info(xrefs=True)
            if img_infos and 0 <= img_idx < len(img_infos):
                xref = img_infos[img_idx].get("xref")
        except Exception:
            xref = None

        if not xref or xref <= 0:
            imgs = pagina.get_images()
            if 0 <= img_idx < len(imgs):
                xref = imgs[img_idx][0]
                
        if not xref or xref <= 0:
            doc.close()
            return None, None

        base_img = doc.extract_image(xref)
        doc.close()
        
        if not base_img or "image" not in base_img:
            return None, None
        return base_img["image"], base_img.get("ext", "png")
    except Exception as e:
        print(f"Error al extraer imagen: {e}")
        return None, None
