import re

from backend.verificador_internet.busqueda_inversa_por_imagen import _busqueda_inversa_por_imagen

def _analizar_resultados(img_bytes, ext, headers):
    """Realiza la búsqueda inversa y determina si la imagen existe en Internet.

    Devuelve (existe, detalles, fuentes_encontradas, url_busqueda)."""
    existe = False
    detalles = ""
    fuentes_encontradas = []
    url_busqueda = ""

    try:
        url_busqueda, html = _busqueda_inversa_por_imagen(img_bytes, ext, headers)

        es_busqueda_valida = any(k in url_busqueda for k in ["vsrid=", "udm=", "tbs=sbi", "/search?"])
        
        marcadores_coincidencia = [
            "Pages that include matching images",
            "Páginas que incluyen imágenes coincidentes",
            "Visual matches",
            "Coincidencias visuales",
            "Best guess for this image",
            "Búsqueda relacionada",
            "Coincidencia visual",
            "Resultados visuales",
            "Buscar fuente de la imagen"
        ]
        
        enlaces_externos = re.findall(r'href="(https?://[^"]+?)"', html)
        vistos = []
        for e in enlaces_externos:
            if e not in vistos and not any(d in e for d in ["google", "gstatic", "consent", "schema.org", "w3.org"]):
                vistos.append(e)
            if len(vistos) >= 5:
                break
        fuentes_encontradas = vistos

        if any(m in html for m in marcadores_coincidencia) or len(fuentes_encontradas) > 0:
            existe = True
            if fuentes_encontradas:
                urls_str = "\n".join(fuentes_encontradas)
                detalles = f"Google Imágenes / Lens ha encontrado coincidencias de esta imagen en las siguientes URLs:\n{urls_str}"
            elif url_busqueda:
                # Si encontró coincidencias pero no pudo extraer URLs específicas,
                # muestra el enlace a la búsqueda de Google
                detalles = f"Google Imágenes / Lens ha encontrado coincidencias visuales de esta imagen en la web.\n🔗 URL de búsqueda: {url_busqueda}"
            else:
                detalles = "Google Imágenes / Lens ha encontrado coincidencias visuales de esta imagen en la web."
        else:
            existe = False
            detalles = "No se han encontrado coincidencias de esta imagen en la web."

    except Exception as e:
        detalles = f"No se pudo completar la búsqueda inversa por imagen ({e})."
        existe = False

    return existe, detalles, fuentes_encontradas, url_busqueda
