import os

from backend.configuracion import CONFIGURACION_GRADOS

def buscar_ruta_pdf(grado, nombre_archivo):
    """Localiza la ruta real del PDF dentro del repositorio del grado."""
    if grado not in CONFIGURACION_GRADOS:
        return None
    dir_repo = CONFIGURACION_GRADOS[grado]["directorio"]
    for root, _, files in os.walk(dir_repo):
        if '.git' in root:
            continue
        for f in files:
            if f == nombre_archivo or os.path.basename(f) == nombre_archivo:
                return os.path.join(root, f)
    return None
