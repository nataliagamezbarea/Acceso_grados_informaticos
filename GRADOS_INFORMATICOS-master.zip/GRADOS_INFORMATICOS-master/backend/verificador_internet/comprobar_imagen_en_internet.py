import urllib.parse

from backend.gestor_datos import guardar_accion_imagen
from backend.verificador_internet.extraer_imagen_bytes import extraer_imagen_bytes
from backend.verificador_internet.analizar_resultados import _analizar_resultados

def comprobar_imagen_en_internet(grado, nombre_archivo, num_pagina, img_idx, auto_borrar_si_existe=False):
    """
    Verifica si una imagen del PDF existe públicamente en Internet mediante
    búsqueda inversa POR LA PROPIA IMAGEN.
    Si auto_borrar_si_existe es True y se detecta en la red, la marca automáticamente para borrar.
    """
    img_id = f"p{num_pagina}_img{img_idx}"
    img_bytes, ext = extraer_imagen_bytes(grado, nombre_archivo, num_pagina, img_idx)
    if not img_bytes:
        return {
            "ok": False,
            "img_id": img_id,
            "existe_en_internet": False,
            "mensaje": "No se pudo extraer la imagen del documento PDF.",
            "detalles": "No se pudo extraer la imagen del documento PDF.",
            "fuentes": [],
            "cita_autor": "",
            "url_busqueda": ""
        }

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
        "Cookie": "SOCS=CAESHAgBEhJnd3NfMjAyNDAxMTUtMF9SQzEaAmVzIAEaBgiA_a-tBg; CONSENT=YES+cb.20210328-17-p0.es+FX+111"
    }

    existe, detalles, fuentes_encontradas, url_busqueda = _analizar_resultados(img_bytes, ext, headers)

    cita_texto = ""
    if existe:
        dominio_fuente = ""
        for f in fuentes_encontradas:
            try:
                host = urllib.parse.urlparse(f).netloc.replace("www.", "").strip()
                if host and not any(g in host for g in ["google", "gstatic", "schema.org", "w3.org"]):
                    dominio_fuente = host
                    break
            except Exception:
                pass
        if fuentes_encontradas:
            cita_texto = f"Fuente: {fuentes_encontradas[0]}"
        elif dominio_fuente:
            cita_texto = f"Fuente: {dominio_fuente}"
        else:
            cita_texto = "Fuente: Internet"

    accion_aplicada = "ninguna"
    if auto_borrar_si_existe:
        if not existe:
            guardar_accion_imagen(grado, nombre_archivo, img_id, "borrar", auto_internet=True)
            accion_aplicada = "borrada_automaticamente"
        else:
            guardar_accion_imagen(grado, nombre_archivo, img_id, "citar", cita_texto=cita_texto, auto_internet=True)
            accion_aplicada = "citada_debajo"
    elif existe:
        guardar_accion_imagen(grado, nombre_archivo, img_id, "citar", cita_texto=cita_texto, auto_internet=True)
        accion_aplicada = "citada_debajo"

    return {
        "ok": True,
        "img_id": img_id,
        "existe_en_internet": existe,
        "mensaje": "Imagen no encontrada en Internet (marcada para borrar automáticamente)" if (not existe and auto_borrar_si_existe) else ("Imagen encontrada en Internet (citada debajo)" if existe else "No encontrada en Internet"),
        "detalles": detalles,
        "fuentes": fuentes_encontradas,
        "cita_autor": cita_texto,
        "accion_aplicada": accion_aplicada,
        "url_busqueda": url_busqueda
    }
