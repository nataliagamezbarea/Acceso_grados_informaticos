import os

def _construir_cuerpo_multipart(campos, nombre_campo_archivo, nombre_archivo, datos_archivo, tipo_contenido):
    """Construye manualmente un cuerpo multipart/form-data para subir la imagen."""
    boundary = "----ImgSearchBoundary" + os.urandom(8).hex()
    partes = []
    for clave, valor in campos.items():
        partes.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{clave}"\r\n\r\n{valor}\r\n'.encode("utf-8"))
    partes.append(
        f'--{boundary}\r\nContent-Disposition: form-data; name="{nombre_campo_archivo}"; filename="{nombre_archivo}"\r\n'
        f'Content-Type: {tipo_contenido}\r\n\r\n'.encode("utf-8")
    )
    partes.append(datos_archivo)
    partes.append(f'\r\n--{boundary}--\r\n'.encode("utf-8"))
    cuerpo = b"".join(partes)
    return cuerpo, boundary
