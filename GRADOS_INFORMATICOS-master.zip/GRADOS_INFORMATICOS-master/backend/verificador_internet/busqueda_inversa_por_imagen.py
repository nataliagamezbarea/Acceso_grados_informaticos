import urllib.request

from backend.verificador_internet.construir_cuerpo_multipart import _construir_cuerpo_multipart

def _busqueda_inversa_por_imagen(img_bytes, ext, headers):
    """Sube la imagen a Google Images / Lens y devuelve la URL de resultados + el HTML."""
    ext_norm = (ext or "png").lower()
    tipo_contenido = f"image/{ext_norm}" if ext_norm not in ["jpg", "jpeg"] else "image/jpeg"
    cuerpo, boundary = _construir_cuerpo_multipart(
        {}, "encoded_image", f"imagen.{ext_norm}", img_bytes, tipo_contenido
    )
    req_headers = dict(headers)
    req_headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
    if "Cookie" not in req_headers:
        req_headers["Cookie"] = "SOCS=CAESHAgBEhJnd3NfMjAyNDAxMTUtMF9SQzEaAmVzIAEaBgiA_a-tBg; CONSENT=YES+cb.20210328-17-p0.es+FX+111"
        
    req = urllib.request.Request(
        "https://www.google.com/searchbyimage/upload",
        data=cuerpo,
        headers=req_headers,
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=10) as response:
        html = response.read().decode("utf-8", errors="ignore")
        url_resultados = response.geturl()
    return url_resultados, html
