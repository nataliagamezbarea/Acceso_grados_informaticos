import pymupdf as fitz

from backend.procesador_pdf.reescritura.orquestador._procesar_una_imagen import _procesar_una_imagen


def _procesar_imagenes(pagina, pno, doc, acciones_imagenes, hacer_internet, grado, nombre_archivo, registro_borrar):
    rects_imagenes_borradas = []
    modificado_en_esta_pagina = False
    img_infos = []
    try:
        img_infos = pagina.get_image_info(xrefs=True)
    except Exception:
        img_infos = []
    if not img_infos:
        imgs_raw = pagina.get_images()
        for idx, img in enumerate(imgs_raw):
            try:
                for r in pagina.get_image_rects(img[0]):
                    img_infos.append({"xref": img[0], "bbox": (r.x0, r.y0, r.x1, r.y1), "number": idx})
            except Exception:
                pass

    img_infos_ordenados = sorted(enumerate(img_infos), key=lambda x: x[1].get("bbox", (0, 0, 0, 0))[1], reverse=True)
    for img_idx, info in img_infos_ordenados:
        mod_p, borrada = _procesar_una_imagen(pagina, pno, doc, info, img_idx, acciones_imagenes, hacer_internet, grado, nombre_archivo, registro_borrar)
        if mod_p:
            modificado_en_esta_pagina = True
        if borrada is not None:
            rects_imagenes_borradas.append(borrada)

    if rects_imagenes_borradas:
        try:
            pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_REMOVE, graphics=0, text=0)
        except Exception as e_red:
            print(f"[WARN] apply_redactions fallo en pag {pno}: {e_red}")

    return modificado_en_esta_pagina, rects_imagenes_borradas

