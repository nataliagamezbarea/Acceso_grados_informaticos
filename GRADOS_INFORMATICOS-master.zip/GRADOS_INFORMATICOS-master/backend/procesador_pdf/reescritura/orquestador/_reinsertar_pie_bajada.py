import pymupdf as fitz
from backend.procesador_pdf.reescritura.fuentes_descarga.resolver_fuente_real import resolver_fuente_real
from backend.procesador_pdf.reescritura.tipografia._fuente_cubre_todo import _fuente_cubre_todo

def reinsertar_pie_con_bajada(pagina, rems, marco_bajada, texto_pie=None, incluir_fechas=True, es_bold_pie=False):
    if len(marco_bajada) >= 4:
        box_rect, shift_d, x_izq, font_orig = marco_bajada
    elif len(marco_bajada) >= 2:
        box_rect, shift_d = marco_bajada[0], marco_bajada[1]
        x_izq = rems[0]['x'] if rems else 196.82
        font_orig = rems[0].get('fuente_orig', 'Avenir Next LT Pro') if rems else 'Avenir Next LT Pro'
    else:
        box_rect, shift_d, x_izq, font_orig = fitz.Rect(189.25, 597.53, 551.65, 776.03), 0, 196.82, 'Avenir Next LT Pro'

    c_indigo = (0.19215686274509805, 0.06666666666666667, 0.9529411764705882)
    c_azul = (0.0, 0.4392156862745098, 0.7529411764705882)
    
    ruta_light = resolver_fuente_real(font_orig, 0) or resolver_fuente_real('Avenir Next LT Pro Light', 0)
    ruta_bold = resolver_fuente_real(font_orig, 16) or resolver_fuente_real('Avenir Next LT Pro Bold', 16)
    fn_light, fn_bold = 'helv', 'hebo'
    if ruta_light:
        try:
            pagina.insert_font(fontname='f_pie_light', fontfile=ruta_light)
            fn_light = 'f_pie_light'
        except Exception: pass
    if ruta_bold:
        try:
            pagina.insert_font(fontname='f_pie_bold', fontfile=ruta_bold)
            fn_bold = 'f_pie_bold'
        except Exception: pass

    if texto_pie:
        y_prim = 687.78 + shift_d
        f_pie = fn_bold if es_bold_pie else fn_light
        pagina.insert_text((x_izq, y_prim), str(texto_pie).strip(), fontsize=16.02, color=c_azul, fontname=f_pie)
    elif incluir_fechas:
        y_prim = 616.96 + shift_d
        x_gap1, x_gap2 = x_izq + 178.18, x_izq + 285.18
        pagina.insert_text((x_izq, y_prim), 'FECHA DE ENTREGA:', fontsize=16.02, color=c_indigo, fontname=fn_light)
        pagina.draw_rect(fitz.Rect(x_izq, 618.16 + shift_d, x_izq + 160.4, 618.94 + shift_d), color=c_indigo, fill=c_indigo)
        pagina.insert_text((x_gap1, y_prim), '3 DE NOVIEMBRE DE', fontsize=16.02, color=c_azul, fontname=fn_light)
        pagina.insert_text((x_izq, 637.90 + shift_d), '2022 A LAS 16:00', fontsize=16.02, color=c_azul, fontname=fn_light)
        pagina.insert_text((x_izq, 666.84 + shift_d), 'FECHA DEL TRABAJO TERMINADO:', fontsize=16.02, color=c_indigo, fontname=fn_light)
        pagina.draw_rect(fitz.Rect(x_izq, 668.04 + shift_d, x_izq + 270.98, 668.82 + shift_d), color=c_indigo, fill=c_indigo)
        pagina.insert_text((x_gap2, 666.84 + shift_d), '3 DE', fontsize=16.02, color=c_azul, fontname=fn_light)
        pagina.insert_text((x_izq, 687.78 + shift_d), 'NOVIEMBRE', fontsize=16.02, color=c_azul, fontname=fn_light)
    else:
        y_prim = rems[0]['y'] if rems else (707.78 + shift_d)

    for rem in rems:
        c_rgb = (((rem['color'] >> 16) & 0xFF)/255.0, ((rem['color'] >> 8) & 0xFF)/255.0, (rem['color'] & 0xFF)/255.0) if isinstance(rem['color'], int) else (0,0,0)
        es_b = bool(rem.get('es_bold'))
        f_name = fn_bold if es_b else fn_light
        pagina.insert_text((rem['x'], rem['y']), rem['texto'], fontsize=rem['size'], color=c_rgb, fontname=f_name)
        if rem.get('subrayado'):
            try:
                w_txt = fitz.Font(f_name).text_length(rem['texto'], fontsize=rem['size'])
            except Exception:
                w_txt = len(rem['texto']) * rem['size'] * 0.5
            pagina.draw_rect(fitz.Rect(rem['x'], rem['y'] + 1.2, rem['x'] + w_txt, rem['y'] + 2.0), color=c_rgb, fill=c_rgb)

    y0_recuadro = y_prim - 19.43
    m_rect_ajustado = fitz.Rect(box_rect.x0, y0_recuadro, box_rect.x1, box_rect.y1)
    pagina.draw_rect(m_rect_ajustado, color=(0, 0, 0), width=0.75)
