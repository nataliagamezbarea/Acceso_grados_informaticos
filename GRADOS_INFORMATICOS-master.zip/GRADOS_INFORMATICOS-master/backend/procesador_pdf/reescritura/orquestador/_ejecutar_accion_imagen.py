import os
import pymupdf as fitz


from backend.procesador_pdf.reescritura.orquestador._reflujo_imagen import borrar_y_refluir_imagen


def _ejecutar_accion_imagen(doc, pno, pagina, r, accion, act, bg_col, hacer_internet):
    modificado_en_esta_pagina = False
    rect_borrada = None
    if accion == "borrar":
        borrar_y_refluir_imagen(doc, pagina, pno, r)
        rect_borrada = r
        modificado_en_esta_pagina = True
    elif accion == "reemplazar":
        ruta_nueva = act.get("ruta")
        if ruta_nueva and not os.path.exists(ruta_nueva):
            try:
                from backend.gestor_datos.github_sync import descargar_archivo_de_github
                descargar_archivo_de_github(ruta_nueva)
            except Exception: pass
        if ruta_nueva and os.path.exists(ruta_nueva):
            pagina.add_redact_annot(r, fill=bg_col)
            pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS)
            try:
                doc_img = fitz.open(ruta_nueva)
                if len(doc_img) > 0:
                    p_img = doc_img[0]
                    img_w = p_img.rect.width
                    img_h = p_img.rect.height
                    doc_img.close()

                    aspect_ratio = img_w / max(1.0, img_h)
                    box_w = r.width
                    box_h = r.height
                    box_ratio = box_w / max(1.0, box_h)

                    if aspect_ratio < box_ratio:
                        nuevo_w = box_h * aspect_ratio
                        offset_x = (box_w - nuevo_w) / 2.0
                        rect_pegar = fitz.Rect(r.x0 + offset_x, r.y0, r.x0 + offset_x + nuevo_w, r.y1)
                    else:
                        nuevo_h = box_w / aspect_ratio
                        offset_y = (box_h - nuevo_h) / 2.0
                        rect_pegar = fitz.Rect(r.x0, r.y0 + offset_y, r.x1, r.y0 + offset_y + nuevo_h)

                    pagina.insert_image(rect_pegar, filename=ruta_nueva)
                else:
                    pagina.insert_image(r, filename=ruta_nueva)
                modificado = True
            except Exception:
                pagina.insert_image(r, filename=ruta_nueva)
                modificado = True
            modificado_en_esta_pagina = True
    elif accion == "citar" or act.get("cita"):
        texto_cita = act.get("cita") or "Fuente: Internet"
        y_top = min(pagina.rect.height - 12, r.y1 + 1)
        rect_cita = fitz.Rect(r.x0, y_top, r.x1, min(pagina.rect.height - 1, y_top + 10))
        pagina.insert_textbox(rect_cita, texto_cita, fontsize=7.0, fontname="helv", color=(0.35, 0.35, 0.35), align=1)
        modificado_en_esta_pagina = True
    return modificado_en_esta_pagina, rect_borrada
