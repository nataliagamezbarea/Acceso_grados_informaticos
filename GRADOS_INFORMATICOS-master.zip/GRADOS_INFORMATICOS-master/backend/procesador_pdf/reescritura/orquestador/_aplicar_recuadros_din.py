from backend.procesador_pdf.reescritura.recuadros_dinamicos import aplicar_recuadros_dinamicos


def _aplicar_recuadros_din(pagina, definiciones_recuadros, paginas_nuevas_pendientes):
    modificado = False
    for definicion in definiciones_recuadros:
        try:
            if aplicar_recuadros_dinamicos(pagina, paginas_pendientes=paginas_nuevas_pendientes, **definicion):
                modificado = True
        except Exception:
            pass
    return modificado
