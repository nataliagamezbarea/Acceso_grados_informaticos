import pymupdf as fitz
import unicodedata, re
from backend.gestor_datos import es_curriculum
from backend.configuracion import NOMBRES_COMPLETOS, PALABRAS_CLAVE_COLEGIO
from backend.procesador_pdf.busqueda_rectangulos.buscar_rectangulos_nombres import buscar_rectangulos_nombres
from backend.procesador_pdf.reescritura.orquestador._rects_manual_por_porcentaje import _rects_manual_por_porcentaje
from backend.procesador_pdf.reescritura.orquestador._partir_texto_reflujo import envolver_texto


def preparar_nombres(pagina, pno, nombre_archivo, recuadros_manual, limpiar_nombres=True, limpiar_colegio=True):
    if es_curriculum(nombre_archivo) or (not limpiar_nombres and not limpiar_colegio):
        return [], [], None
    rects = []
    if limpiar_nombres:
        man = (recuadros_manual or {}).get('nombre', {}).get(str(pno))
        txt_man = str(man.get('text', '') or '').strip() if isinstance(man, dict) else ''
        if txt_man:
            for v in [txt_man, ''.join(c for c in unicodedata.normalize('NFD', txt_man) if unicodedata.category(c) != 'Mn')]:
                rects.extend([fitz.Rect(r) for r in pagina.search_for(v) if fitz.Rect(r).width > 0])
        if not rects:
            rects = buscar_rectangulos_nombres(pagina)
    
    remanentes, marco_bajada = [], None
    try:
        dict_pag = pagina.get_text('dict')
        b_pie = [b for b in dict_pag.get('blocks', []) if b.get('bbox', [0,0,0,0])[1] > 550]
        for b in b_pie:
            lines = b.get('lines', [])
            for i, l in enumerate(lines):
                line_box = fitz.Rect(l.get('bbox'))
                line_txt = ''.join(s.get('text', '') for s in l.get('spans', []))
                es_objetivo = any(line_box.intersects(r) for r in rects) if rects else any(k in line_txt.upper() for k in ['GRADO', 'MEDIO', 'SISTEMAS', 'XALO'])
                if es_objetivo:
                    first_s = l.get('spans', [{}])[0]
                    partes = [''.join(s.get('text', '') for s in l.get('spans', []))]
                    for j in range(i + 1, len(lines)):
                        partes.append(''.join(s.get('text', '') for s in lines[j].get('spans', [])))
                    texto_total = ' '.join(partes)
                    if limpiar_colegio:
                        for col in PALABRAS_CLAVE_COLEGIO:
                            texto_total = texto_total.replace(col, '')
                            col_st = ''.join(c for c in unicodedata.normalize('NFD', col) if unicodedata.category(c) != 'Mn')
                            texto_total = texto_total.replace(col_st, '')
                    if limpiar_nombres:
                        for nom in sorted(NOMBRES_COMPLETOS, key=len, reverse=True):
                            texto_total = texto_total.replace(nom + ',', '').replace(nom, '')
                            nom_st = ''.join(c for c in unicodedata.normalize('NFD', nom) if unicodedata.category(c) != 'Mn')
                            texto_total = texto_total.replace(nom_st + ',', '').replace(nom_st, '')
                    texto_total = re.sub(r'^[\s,\-\–\.]+', '', texto_total)
                    texto_total = re.sub(r'[\s,\-\–\.]+$', '', texto_total).strip()
                    if texto_total and not texto_total.endswith('.'):
                        texto_total += '.'
                    if texto_total:
                        font_orig = str(first_s.get('font') or 'Avenir Next LT Pro Light')
                        fn = font_orig.lower()
                        es_bold = ('bold' in fn or 'black' in fn or 'heavy' in fn)
                        font_n = 'hebo' if es_bold else 'helv'
                        f_size = first_s.get('size') or 16.02
                        color = first_s.get('color') if first_s.get('color') is not None else 28864
                        ancho_disp = 540.0 - line_box.x0
                        lineas_reflujo = envolver_texto(texto_total, font_orig, f_size, ancho_disp)
                        d_boxes = [d['rect'] for d in pagina.get_drawings() if d.get('rect') and d['rect'].y1 > 500 and d['rect'].width > 200]
                        box_base = d_boxes[0] if d_boxes else fitz.Rect(line_box.x0 - 7.53, 590.81, line_box.x0 + 355.0, 769.31)
                        
                        y_calc = 707.78
                        y_ult_nueva = y_calc + (len(lineas_reflujo) - 1) * 20.0
                        shift_down = 762.51 - y_ult_nueva
                        
                        marco_bajada = (fitz.Rect(box_base.x0, box_base.y0 + shift_down, box_base.x1, box_base.y1), shift_down, line_box.x0, font_orig)
                        y_cur = y_calc + shift_down
                        for idx, l_txt in enumerate(lineas_reflujo):
                            remanentes.append({
                                'bbox': fitz.Rect(box_base.x0 - 2.0, box_base.y0 - 2.0, box_base.x1 + 2.0, box_base.y1 + 2.0) if idx == 0 else fitz.Rect(0, 0, 0, 0),
                                'x': line_box.x0, 'y': y_cur, 'texto': l_txt,
                                'size': f_size, 'font_name': font_n, 'color': color,
                                'es_bold': es_bold, 'fuente_orig': font_orig,
                            })
                            y_cur += 20.0
                    break
    except Exception:
        pass
    return rects, remanentes, marco_bajada
