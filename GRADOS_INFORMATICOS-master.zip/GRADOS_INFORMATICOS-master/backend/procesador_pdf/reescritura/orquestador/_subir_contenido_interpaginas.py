import pymupdf as fitz


def _extraer_rects_visibles(p):
    t_rects = [fitz.Rect(b[0], max(0.0, b[1]), b[2], min(780.0, b[3])) for b in p.get_text("blocks") if b[4].strip() and b[3] > 10 and b[1] < 780 and (b[3] - b[1]) > 2]
    i_rects = []
    for im in p.get_image_info():
        bb = im.get("bbox")
        if bb and bb[3] > 10 and bb[1] < 780:
            r = fitz.Rect(bb[0], max(0.0, bb[1]), bb[2], min(780.0, bb[3]))
            if r.height > 5:
                i_rects.append(r)
    return sorted(t_rects + i_rects, key=lambda r: r.y0)


def _es_pagina_indice_o_portada(p, pno):
    if pno == 0: return True
    txt = p.get_text().upper()
    if "ÍNDICE" in txt or "INDICE" in txt or "TABLA DE CONTENIDOS" in txt: return True
    return sum(1 for l in txt.split("\n") if "...." in l or "…" in l or ". . ." in l) >= 2


def subir_contenido_entre_paginas(doc, primer_pno=None):
    """Refluye el contenido visual hacia arriba si se liberó espacio o si hay punto de inicio."""
    if primer_pno is None or primer_pno < 0:
        primer_pno = 1
        while primer_pno < len(doc) and _es_pagina_indice_o_portada(doc[primer_pno], primer_pno):
            primer_pno += 1
    modificado = False

    pno = primer_pno
    while pno < len(doc) - 1:
        p_act, p_sig = doc[pno], doc[pno + 1]
        if _es_pagina_indice_o_portada(p_act, pno):
            pno += 1
            continue

        elems_act = _extraer_rects_visibles(p_act)
        y_bot_act = max([r.y1 for r in elems_act] + [100.0])
        espacio_libre = 760.0 - y_bot_act

        if espacio_libre > 60.0:
            elems_sig = _extraer_rects_visibles(p_sig)
            imgs_sig = [fitz.Rect(im["bbox"]) for im in p_sig.get_image_info() if im.get("bbox")]
            if elems_sig:
                y_min_sig = min(r.y0 for r in elems_sig)
                elems_mover = []
                for r in elems_sig:
                    if (r.y1 - y_min_sig) > espacio_libre: break
                    im_sol = next((im for im in imgs_sig if im.intersects(r)), None)
                    if im_sol and (im_sol.y1 - y_min_sig > espacio_libre or (y_bot_act + 14.0 + (im_sol.y1 - y_min_sig) > 760.0)):
                        break
                    elems_mover.append(r)
                if elems_mover:
                    y_corte = max(r.y1 for r in elems_mover) + 4.0
                    for im in imgs_sig:
                        if im.y0 < y_corte < im.y1: y_corte = im.y0 - 2.0
                    if y_corte > y_min_sig + 5.0:
                        doc_src = fitz.open(stream=doc.tobytes(), filetype="pdf")
                        rect_clip = fitz.Rect(0, y_min_sig - 2.0, p_sig.rect.width, y_corte)
                        h_mover = rect_clip.height
                        rect_dest = fitz.Rect(0, y_bot_act + 14.0, p_act.rect.width, y_bot_act + 14.0 + h_mover)
                        if rect_dest.y1 <= 780.0:
                            p_act.show_pdf_page(rect_dest, doc_src, pno + 1, clip=rect_clip)
                            p_sig.add_redact_annot(rect_clip, fill=(1, 1, 1))
                            p_sig.apply_redactions(images=fitz.PDF_REDACT_IMAGE_REMOVE, graphics=0, text=0)
                            rect_below = fitz.Rect(0, y_corte, p_sig.rect.width, p_sig.rect.height)
                            if rect_below.height > 20:
                                rect_target = fitz.Rect(0, 40.0, p_sig.rect.width, 40.0 + rect_below.height)
                                p_sig.add_redact_annot(fitz.Rect(0, 40.0, p_sig.rect.width, p_sig.rect.height), fill=(1, 1, 1))
                                p_sig.apply_redactions(images=fitz.PDF_REDACT_IMAGE_REMOVE, graphics=0, text=0)
                                p_sig.show_pdf_page(rect_target, doc_src, pno + 1, clip=rect_below)
                        doc_src.close()
                        modificado = True

        txt_sig_post = "".join(b[4].strip() for b in p_sig.get_text("blocks") if b[4].strip())
        if not txt_sig_post and len(p_sig.get_images()) == 0:
            doc.delete_page(pno + 1)
            modificado = True
            continue

        pno += 1

    return modificado
