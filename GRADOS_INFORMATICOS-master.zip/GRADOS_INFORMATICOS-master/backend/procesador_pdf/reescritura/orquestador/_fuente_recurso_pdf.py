import re


def _norm_font(s):
    return re.sub(r'[^a-z0-9]+', '', str(s or '').lower())


def localizar_recurso_fuente_pdf(pagina, nombre_fuente, flags=0):
    """Devuelve el nombre del recurso de fuente YA incrustado en la página
    (por ejemplo F6) que corresponde al span original.

    No inventa peso/estilo: primero busca la familia/estilo exactos del PDF.
    """
    objetivo = _norm_font(nombre_fuente)
    if not objetivo or pagina is None:
        return None
    try:
        fuentes = pagina.get_fonts(full=True)
    except Exception:
        return None

    candidatos = []
    for f in fuentes:
        # xref, ext, type, basefont, resource_name, encoding, referencer...
        if len(f) < 5:
            continue
        basefont = str(f[3] or '')
        recurso = str(f[4] or '')
        nb = _norm_font(basefont)
        # Los subset prefixes tipo ABCDEF+ desaparecen del nombre del span.
        nb_sin_subset = re.sub(r'^[a-z0-9]{6}', '', nb)
        score = 0
        if nb == objetivo:
            score = 1000
        elif nb_sin_subset == objetivo:
            score = 900
        elif objetivo in nb or nb_sin_subset in objetivo:
            score = 700
        else:
            # Comparación por familia eliminando estilos solo cuando no hay
            # coincidencia exacta; nunca se usa para decidir que algo es Bold.
            objetivo_fam = re.sub(r'(bold|light|regular|italic|oblique|medium|semibold|demibold|book|black|heavy|thin|ultralight|extralight)$', '', objetivo)
            cand_fam = re.sub(r'(bold|light|regular|italic|oblique|medium|semibold|demibold|book|black|heavy|thin|ultralight|extralight)$', '', nb_sin_subset)
            if objetivo_fam and objetivo_fam == cand_fam:
                score = 500
        if score:
            candidatos.append((score, recurso))

    if not candidatos:
        return None
    candidatos.sort(key=lambda x: x[0], reverse=True)
    return candidatos[0][1]
