import os
import pymupdf as fitz
from backend.procesador_pdf.reescritura.fuentes_descarga.resolver_fuente_real import resolver_fuente_real


def _obtener_font_obj(font_input):
    if isinstance(font_input, fitz.Font):
        return font_input
    if isinstance(font_input, str):
        if os.path.exists(font_input):
            try:
                return fitz.Font(fontfile=font_input)
            except Exception:
                pass
        ruta = resolver_fuente_real(font_input)
        if ruta and os.path.exists(ruta):
            try:
                return fitz.Font(fontfile=ruta)
            except Exception:
                pass
        try:
            return fitz.Font(font_input)
        except Exception:
            pass
    return fitz.Font("helv")


def envolver_texto(texto, font_ref, fontsize, ancho_max):
    """Envuelve texto midiendo con la tipografía REAL y guionizando de forma natural."""
    if not texto or ancho_max <= 0:
        return [texto] if texto else []
    f_obj = _obtener_font_obj(font_ref)
    palabras = [p for p in str(texto).split(" ") if p]
    lineas, act = [], ""

    for p in palabras:
        cand = (act + " " + p).strip() if act else p
        try:
            ancho_cand = f_obj.text_length(cand, fontsize=fontsize)
        except Exception:
            ancho_cand = len(cand) * fontsize * 0.5

        if ancho_cand <= ancho_max:
            act = cand
        else:
            partido = False
            if act and len(p) > 5:
                cortes = []
                for pref_nat in ['MICRO', 'INFOR', 'MULTI', 'SUPER', 'AUTO', 'TRANS', 'INTER']:
                    if p.upper().startswith(pref_nat) and len(p) > len(pref_nat) + 2:
                        cortes.append(len(pref_nat))
                cortes.extend(range(len(p) - 2, 3, -1))
                for corte in cortes:
                    pref = p[:corte] + '-'
                    try:
                        w_comb = f_obj.text_length(act + " " + pref, fontsize=fontsize)
                    except Exception:
                        w_comb = (len(act) + 1 + len(pref)) * fontsize * 0.5
                    if w_comb <= ancho_max:
                        lineas.append(act + " " + pref)
                        act = p[corte:]
                        partido = True
                        break
            if not partido:
                if act:
                    lineas.append(act)
                act = p

    if act:
        lineas.append(act)
    return lineas
