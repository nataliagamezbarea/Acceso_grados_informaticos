import pymupdf as fitz


def _rects_manual_por_porcentaje(pagina, datos_pagina):
    """Convierte {left,top,width,height} en % (recuadro movido a mano por el
    usuario) a un Rect real de la página; None si no hay datos guardados."""
    if not datos_pagina:
        return None
    try:
        if isinstance(datos_pagina, dict):
            datos = datos_pagina.get("coords", datos_pagina.get("geometry", []))
        else:
            datos = datos_pagina
        l, t, w, h = (float(datos[0]), float(datos[1]),
                      float(datos[2]), float(datos[3]))
        W, H = pagina.rect.width, pagina.rect.height
        r = fitz.Rect(l / 100.0 * W, t / 100.0 * H, (l + w) / 100.0 * W, (t + h) / 100.0 * H)
        if r.width > 2 and r.height > 2:
            return [r]
    except Exception:
        pass
    return None
