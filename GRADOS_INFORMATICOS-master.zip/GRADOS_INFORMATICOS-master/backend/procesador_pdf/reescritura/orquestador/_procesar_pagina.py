import pymupdf as fitz

from backend.procesador_pdf.busqueda_rectangulos import extraer_lineas_pagina
from backend.procesador_pdf.ayudas_render import compactar_huecos_blancos_pagina
from backend.procesador_pdf.reescritura.enunciados import sustituir_enunciados_de_pagina
from backend.procesador_pdf.reescritura.sustitucion import aplicar_sustitucion_completa
from backend.procesador_pdf.reescritura.orquestador._aplicar_recuadros_din import _aplicar_recuadros_din
from backend.procesador_pdf.reescritura.orquestador._procesar_imagenes import _procesar_imagenes
from backend.configuracion import NOMBRES_COMPLETOS, PALABRAS_CLAVE_COLEGIO
from backend.gestor_datos import es_curriculum

_VARIANTES_COLEGIO = tuple(PALABRAS_CLAVE_COLEGIO or ())


def _textos_a_eliminar(limpiar_nombres, limpiar_colegio, nombre_archivo):
    """Lista global equivalente a ``textos_a_eliminar`` de sustituir.py.

    Esta lista se usa SOLO cuando el usuario no ha marcado un recuadro manual
    en esta página. Si hay un recuadro manual, la selección del usuario tiene
    prioridad y se usa el texto guardado dentro de ese recuadro.
    """
    textos = []
    if limpiar_nombres and not es_curriculum(nombre_archivo):
        textos.extend(str(x).strip() for x in NOMBRES_COMPLETOS if str(x).strip())
    if limpiar_colegio:
        textos.extend(str(x).strip() for x in _VARIANTES_COLEGIO if str(x).strip())
    vistos = set()
    salida = []
    for t in textos:
        if t not in vistos:
            vistos.add(t)
            salida.append(t)
    return tuple(salida)


def _manual_selecciones(recuadros_manual, pno, pagina, limpiar_nombres, limpiar_colegio):
    """Obtiene las selecciones manuales de esta página.

    El texto guardado al dibujar/mover el recuadro es la IDENTIDAD del objetivo.
    La geometría solo limita dónde puede coincidir ese texto, igual que un
    ``clip_busqueda`` de sustituir.py. Esto evita borrar una coincidencia igual
    situada en otra parte de la página.
    """
    from backend.procesador_pdf.reescritura.orquestador._rects_manual_por_porcentaje import (
        _rects_manual_por_porcentaje,
    )

    textos = []
    clips = []
    encontrados_tipo = set()
    rec = recuadros_manual or {}

    for tipo, activo in (("nombre", limpiar_nombres), ("colegio", limpiar_colegio)):
        if not activo:
            continue
        por_tipo = rec.get(tipo, {}) if isinstance(rec, dict) else {}
        datos = por_tipo.get(str(pno)) if isinstance(por_tipo, dict) else None
        if not isinstance(datos, dict):
            continue
        texto = str(datos.get("text", "") or "").strip()
        if texto:
            textos.append(texto)
            encontrados_tipo.add(tipo)
            rr = _rects_manual_por_porcentaje(pagina, datos)
            if rr:
                clips.extend(rr)
                for r_clip in rr:
                    try:
                        txt_en_clip = pagina.get_text("text", clip=r_clip).strip()
                        if txt_en_clip and txt_en_clip not in textos:
                            textos.append(txt_en_clip)
                    except Exception:
                        pass

    # Si hay una selección manual de un tipo, ese tipo NO usa el detector
    # automático en esta página: se borra exactamente lo que el usuario
    # seleccionó. Los otros tipos siguen funcionando normalmente.
    return tuple(dict.fromkeys(textos)), clips, encontrados_tipo


def _borrar_solo_con_motor(doc, pagina, pno, textos, paginas_nuevas_pendientes):
    """Caso sin enunciado: usa el mismo motor parametrizado que sustituir.py,
    pero con texto_sustituir/texto_nuevo vacíos y solo textos_eliminar."""
    if not textos:
        return False
    return bool(aplicar_sustitucion_completa(
        doc, pagina, pno,
        texto_sustituir="",
        texto_nuevo="",
        textos_eliminar=textos,
        ref_y=None,
        paginas_nuevas_pendientes=paginas_nuevas_pendientes,
    ))


def _procesar_pagina(doc, pno, enunciados, recuadros_manual, enunciados_ya_hechos,
                     paginas_nuevas_pendientes, registro_borrar, definiciones_recuadros,
                     limpiar_nombres, limpiar_colegio, hacer_enunciado, grado,
                     nombre_archivo, acciones_imagenes, hacer_internet, resaltar_cambios):
    try:
        pagina = doc[pno]
    except Exception:
        return False

    modificado = False
    modificado_en_esta_pagina = False

    # =============================================================
    # 1) ACCIONES SOBRE IMÁGENES PRIMERO (Borrar, Reemplazar, Citar)
    # =============================================================
    try:
        mod_img, _ = _procesar_imagenes(
            pagina, pno, doc, acciones_imagenes,
            hacer_internet, grado, nombre_archivo, registro_borrar
        )
        if mod_img:
            modificado = True
            modificado_en_esta_pagina = True
    except Exception as exc_img:
        print(f"[DEBUG] Procesar imágenes falló en página {pno}: {exc_img}")

    # =============================================================
    # 2) RECOPILAR TODOS LOS TEXTOS A ELIMINAR EN ESTA PÁGINA
    # =============================================================
    todos_textos_eliminar = []

    if limpiar_nombres:
        textos_n_man, _, _ = _manual_selecciones(
            recuadros_manual, pno, pagina, limpiar_nombres=True, limpiar_colegio=False
        )
        if textos_n_man:
            todos_textos_eliminar.extend(textos_n_man)
        textos_n_glob = _textos_a_eliminar(True, False, nombre_archivo)
        if textos_n_glob:
            todos_textos_eliminar.extend(textos_n_glob)

    if limpiar_colegio:
        textos_c_man, _, _ = _manual_selecciones(
            recuadros_manual, pno, pagina, limpiar_nombres=False, limpiar_colegio=True
        )
        if textos_c_man:
            todos_textos_eliminar.extend(textos_c_man)
        textos_c_glob = _textos_a_eliminar(False, True, nombre_archivo)
        if textos_c_glob:
            todos_textos_eliminar.extend(textos_c_glob)

    textos_eliminar_unicos = tuple(dict.fromkeys(todos_textos_eliminar))

    # =============================================================
    # 3) SUSTITUCIÓN DE ENUNCIADOS + BORRADO CON MOTOR Y REFLUJO
    # =============================================================
    hizo_enunciado = False
    if hacer_enunciado and enunciados:
        enuncs_pag = [e for e in enunciados if (float(e.get('pct_top') or 0) < 50)] if pno == 0 else enunciados
        if enuncs_pag:
            lineas = extraer_lineas_pagina(pagina)
            textos_p0 = tuple(t for t in textos_eliminar_unicos if not any(k in t.upper() for k in ['XALO', 'SAN JOSÉ', 'SAN JOSE', 'OBRERO', 'SISTEMAS', 'GRADO'])) if pno == 0 else textos_eliminar_unicos
            hizo_enunciado = sustituir_enunciados_de_pagina(
                doc, pagina, pno, lineas, enuncs_pag,
                enunciados_ya_hechos, paginas_nuevas_pendientes,
                resaltar_cambios,
                textos_eliminar=textos_p0,
            )
            if hizo_enunciado:
                modificado = True
                modificado_en_esta_pagina = True
                pagina = doc[pno]

    if not hizo_enunciado and textos_eliminar_unicos and pno > 0:
        if _borrar_solo_con_motor(doc, pagina, pno, textos_eliminar_unicos, paginas_nuevas_pendientes):
            modificado = True
            modificado_en_esta_pagina = True
            pagina = doc[pno]

    # =============================================================
    # 4) LIMPIEZA DE PIE/NOMBRES CON REFLUJO CONTINUO Y COLEGIO
    # =============================================================
    if limpiar_nombres or limpiar_colegio:
        from backend.procesador_pdf.reescritura.orquestador._limpiar_nombres import preparar_nombres
        from backend.procesador_pdf.reescritura.orquestador._limpiar_colegio import preparar_colegio
        rects_nom, rems, marco_bajada = preparar_nombres(
            pagina, pno, nombre_archivo, recuadros_manual,
            limpiar_nombres=limpiar_nombres, limpiar_colegio=limpiar_colegio
        )
        texto_pie_custom = None
        es_bold_pie = False
        incluir_fechas = True
        if enunciados:
            for enc in enunciados:
                if enc.get('page') == pno and (float(enc.get('pct_top') or 0) >= 50):
                    if enc.get('include') is False or enc.get('new') == '':
                        incluir_fechas = False
                    nw = str(enc.get('new', '') or '').strip()
                    if nw and enc.get('include') is not False:
                        texto_pie_custom = nw
                        incluir_fechas = False
                        st = str(enc.get('start', '') or '').strip()
                        for b in pagina.get_text('dict')['blocks']:
                            for l in b.get('lines', []):
                                for s in l.get('spans', []):
                                    if (st and st.upper() in s.get('text', '').upper()) or ('FECHA' in s.get('text', '').upper()):
                                        fl = s.get('flags', 0)
                                        cfl = s.get('char_flags', 0)
                                        fn = str(s.get('font', '')).lower()
                                        es_bold_pie = bool((fl & 16) or (cfl & 16) or any(k in fn for k in ['bold', 'black', 'heavy', 'semibold', 'demi', '-b', '_bold']))
                                        break
                        if enc.get('es_bold') is not None:
                            es_bold_pie = bool(enc.get('es_bold'))
                        break
        rects_col = preparar_colegio(pagina, pno, recuadros_manual) if limpiar_colegio else []
        if rects_nom or rects_col or rems or marco_bajada:
            for r in rects_nom + rects_col:
                pagina.add_redact_annot(fitz.Rect(r.x0 - 1, r.y0 - 1, r.x1 + 1, r.y1 + 1), fill=(1, 1, 1))
            if marco_bajada:
                pagina.add_redact_annot(fitz.Rect(187.0, 550.0, 554.0, 780.0), fill=(1, 1, 1))
            else:
                for rem in rems:
                    if rem['bbox'].is_valid and rem['bbox'].width > 0:
                        pagina.add_redact_annot(fitz.Rect(rem['bbox'].x0, rem['bbox'].y0, rem['bbox'].x1, rem['bbox'].y1), fill=(1, 1, 1))
            g_mode = 2 if marco_bajada else 0
            pagina.apply_redactions(images=2, graphics=g_mode, text=0)
            if marco_bajada:
                from backend.procesador_pdf.reescritura.orquestador._reinsertar_pie_bajada import reinsertar_pie_con_bajada
                reinsertar_pie_con_bajada(pagina, rems, marco_bajada, texto_pie=texto_pie_custom, incluir_fechas=incluir_fechas, es_bold_pie=es_bold_pie)
            else:
                for rem in rems:
                    try:
                        c_rgb = (((rem['color'] >> 16) & 0xFF)/255.0, ((rem['color'] >> 8) & 0xFF)/255.0, (rem['color'] & 0xFF)/255.0) if isinstance(rem['color'], int) else (0,0,0)
                        pagina.insert_text((rem['x'], rem['y']), rem['texto'], fontname=rem.get('font_name', 'hebo'), fontsize=rem['size'], color=c_rgb)
                    except Exception:
                        pass
            if pno == 0 and limpiar_nombres and any(r.y0 < 300 for r in rects_nom):
                for im in pagina.get_image_info():
                    bb = im.get('bbox')
                    if bb and 280 < bb[1] < 350 and (bb[2] - bb[0]) < 100:
                        r_orig = fitz.Rect(bb)
                        r_dest = fitz.Rect(r_orig.x0, r_orig.y0 - 42.0, r_orig.x1, r_orig.y1 - 42.0)
                        doc_temp = fitz.open(stream=pagina.parent.tobytes(), filetype="pdf")
                        pagina.add_redact_annot(fitz.Rect(r_orig.x0 - 2, r_orig.y0 - 2, r_orig.x1 + 2, r_orig.y1 + 2), fill=(1, 1, 1))
                        pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_REMOVE, graphics=0, text=0)
                        pagina.show_pdf_page(r_dest, doc_temp, 0, clip=r_orig)
                        doc_temp.close()
                        break
            modificado = True
            modificado_en_esta_pagina = True

    # =============================================================
    # 5) RECONSTRUCCIÓN CONTINUA DE RECUADROS DINÁMICOS
    # =============================================================
    if definiciones_recuadros:
        try:
            if _aplicar_recuadros_din(pagina, definiciones_recuadros, paginas_nuevas_pendientes):
                modificado = True
                modificado_en_esta_pagina = True
        except Exception as exc_din:
            print(f"[DEBUG] Error en recuadros dinámicos página {pno}: {exc_din}")



    return modificado


