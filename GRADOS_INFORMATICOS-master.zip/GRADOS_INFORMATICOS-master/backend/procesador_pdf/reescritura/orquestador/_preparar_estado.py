from backend.gestor_datos import cargar_imagenes_borrar_global
from backend.procesador_pdf.reescritura.recuadros_dinamicos import RECUADROS_DINAMICOS_POR_DEFECTO


def _preparar_estado(ruta_pdf, nombre_archivo, item_reescritura, grado, acciones_imagenes):
    if acciones_imagenes is None and grado:
        from backend.gestor_datos import cargar_revision, clave_registro
        rev = cargar_revision()
        acciones_imagenes = rev.get(clave_registro(grado, nombre_archivo), {}).get("imagenes", {})
    if not acciones_imagenes:
        acciones_imagenes = {}

    enunciados = item_reescritura.get("enunciados", []) if item_reescritura else []
    if not enunciados and item_reescritura and item_reescritura.get("start"):
        enunciados = [{
            "start": item_reescritura.get("start", ""),
            "end": item_reescritura.get("end", ""),
            "new": item_reescritura.get("new", ""),
            "include": item_reescritura.get("include", True)
        }]
    inicio_reflujo = None
    try:
        from backend.gestor_datos import cargar_revision as _cargar_rev, clave_registro as _clave_reg
        datos_rev_doc = _cargar_rev().get(_clave_reg(grado, nombre_archivo), {}) or {}
        recuadros_manual = datos_rev_doc.get("recuadros", {}) or {}
        inicio_reflujo = datos_rev_doc.get("inicio_reflujo")
    except Exception:
        recuadros_manual = {}

    enunciados_ya_hechos = set()
    paginas_nuevas_pendientes = []
    registro_borrar = cargar_imagenes_borrar_global()

    definiciones_recuadros = None
    if item_reescritura:
        definiciones_recuadros = item_reescritura.get("recuadros_dinamicos")
    if not definiciones_recuadros:
        definiciones_recuadros = RECUADROS_DINAMICOS_POR_DEFECTO

    return {
        "acciones_imagenes": acciones_imagenes,
        "enunciados": enunciados,
        "recuadros_manual": recuadros_manual,
        "inicio_reflujo": inicio_reflujo,
        "enunciados_ya_hechos": enunciados_ya_hechos,
        "paginas_nuevas_pendientes": paginas_nuevas_pendientes,
        "registro_borrar": registro_borrar,
        "definiciones_recuadros": definiciones_recuadros,
    }
