import pymupdf as fitz

from backend.procesador_pdf.reescritura.orquestador._decidir_accion_imagen import _decidir_accion_imagen
from backend.procesador_pdf.reescritura.orquestador._ejecutar_accion_imagen import _ejecutar_accion_imagen


def _procesar_una_imagen(pagina, pno, doc, info, img_idx, acciones_imagenes, hacer_internet, grado, nombre_archivo, registro_borrar):
    xref_estable = info.get("xref", 0)
    img_id = f"p{pno}_x{xref_estable}" if xref_estable else f"p{pno}_img{img_idx}"
    act = acciones_imagenes.get(img_id, {})
    if not act:
        act = acciones_imagenes.get(f"p{pno}_img{img_idx}", {})
    r, accion, act, bg_col = _decidir_accion_imagen(doc, pno, img_idx, info, acciones_imagenes, hacer_internet, grado, nombre_archivo, registro_borrar, xref_estable, img_id, act, pagina)
    if r is None:
        return False, None
    modificado_en_esta_pagina, rect_borrada = _ejecutar_accion_imagen(doc, pno, pagina, r, accion, act, bg_col, hacer_internet)
    return modificado_en_esta_pagina, rect_borrada
