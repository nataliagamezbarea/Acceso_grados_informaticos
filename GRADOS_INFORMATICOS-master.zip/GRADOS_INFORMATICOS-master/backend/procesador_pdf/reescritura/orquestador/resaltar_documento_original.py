import pymupdf as fitz


def resaltar_documento_original(ruta_pdf, nombre_archivo, item_reescritura=None, grado=None):
    """NO dibuja nada dentro del PDF original.

    El documento original se sirve LIMPIO: los recuadros de nombre/colegio/
    enunciado NO se pintan dentro del PDF (antes se horneaban rectángulos
    de color y el usuario los veía "quemados" en el documento). La única
    marca visible es el 'red-hotspot' interactivo que dibuja el visor POR
    ENCIMA (capa DOM), que sí debe seguir apareciendo para poder hacer clic
    y editar. Así el PDF original queda intacto y las marcas son solo UI."""
    try:
        doc = fitz.open(ruta_pdf)
        doc.close()
    except Exception:
        pass
    return False
