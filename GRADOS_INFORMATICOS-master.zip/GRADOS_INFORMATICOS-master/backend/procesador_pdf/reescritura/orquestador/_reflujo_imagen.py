import pymupdf as fitz
from backend.procesador_pdf.reescritura.orquestador._partir_texto_reflujo import envolver_texto


def borrar_y_refluir_imagen(doc, pagina, pno, r_img):
    if pno == 0:
        pagina.add_redact_annot(fitz.Rect(r_img.x0 - 2, r_img.y0 - 2, r_img.x1 + 2, r_img.y1 + 2), fill=(1, 1, 1))
        pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_REMOVE, graphics=0, text=0)
        return

    doc_src = fitz.open(stream=pagina.parent.tobytes(), filetype="pdf")
    lines_lateral = []
    try:
        for b in pagina.get_text("dict").get("blocks", []):
            for l in b.get("lines", []):
                lx0, ly0, lx1, ly1 = l["bbox"]
                mid_y = (ly0 + ly1) / 2.0
                if r_img.y0 <= mid_y <= r_img.y1:
                    if (lx0 >= r_img.x1 - 10) or (lx1 <= r_img.x0 + 10):
                        lines_lateral.append(l)
    except Exception:
        pass

    first_span, parrafos, cur_par = None, [], []
    for l in lines_lateral:
        for s in l.get("spans", []):
            t = s.get("text", "").strip()
            if t:
                if first_span is None: first_span = s
                if t.startswith("-") and cur_par:
                    parrafos.append(" ".join(cur_par))
                    cur_par = [t]
                else: cur_par.append(t)
    if cur_par: parrafos.append(" ".join(cur_par))

    pagina.add_redact_annot(r_img, fill=(1, 1, 1))
    for l in lines_lateral:
        pagina.add_redact_annot(fitz.Rect(l["bbox"]), fill=(1, 1, 1))
    pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_REMOVE, graphics=0, text=0)

    y_cursor = r_img.y0
    if parrafos:
        x_start = 14.22
        f_size = (first_span.get("size") if first_span else None) or 12.0
        color = (0.0, 0.2, 0.8)
        if first_span and isinstance(first_span.get("color"), int):
            c_int = first_span["color"]
            color = (((c_int >> 16) & 0xFF)/255.0, ((c_int >> 8) & 0xFF)/255.0, (c_int & 0xFF)/255.0)

        for par in parrafos:
            for le in envolver_texto(par, "helv", f_size, 550.0 - x_start):
                pagina.insert_text((x_start, y_cursor + f_size), le, fontname="helv", fontsize=f_size, color=color)
                y_cursor += f_size * 1.3
            y_cursor += 4.0

    lat_y0s = [l["bbox"][1] for l in lines_lateral]
    blocks_below = [b for b in doc_src[pno].get_text("blocks") if b[4].strip() and b[1] >= (r_img.y1 - 2.0)]
    blocks_below = [b for b in blocks_below if not any(abs(b[1] - ly0) < 5.0 for ly0 in lat_y0s)]

    if blocks_below:
        y_cut = min(b[1] for b in blocks_below) - 2.0
        shift_up = max(0.0, y_cut - (y_cursor + 6.0 if parrafos else (r_img.y0 + 2.0)))
    else:
        y_cut = r_img.y1 + 5.0
        shift_up = max(0.0, (r_img.y1 + 5.0) - y_cursor)

    if shift_up > 15:
        rect_below = fitz.Rect(0, y_cut, pagina.rect.width, pagina.rect.height)
        rect_target = fitz.Rect(0, y_cut - shift_up, pagina.rect.width, pagina.rect.height - shift_up)
        pagina.add_redact_annot(fitz.Rect(0, y_cut - shift_up, pagina.rect.width, pagina.rect.height), fill=(1, 1, 1))
        pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_REMOVE, graphics=0, text=0)
        try:
            pagina.show_pdf_page(rect_target, doc_src, pno, clip=rect_below)
        except Exception:
            pass
    try:
        doc_src.close()
    except Exception:
        pass
