import os
import uuid
import pymupdf as fitz

from backend.procesador_pdf.ayudas_render import materializar_paginas_pendientes
from backend.procesador_pdf.reescritura.orquestador._preparar_estado import _preparar_estado
from backend.procesador_pdf.reescritura.orquestador._procesar_pagina import _procesar_pagina
from backend.procesador_pdf.reescritura.sustitucion.fuentes.cache_fuentes import (
    fuentes_registradas,
    contador_fuentes,
)


def reescribir_y_limpiar_pdf(ruta_pdf, nombre_archivo, item_reescritura=None, limpiar_nombres=False, limpiar_colegio=True, hacer_enunciado=True, grado=None, acciones_imagenes=None, hacer_internet=False, resaltar_cambios=False):
    """Aplica las redacciones tipográficas, reescritura de enunciados y acciones sobre imágenes."""
    if not os.path.exists(ruta_pdf):
        return False

    try:
        doc = fitz.open(ruta_pdf)
    except Exception:
        return False
    modificado = False

    # IMPORTANTE: fuentes_registradas es una caché GLOBAL a nivel de módulo
    # (vive mientras dure el proceso "python servidor.py"), pensada para no
    # repetir insert_font varias veces dentro del MISMO documento (misma
    # página + mismo archivo de fuente). El problema: la clave solo usa
    # (num_pagina, ruta_fuente), NO identifica el documento. Como el visor
    # regenera un fitz.Document NUEVO en cada refresco de previsualización,
    # una entrada cacheada de un documento ANTERIOR (ya cerrado) hacía que
    # se reutilizara un nombre de recurso de fuente que nunca se insertó en
    # el documento nuevo -> insert_text no encontraba ese recurso y la
    # tipografía no se aplicaba. En sustituir.py esto no pasa porque es un
    # script que se ejecuta una vez por proceso (la caché siempre nace
    # vacía). Aquí replicamos ese comportamiento vaciando la caché al
    # empezar a procesar CADA documento.
    fuentes_registradas.clear()
    contador_fuentes[0] = 0

    estado = _preparar_estado(ruta_pdf, nombre_archivo, item_reescritura, grado, acciones_imagenes)
    enunciados = estado["enunciados"]
    recuadros_manual = estado["recuadros_manual"]
    enunciados_ya_hechos = estado["enunciados_ya_hechos"]
    paginas_nuevas_pendientes = estado["paginas_nuevas_pendientes"]
    registro_borrar = estado["registro_borrar"]
    definiciones_recuadros = estado["definiciones_recuadros"]
    acciones_imagenes = estado["acciones_imagenes"]

    for pno in range(len(doc)):
        if _procesar_pagina(doc, pno, enunciados, recuadros_manual, enunciados_ya_hechos,
                            paginas_nuevas_pendientes, registro_borrar, definiciones_recuadros,
                            limpiar_nombres, limpiar_colegio, hacer_enunciado, grado,
                            nombre_archivo, acciones_imagenes, hacer_internet, resaltar_cambios):
            modificado = True

    if estado.get("inicio_reflujo") and "page" in estado["inicio_reflujo"]:
        try:
            from backend.procesador_pdf.reescritura.orquestador._subir_contenido_interpaginas import (
                subir_contenido_entre_paginas,
            )
            p_ini = int(estado["inicio_reflujo"]["page"])
            if subir_contenido_entre_paginas(doc, primer_pno=p_ini):
                modificado = True
        except Exception:
            pass

    if modificado:
        tmp = ruta_pdf + f".{uuid.uuid4().hex}.tmp.pdf"
        try:
            doc.save(tmp, encryption=0)
            doc.close()
            if os.path.exists(tmp):
                os.replace(tmp, ruta_pdf)
        except Exception:
            try:
                doc.close()
            except Exception:
                pass
            return False
    else:
        doc.close()
    return modificado
