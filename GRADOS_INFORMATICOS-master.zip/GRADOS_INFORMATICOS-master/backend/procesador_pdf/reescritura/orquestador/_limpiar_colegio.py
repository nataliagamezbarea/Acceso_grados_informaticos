import pymupdf as fitz
import unicodedata
from backend.configuracion import PALABRAS_CLAVE_COLEGIO
from backend.procesador_pdf.reescritura.orquestador._rects_manual_por_porcentaje import _rects_manual_por_porcentaje

_VARIANTES_COLEGIO = tuple(PALABRAS_CLAVE_COLEGIO)


def preparar_colegio(pagina, pno, recuadros_manual):
    rects = []
    man = (recuadros_manual or {}).get('colegio', {}).get(str(pno))
    txt_man = str(man.get('text', '') or '').strip() if isinstance(man, dict) else ''
    if txt_man:
        for v in [txt_man, ''.join(c for c in unicodedata.normalize('NFD', txt_man) if unicodedata.category(c) != 'Mn')]:
            rects.extend([fitz.Rect(r) for r in pagina.search_for(v) if fitz.Rect(r).width > 0])
    if not rects and man:
        rects = _rects_manual_por_porcentaje(pagina, man)
    if not rects and not txt_man:
        for v in _VARIANTES_COLEGIO:
            for r in pagina.search_for(v):
                rr = fitz.Rect(r)
                if rr.width > 0:
                    rects.append(rr)
        if pagina.number == 0 and rects:
            for img in pagina.get_images():
                try:
                    for r in pagina.get_image_rects(img[0]):
                        if r.y0 < 130 and r.y1 < 220 and 20 < r.width < 280 and 20 < r.height < 120:
                            rects.append(fitz.Rect(r))
                except Exception:
                    pass
    return rects
