import pymupdf as fitz

from backend.gestor_datos import hash_stream_imagen
from backend.procesador_pdf.ayudas_render import obtener_color_fondo_rect


def _decidir_accion_imagen(doc, pno, img_idx, info, acciones_imagenes, hacer_internet, grado, nombre_archivo, registro_borrar, xref_estable, img_id, act, pagina):
    accion = act.get("accion")
    if accion == "conservar" or act.get("no_borrar"):
        return None, None, act, None

    bbox = info.get("bbox")
    if not bbox:
        return None, None, act, None
    r = fitz.Rect(bbox)
    w_pct = (r.width / pagina.rect.width) * 100.0
    h_pct = (r.height / pagina.rect.height) * 100.0
    if (w_pct >= 85.0 and h_pct >= 85.0) or (r.x0 <= 15 and r.y0 <= 15 and r.x1 >= pagina.rect.width - 15 and r.y1 >= pagina.rect.height - 15):
        return None, None, act, None

    if not hacer_internet:
        if not act.get("manual") or accion == "normal":
            return None, None, act, None
    else:
        if not accion or accion == "normal":
            xr_img = info.get("xref", 0)
            if xr_img:
                h_img = hash_stream_imagen(doc, xr_img)
                if h_img:
                    from backend.gestor_datos import cargar_imagenes_conservar_global
                    if h_img in cargar_imagenes_conservar_global():
                        return None, None, act, None
                    if h_img in registro_borrar:
                        accion = "borrar"
                        act = {"accion": "borrar", "global_auto": True}

        if (not accion or accion == "normal") and grado:
            from backend.verificador_internet import comprobar_imagen_en_internet
            res_net = comprobar_imagen_en_internet(grado, nombre_archivo, pno, img_idx, auto_borrar_si_existe=True)
            if not res_net.get("existe_en_internet"):
                accion = "borrar"
                act = {"accion": "borrar", "auto_internet": True}
            else:
                accion = "citar"
                act = {"accion": "citar", "cita": res_net.get("cita_autor", "Fuente: Internet")}

    bg_col = (1.0, 1.0, 1.0)
    return r, accion, act, bg_col
