import os, sys
from pathlib import Path

DIR_BASE = Path(__file__).resolve().parents[4]
IS_VENV = sys.prefix != sys.base_prefix
ENV_FONTS_DIR = DIR_BASE / "venv" / "share" / "fonts"
if not ENV_FONTS_DIR.parent.exists():
    ENV_FONTS_DIR = Path.home() / ".cache" / "pdf_fonts"
# En entornos serverless de solo lectura (p.ej. Vercel) la creación de esta
# carpeta de fuentes puede fallar al importar. En ese caso se cae a /tmp, que
# sí es escribible en serverless, para que la descarga de fuentes siga activa.
try:
    ENV_FONTS_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    try:
        ENV_FONTS_DIR = Path("/tmp") / "pdf_fonts"
        ENV_FONTS_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

WEIGHTS_AND_STYLES = [
    "thin", "hairline", "extralight", "ultralight", "light", "regular",
    "medium", "semibold", "demibold", "extrabold", "ultrabold", "bold",
    "black", "heavy", "italic", "oblique"
]
