import urllib.parse

import requests
from bs4 import BeautifulSoup

from backend.procesador_pdf.reescritura.fuentes_descarga.clean_str import clean_str
from backend.procesador_pdf.reescritura.fuentes_descarga.log_msg import log_msg
from backend.procesador_pdf.reescritura.fuentes_descarga.is_valid_ttf import is_valid_ttf
from backend.procesador_pdf.reescritura.fuentes_descarga.extract_ttf_from_zip import extract_ttf_from_zip


def fetch_dafont_dynamic(family: str, style: str) -> tuple[bytes | None, str]:
    c_fam = clean_str(family)
    log_msg("DAFONT", f"Consultando DaFont para '{family}'...")
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Referer": "https://www.dafont.com/",
    }

    dl_url = f"https://dl.dafont.com/dl/?f={c_fam}"
    try:
        r = requests.get(dl_url, headers=headers, timeout=8)
        if r.status_code == 200 and r.content[:4] == b"PK\x03\x04":
            ttf_data = extract_ttf_from_zip(r.content, style)
            if ttf_data:
                return ttf_data, dl_url
    except Exception:
        pass

    search_url = f"https://www.dafont.com/search.php?q={urllib.parse.quote(family)}"
    try:
        r_s = requests.get(search_url, headers=headers, timeout=8)
        if r_s.status_code == 200:
            soup = BeautifulSoup(r_s.text, "html.parser")
            for a in soup.find_all("a", href=True):
                href = a["href"]
                if "dl.dafont.com/dl/?f=" in href or "//dl.dafont.com" in href:
                    final_dl = href if href.startswith("http") else f"https:{href}"
                    r_dl = requests.get(final_dl, headers=headers, timeout=10)
                    if r_dl.status_code == 200:
                        ttf_data = extract_ttf_from_zip(r_dl.content, style)
                        if ttf_data:
                            return ttf_data, final_dl
    except Exception:
        pass

    log_msg("DAFONT", f"'{family}' no encontrada en DaFont.")
    return None, ""
