from backend.procesador_pdf.reescritura.fuentes_descarga._constantes import ENV_FONTS_DIR
from backend.procesador_pdf.reescritura.fuentes_descarga._estilos_desde_banderas import _estilos_desde_banderas
from backend.procesador_pdf.reescritura.fuentes_descarga.parse_font_family_and_style import parse_font_family_and_style
from backend.procesador_pdf.reescritura.fuentes_descarga.clean_str import clean_str
from backend.procesador_pdf.reescritura.fuentes_descarga.find_in_env import find_in_env, _substrings_dinamicos
from backend.procesador_pdf.reescritura.fuentes_descarga.log_msg import log_msg
from backend.procesador_pdf.reescritura.fuentes_descarga.is_valid_ttf import is_valid_ttf
from backend.procesador_pdf.reescritura.fuentes_descarga.fetch_google_fonts import fetch_google_fonts
from backend.procesador_pdf.reescritura.fuentes_descarga.fetch_github_dynamic import fetch_github_dynamic
from backend.procesador_pdf.reescritura.fuentes_descarga.fetch_dafont_dynamic import fetch_dafont_dynamic

_cache_resolucion: dict[str, str | None] = {}


def resolver_fuente_real(nombre_fuente_pdf: str, banderas: int = 0) -> str | None:
    estilos_extra = _estilos_desde_banderas(banderas)
    clave = f"{nombre_fuente_pdf}|{estilos_extra}"
    if clave in _cache_resolucion:
        return _cache_resolucion[clave]

    def _guardar(r):
        _cache_resolucion[clave] = r
        return r

    ruta: str | None = None
    try:
        familia, estilo = parse_font_family_and_style(nombre_fuente_pdf)
        if estilos_extra and estilo == "Regular":
            estilo = estilos_extra

        ruta = find_in_env(familia, estilo)
        if ruta:
            log_msg("EXITO", f"Fuente '{familia} {estilo}' cargada del entorno -> {ruta}")
            return _guardar(ruta)

        if familia.lower() in ("helv", "helvetica", "standard"):
            return _guardar(None)

        # Generación 100% DINÁMICA de candidatos por prefijos/variantes
        variantes = _substrings_dinamicos(familia)
        candidatos = [(v, estilo, True) for v in variantes]

        for fam_cand, est_cand, permitir_dafont in candidatos:
            print("\n" + "=" * 80)
            print("\033[1;33m[PIPELINE DINÁMICO: GOOGLE FONTS -> GITHUB -> DAFONT]\033[0m")
            print(f"Buscando Familia: \033[1;37m{fam_cand}\033[0m | Estilo/Peso: \033[1;37m{est_cand}\033[0m")
            print("=" * 80)

            data, source_url = fetch_google_fonts(fam_cand, est_cand)
            origin_tag = "GOOGLE FONTS"

            if not data:
                data, source_url = fetch_github_dynamic(fam_cand, est_cand)
                origin_tag = "GITHUB"

            if not data and permitir_dafont:
                data, source_url = fetch_dafont_dynamic(fam_cand, est_cand)
                origin_tag = "DAFONT"

            print("=" * 80 + "\n")

            if data and is_valid_ttf(data):
                destino = ENV_FONTS_DIR / f"{clean_str(fam_cand)}_{clean_str(est_cand)}.ttf"
                with open(destino, "wb") as f_out:
                    f_out.write(data)
                ruta = str(destino.resolve())
                log_msg("EXITO", f"Proveedor : {origin_tag}")
                log_msg("EXITO", f"URL       : {source_url}")
                log_msg("EXITO", f"Guardada  : {ruta} ({len(data)//1024} KB)\n")
                break
            log_msg("ERROR", f"No se pudo descargar automáticamente '{fam_cand} {est_cand}'.\n")
    except Exception as e:
        log_msg("ERROR", f"Fallo resolviendo fuente '{nombre_fuente_pdf}': {e}")
        ruta = None

    return _guardar(ruta)
