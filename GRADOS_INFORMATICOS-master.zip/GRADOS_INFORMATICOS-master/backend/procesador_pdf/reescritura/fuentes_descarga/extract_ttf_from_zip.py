import io
import zipfile

from backend.procesador_pdf.reescritura.fuentes_descarga.clean_str import clean_str
from backend.procesador_pdf.reescritura.fuentes_descarga.is_valid_ttf import is_valid_ttf


def extract_ttf_from_zip(zip_bytes: bytes, style: str) -> bytes | None:
    c_style = clean_str(style)
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
            for item in z.namelist():
                name_low = item.lower()
                if (name_low.endswith(".ttf") or name_low.endswith(".otf")) and c_style in name_low:
                    data = z.read(item)
                    if is_valid_ttf(data):
                        return data

            for item in z.namelist():
                name_low = item.lower()
                if (name_low.endswith(".ttf") or name_low.endswith(".otf")) and "[" in name_low:
                    data = z.read(item)
                    if is_valid_ttf(data):
                        return data

            for item in z.namelist():
                name_low = item.lower()
                if (name_low.endswith(".ttf") or name_low.endswith(".otf")) and "regular" in name_low:
                    data = z.read(item)
                    if is_valid_ttf(data):
                        return data

            for item in z.namelist():
                if item.lower().endswith((".ttf", ".otf")):
                    data = z.read(item)
                    if is_valid_ttf(data):
                        return data
    except Exception:
        pass
    return None
