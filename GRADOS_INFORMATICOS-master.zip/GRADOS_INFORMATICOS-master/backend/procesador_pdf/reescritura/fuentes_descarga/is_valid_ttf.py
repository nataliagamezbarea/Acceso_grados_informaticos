def is_valid_ttf(data: bytes) -> bool:
    if not data or len(data) < 15000:
        return False
    if b"git-lfs.github.com" in data[:150]:
        return False
    return data[:4] in (b"\x00\x01\x00\x00", b"OTTO", b"true", b"typ1")
