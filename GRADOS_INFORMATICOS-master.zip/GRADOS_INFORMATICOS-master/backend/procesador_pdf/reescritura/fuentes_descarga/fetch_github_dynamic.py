import urllib.parse
from pathlib import Path

import requests

from backend.procesador_pdf.reescritura.fuentes_descarga.clean_str import clean_str
from backend.procesador_pdf.reescritura.fuentes_descarga.log_msg import log_msg
from backend.procesador_pdf.reescritura.fuentes_descarga.find_in_env import _substrings_dinamicos
from backend.procesador_pdf.reescritura.fuentes_descarga.is_valid_ttf import is_valid_ttf


def _get_headers():
    h = {"User-Agent": "Mozilla/5.0", "Accept": "application/vnd.github.v3+json"}
    try:
        from backend.gestor_datos.github_sync import _obtener_config_github
        tok, _ = _obtener_config_github()
        if tok:
            h["Authorization"] = f"Bearer {tok}"
    except Exception:
        pass
    return h


def fetch_github_dynamic(family: str, style: str) -> tuple[bytes | None, str]:
    c_sty = clean_str(style or "regular")
    log_msg("GITHUB", f"Buscando '{family}' (estilo: {style})...")
    headers = _get_headers()
    variantes = _substrings_dinamicos(family)
    # Queries: nombre completo + todas las variantes progresivas
    query_terms = list(dict.fromkeys(
        [f"{family} font"] + [f"{v} font" for v in variantes]
    ))

    repos = []
    seen = set()
    for term in query_terms[:5]:
        url = f"https://api.github.com/search/repositories?q={urllib.parse.quote(term)}&sort=stars&order=desc&per_page=5"
        try:
            r = requests.get(url, headers=headers, timeout=5)
            if r.status_code == 200:
                for repo in r.json().get("items", []):
                    fn = repo.get("full_name")
                    if fn and fn not in seen:
                        seen.add(fn)
                        repos.append((fn, repo.get("default_branch", "master")))
        except Exception:
            continue

    for repo_name, branch in repos:
        try:
            r_tree = requests.get(
                f"https://api.github.com/repos/{repo_name}/git/trees/{branch}?recursive=1",
                headers=headers, timeout=5)
            if r_tree.status_code != 200:
                continue
            for entry in r_tree.json().get("tree", []):
                path = entry.get("path", "")
                fn = clean_str(Path(path).name)
                if not Path(path).suffix.lower() in (".ttf", ".otf"):
                    continue
                if not any(v in fn for v in variantes):
                    continue
                if c_sty != "regular" and c_sty not in fn:
                    continue
                dl = f"https://raw.githubusercontent.com/{repo_name}/{branch}/{path}"
                r_file = requests.get(dl, headers=headers, timeout=8, allow_redirects=True)
                if r_file.status_code == 200 and is_valid_ttf(r_file.content):
                    log_msg("EXITO", f"Fuente descargada de GitHub -> {dl}")
                    return r_file.content, dl
        except Exception:
            continue

    log_msg("GITHUB", f"'{family} {style}' no encontrada.")
    return None, ""
