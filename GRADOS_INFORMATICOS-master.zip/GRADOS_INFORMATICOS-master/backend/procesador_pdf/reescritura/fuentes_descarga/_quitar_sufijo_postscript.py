from backend.procesador_pdf.reescritura.fuentes_descarga._constantes import WEIGHTS_AND_STYLES


def _quitar_sufijo_postscript(token: str) -> str:
    """Quita sufijos PostScript preservando mayúsculas."""
    t = token
    while t:
        low = t.lower()
        if low.endswith("mt") and len(low) > 2 and low not in WEIGHTS_AND_STYLES:
            t = t[:-2]
        elif low.endswith("ps") and len(low) > 2 and low not in WEIGHTS_AND_STYLES:
            t = t[:-2]
        else:
            break
    return t or token
