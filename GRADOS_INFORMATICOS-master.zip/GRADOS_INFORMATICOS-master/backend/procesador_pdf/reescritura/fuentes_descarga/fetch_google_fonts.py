import urllib.parse

import requests

from backend.procesador_pdf.reescritura.fuentes_descarga.clean_str import clean_str
from backend.procesador_pdf.reescritura.fuentes_descarga.log_msg import log_msg
from backend.procesador_pdf.reescritura.fuentes_descarga.is_valid_ttf import is_valid_ttf
from backend.procesador_pdf.reescritura.fuentes_descarga.extract_ttf_from_zip import extract_ttf_from_zip


def fetch_google_fonts(family: str, style: str) -> tuple[bytes | None, str]:
    c_fam = clean_str(family)
    headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64)"}
    licenses = ["ofl", "apache", "ufl"]

    log_msg("GOOGLE", f"Consultando catálogo oficial google/fonts para '{family}' (Estilo: {style})...")

    for lic in licenses:
        metadata_url = f"https://raw.githubusercontent.com/google/fonts/main/{lic}/{c_fam}/METADATA.pb"
        try:
            r_meta = requests.head(metadata_url, headers=headers, timeout=4)
            if r_meta.status_code == 200:
                candidates = [
                    f"{family.title()}-{style.title()}.ttf",
                    f"{family.title()}-Regular.ttf",
                    f"{c_fam}-{style.lower()}.ttf",
                    f"{c_fam}-regular.ttf",
                    f"{family.title()}[wght].ttf",
                    f"{c_fam}[wght].ttf",
                    f"static/{family.title()}-{style.title()}.ttf",
                    f"static/{family.title()}-Regular.ttf",
                ]

                for fname in candidates:
                    raw_url = f"https://raw.githubusercontent.com/google/fonts/main/{lic}/{c_fam}/{fname}"
                    r_ttf = requests.get(raw_url, headers=headers, timeout=8)
                    if r_ttf.status_code == 200 and is_valid_ttf(r_ttf.content):
                        return r_ttf.content, raw_url
        except Exception:
            continue

    api_url = f"https://fonts.google.com/download?family={urllib.parse.quote(family)}"
    try:
        r_api = requests.get(api_url, headers=headers, timeout=6)
        if r_api.status_code == 200 and r_api.content[:4] == b"PK\x03\x04":
            ttf_data = extract_ttf_from_zip(r_api.content, style)
            if ttf_data:
                return ttf_data, api_url
    except Exception:
        pass

    log_msg("GOOGLE", f"'{family}' no disponible en Google Fonts.")
    return None, ""
