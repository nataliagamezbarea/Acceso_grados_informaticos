from backend.procesador_pdf.reescritura.fuentes_descarga.clean_str import clean_str


def nombre_recurso_interno(family: str) -> str:
    """Nombre corto y único para registrar la fuente dentro del PDF."""
    return f"F_{clean_str(family)}"[:32]
