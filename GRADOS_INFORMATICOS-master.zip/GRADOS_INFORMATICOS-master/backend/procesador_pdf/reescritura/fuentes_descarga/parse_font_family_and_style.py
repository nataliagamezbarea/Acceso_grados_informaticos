import re

from backend.procesador_pdf.reescritura.fuentes_descarga._constantes import WEIGHTS_AND_STYLES
from backend.procesador_pdf.reescritura.fuentes_descarga._quitar_sufijo_postscript import _quitar_sufijo_postscript


def parse_font_family_and_style(raw_name: str) -> tuple[str, str]:
    if not raw_name:
        return "helv", "Regular"

    name = re.sub(r"^F_", "", raw_name, flags=re.IGNORECASE)
    name = re.sub(r"^[A-Z]{6}\+", "", name)
    name = name.split(",")[0].strip()

    parts = re.split(r"[-_ ]+", name)
    detected_styles: list[str] = []
    family_parts = []

    def _add_estilo(est: str):
        if est and est.lower() not in [d.lower() for d in detected_styles]:
            detected_styles.append(est)

    for p in parts:
        p_limpio = _quitar_sufijo_postscript(p)
        pl = p_limpio.lower()
        if pl not in WEIGHTS_AND_STYLES and len(pl) > 5 and pl.endswith(("italic", "oblique")):
            base = pl[:-6].rstrip("-")
            extra = pl[-6:] if pl.endswith("italic") else "oblique"
            if base in WEIGHTS_AND_STYLES:
                _add_estilo(base.capitalize())
                _add_estilo(extra.capitalize())
                continue
        if pl in WEIGHTS_AND_STYLES:
            _add_estilo(p_limpio.capitalize())
        elif p_limpio:
            family_parts.append(p_limpio)

    family = "".join(family_parts).strip() if family_parts else parts[0]
    style = "".join(detected_styles) if detected_styles else "Regular"
    return family, style
