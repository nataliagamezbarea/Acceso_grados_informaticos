def log_msg(tag: str, msg: str):
    colors = {
        "GOOGLE": "\033[1;34m",
        "GITHUB": "\033[1;35m",
        "DAFONT": "\033[1;33m",
        "EXITO": "\033[1;32m",
        "RENDER": "\033[1;36m",
        "ERROR": "\033[1;31m",
    }
    c = colors.get(tag, "\033[1;37m")
    print(f"{c}[{tag}]\033[0m {msg}")
