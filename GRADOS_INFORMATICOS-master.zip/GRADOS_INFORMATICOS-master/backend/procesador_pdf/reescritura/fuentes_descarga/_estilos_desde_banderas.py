def _estilos_desde_banderas(banderas: int) -> str:
    est = ""
    if banderas & 16:
        est += "Bold"
    if banderas & 2:
        est += "Italic"
    return est
