import re
from backend.procesador_pdf.reescritura.fuentes_descarga._constantes import ENV_FONTS_DIR
from backend.procesador_pdf.reescritura.fuentes_descarga.clean_str import clean_str

_PESOS = ("thin", "hairline", "extralight", "ultralight", "light",
          "medium", "semibold", "demibold", "extrabold", "ultrabold",
          "bold", "black", "heavy", "italic", "oblique")


def _substrings_dinamicos(family: str) -> list[str]:
    """Genera variantes normalizadas del nombre de familia dinámicamente.

    Ejemplo: 'AvenirNextLTPro' -> ['avenirnextltpro', 'avenirnextlt', 'avenirnext', 'avenir']
    """
    c = clean_str(family)
    if not c:
        return []
    partes = [p.lower() for p in re.findall(
        r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z][a-z]|\d|\b)|[A-Z]+|[0-9]+', family) if p]
    variantes = [c]
    for i in range(len(partes) - 1, 0, -1):
        sub = "".join(partes[:i])
        if sub and sub not in variantes and len(sub) >= 3:
            variantes.append(sub)
    return variantes


def find_in_env(family: str, style: str) -> str | None:
    """Busca una fuente en el entorno dinámicamente sin tablas hardcodeadas."""
    c_fam = clean_str(family)
    c_sty = clean_str(style or "regular")
    if not c_fam or c_fam in ("helv", "helvetica", "standard"):
        return None

    candidatos = [
        p for p in ENV_FONTS_DIR.iterdir()
        if p.is_file() and p.suffix.lower() in (".ttf", ".otf") and p.stat().st_size > 15000
    ]
    variantes = _substrings_dinamicos(family)

    def familia_ok(stem):
        s = clean_str(stem)
        return any(v in s for v in variantes)

    def estilo_ok(stem):
        s = clean_str(stem)
        if c_sty == "regular":
            return not any(p in s for p in _PESOS)
        return c_sty in s

    for p in candidatos:
        if familia_ok(p.stem) and estilo_ok(p.stem):
            return str(p.resolve())

    esperado = ENV_FONTS_DIR / f"{c_fam}_{c_sty}.ttf"
    if esperado.exists() and esperado.stat().st_size > 15000:
        return str(esperado.resolve())
    return None
