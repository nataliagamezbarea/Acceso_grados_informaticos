import pymupdf as fitz


def _medir_ancho(f_obj, texto, size):
    try:
        if f_obj is not None:
            return f_obj.text_length(texto, fontsize=size)
    except Exception:
        pass
    try:
        return fitz.Font("helv").text_length(texto, fontsize=size)
    except Exception:
        return len(texto) * size * 0.5
