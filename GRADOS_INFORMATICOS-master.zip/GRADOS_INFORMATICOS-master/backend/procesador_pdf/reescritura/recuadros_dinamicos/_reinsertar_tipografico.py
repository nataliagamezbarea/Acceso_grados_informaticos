import pymupdf as fitz

from backend.procesador_pdf.reescritura.recuadros_dinamicos._resolver_recurso_fuente import _resolver_recurso_fuente
from backend.procesador_pdf.reescritura.recuadros_dinamicos._margen_derecho_para_sustitucion import _margen_derecho_para_sustitucion
from backend.procesador_pdf.reescritura.recuadros_dinamicos._envolver_con_guion import _envolver_con_guion
from backend.procesador_pdf.reescritura.recuadros_dinamicos._insertar_span_medido import _insertar_span_medido
from backend.procesador_pdf.ayudas_render import _empujar_contenido_hacia_abajo


def _reinsertar_tipografico(pagina, spans, rect_final, delta_y, paginas_pendientes):
    cache_fuentes = {}

    for sp in spans:
        if sp["nuevo_texto"] and not sp["persistente"]:
            x = sp["bbox"].x0
            y = sp["origin"][1] if sp.get("origin") else sp["bbox"].y1
            size = sp["size"]
            _ruta, _nombre_rec, f_obj_medida = _resolver_recurso_fuente(
                sp["font"], sp["flags"], cache_fuentes)
            ancho_max = max(40.0, _margen_derecho_para_sustitucion(pagina, sp["bbox"]) - x)
            lineas_txt = _envolver_con_guion(f_obj_medida, sp["nuevo_texto"], size, ancho_max)
            alto_linea = size * 1.15
            alto_original = max(alto_linea, sp["bbox"].y1 - sp["bbox"].y0)
            alto_nuevo = alto_linea * len(lineas_txt)
            extra = alto_nuevo - alto_original
            if extra > 2.0:
                try:
                    _empujar_contenido_hacia_abajo(
                        pagina, sp["bbox"].y1 + 1.0, extra + 6.0,
                        paginas_pendientes=paginas_pendientes)
                except Exception:
                    pass
            y_cursor = y
            for ln in lineas_txt:
                _insertar_span_medido(pagina, ln, x, y_cursor, size, sp["font"],
                                      sp["flags"], sp["color"], cache_fuentes)
                y_cursor += alto_linea

    lineas_persistentes_spans = {}
    for sp in spans:
        if sp["persistente"]:
            lineas_persistentes_spans.setdefault(sp["linea_id"], []).append(sp)

    for _linea_id, spans_linea in lineas_persistentes_spans.items():
        spans_linea.sort(key=lambda s: s["bbox"].x0)
        cursor_x = None
        x1_original_previo = None
        for sp in spans_linea:
            texto_final = sp["nuevo_texto"] or sp["texto"]
            y = (sp["origin"][1] if sp.get("origin") else sp["bbox"].y1) + delta_y
            if cursor_x is None:
                x = sp["bbox"].x0
            else:
                hueco_original = sp["bbox"].x0 - x1_original_previo
                x = cursor_x + hueco_original
            ancho_real = _insertar_span_medido(pagina, texto_final, x, y, sp["size"], sp["font"],
                                               sp["flags"], sp["color"], cache_fuentes)
            cursor_x = x + ancho_real
            x1_original_previo = sp["bbox"].x1
