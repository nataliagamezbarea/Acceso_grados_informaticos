import pymupdf as fitz

from backend.procesador_pdf.reescritura.recuadros_dinamicos._extraer_spans_por_linea import _extraer_spans_por_linea
from backend.procesador_pdf.reescritura.recuadros_dinamicos._clasificar_spans import _clasificar_spans
from backend.procesador_pdf.reescritura.recuadros_dinamicos._detectar_marco import _detectar_marco
from backend.procesador_pdf.reescritura.recuadros_dinamicos._reajustar_geometrico import _reajustar_geometrico
from backend.procesador_pdf.reescritura.recuadros_dinamicos._redactar_y_marco import _redactar_y_marco
from backend.procesador_pdf.reescritura.recuadros_dinamicos._reinsertar_tipografico import _reinsertar_tipografico


def aplicar_recuadros_dinamicos(pagina, grupos_eliminar=None, sustituciones=None,
                                patrones_persistentes=None, padding_v=8.0,
                                expandir_izq=8.0, expandir_der=80.0, margen_arriba=10.0,
                                paginas_pendientes=None):
    grupos_eliminar = grupos_eliminar or []
    sustituciones = sustituciones or {}
    patrones_persistentes = patrones_persistentes or []

    spans = _extraer_spans_por_linea(pagina)
    if not spans:
        return False

    encontrado_grupo, hay_sustitucion, bbox_eliminar, bbox_persistente = _clasificar_spans(
        spans, grupos_eliminar, patrones_persistentes, sustituciones)
    if not encontrado_grupo and not hay_sustitucion and not bbox_persistente.is_valid:
        return False

    rect_original, color_borde, grosor_borde = _detectar_marco(
        pagina, bbox_persistente, expandir_izq, expandir_der, margen_arriba, bbox_eliminar)
    delta_y, rect_final = _reajustar_geometrico(rect_original, bbox_persistente, padding_v)
    _redactar_y_marco(pagina, spans, rect_original, rect_final, color_borde, grosor_borde)
    _reinsertar_tipografico(pagina, spans, rect_final, delta_y, paginas_pendientes)
    return True
