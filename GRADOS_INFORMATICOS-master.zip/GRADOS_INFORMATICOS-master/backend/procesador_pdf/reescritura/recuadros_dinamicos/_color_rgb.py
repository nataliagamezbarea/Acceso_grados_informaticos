def _color_rgb(color_num):
    c = color_num or 0
    return ((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0
