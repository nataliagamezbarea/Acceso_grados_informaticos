import pymupdf as fitz


def _clasificar_spans(spans, grupos_eliminar, patrones_persistentes, sustituciones):
    bbox_eliminar = fitz.Rect()
    bbox_persistente = fitz.Rect()
    encontrado_grupo = False
    n = len(spans)

    for grupo in grupos_eliminar:
        glen = len(grupo)
        if glen == 0:
            continue
        for i in range(n - glen + 1):
            if all(grupo[k] in spans[i + k]["texto"] for k in range(glen)):
                for k in range(glen):
                    spans[i + k]["eliminar"] = True
                    bbox_eliminar.include_rect(spans[i + k]["bbox"])
                encontrado_grupo = True

    lineas_persistentes = set()
    for sp in spans:
        if sp["eliminar"]:
            continue
        if any(pat in sp["texto"] for pat in patrones_persistentes):
            lineas_persistentes.add(sp["linea_id"])

    for sp in spans:
        if sp["eliminar"]:
            continue
        if sp["linea_id"] in lineas_persistentes:
            sp["persistente"] = True
            bbox_persistente.include_rect(sp["bbox"])
        else:
            sp["persistente"] = False

    if not bbox_persistente.is_valid:
        for sp in spans:
            if not sp["eliminar"]:
                bbox_persistente.include_rect(sp["bbox"])

    hay_sustitucion = False
    for sp in spans:
        if sp["eliminar"]:
            continue
        for buscar, nuevo in sustituciones.items():
            if buscar in sp["texto"]:
                sp["nuevo_texto"] = sp["texto"].replace(buscar, nuevo)
                hay_sustitucion = True
                break

    return encontrado_grupo, hay_sustitucion, bbox_eliminar, bbox_persistente
