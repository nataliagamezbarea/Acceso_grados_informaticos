import pymupdf as fitz


def _extraer_spans_por_linea(pagina):
    """Lectura estructurada de todos los spans de texto de la página."""
    spans = []
    linea_id = 0
    for bloque in pagina.get_text("dict").get("blocks", []):
        for linea in bloque.get("lines", []):
            spans_de_esta_linea = []
            for span in linea.get("spans", []):
                t = span.get("text", "")
                if t.strip():
                    spans_de_esta_linea.append({
                        "texto": t,
                        "bbox": fitz.Rect(span.get("bbox")),
                        "font": span.get("font"),
                        "size": span.get("size"),
                        "color": span.get("color"),
                        "origin": span.get("origin"),
                        "flags": span.get("flags", 0),
                        "linea_id": linea_id,
                        "eliminar": False,
                        "nuevo_texto": None,
                        "persistente": False,
                    })
            if spans_de_esta_linea:
                spans.extend(spans_de_esta_linea)
                linea_id += 1
    return spans
