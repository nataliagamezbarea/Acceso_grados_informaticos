import pymupdf as fitz


def _reajustar_geometrico(rect_original, bbox_persistente, padding_v):
    delta_y = 0.0
    rect_final = rect_original
    if rect_original is not None and bbox_persistente.is_valid:
        alto_persistente = bbox_persistente.y1 - bbox_persistente.y0
        nueva_altura = alto_persistente + (2 * padding_v)

        # NO tocar la lógica del contenido: solo corregir la posición del recuadro.
        # El borde inferior debe terminar exactamente donde terminaba el recuadro original.
        y1_anclado = rect_original.y1
        y0_nuevo = y1_anclado - nueva_altura

        # Mover el contenido persistente el mismo desplazamiento que el recuadro.
        delta_y = (y0_nuevo + padding_v) - bbox_persistente.y0

        rect_final = fitz.Rect(
            rect_original.x0,
            y0_nuevo,
            rect_original.x1,
            y1_anclado,
        )
    return delta_y, rect_final
