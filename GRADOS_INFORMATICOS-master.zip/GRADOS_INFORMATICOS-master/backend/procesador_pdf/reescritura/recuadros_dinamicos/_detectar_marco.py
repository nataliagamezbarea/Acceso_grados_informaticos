import pymupdf as fitz


def _valor_seguro(valor, defecto):
    """Devuelve el valor si es numérico y finito, sino el defecto."""
    if valor is None:
        return defecto
    try:
        valor = float(valor)
    except Exception:
        return defecto
    import math
    if not math.isfinite(valor):
        return defecto
    return valor


def _detectar_marco(pagina, bbox_persistente, expandir_izq, expandir_der, margen_arriba, bbox_eliminar):
    rect_original = None
    color_borde, grosor_borde = (0, 0, 0), 1.0

    if bbox_persistente.is_valid:
        margen_busqueda = bbox_persistente + (-4, -4, 4, 4)
        candidatos = []
        for draw in pagina.get_drawings():
            r = draw.get("rect")
            if not r:
                continue
            rect_d = fitz.Rect(r)
            # Igual que localizar_recuadro.py: solo considerar dibujos que TENGAN color
            if not draw.get("color"):
                continue
            if rect_d.width < 40 or rect_d.height < 20:
                continue

            # Preferir el recuadro que ENCERRA todo el contenido que permanece y,
            # cuando existe, también todo el texto que se va a borrar. Esto evita
            # elegir por casualidad un rectángulo interior y perder el borde
            # inferior del recuadro original.
            contiene_persistente = rect_d.contains(bbox_persistente)
            contiene_eliminar = (not bbox_eliminar.is_valid) or rect_d.contains(bbox_eliminar)
            if contiene_persistente and contiene_eliminar:
                area = rect_d.width * rect_d.height
                candidatos.append((0, area, rect_d, draw))
            elif rect_d.intersects(margen_busqueda) or contiene_persistente:
                area = rect_d.width * rect_d.height
                candidatos.append((1, area, rect_d, draw))

        if candidatos:
            # Menor prioridad numérica primero; dentro de la misma prioridad,
            # preferimos el recuadro más pequeño que realmente encierra el bloque.
            candidatos.sort(key=lambda item: (item[0], item[1]))
            _, _, rect_original, draw = candidatos[0]
            color_borde = draw.get("color") or (0, 0, 0)
            grosor_borde = _valor_seguro(draw.get("width"), 1.0)

        if not rect_original:
            # Si no hay dibujo original, usamos el bbox persistente desplazado
            rect_original = fitz.Rect(
                bbox_persistente.x0 - expandir_izq,
                bbox_persistente.y0 - expandir_izq,
                bbox_persistente.x1 + expandir_der,
                (bbox_eliminar.y1 if bbox_eliminar.is_valid else bbox_persistente.y1) + margen_arriba,
            )
            # Intentar obtener color del bbox eliminar si existe
            if bbox_eliminar.is_valid:
                try:
                    color_borde = bbox_eliminar.fill or (0, 0, 0)
                except Exception:
                    color_borde = (0, 0, 0)
            grosor_borde = 1.0

    return rect_original, color_borde, grosor_borde
