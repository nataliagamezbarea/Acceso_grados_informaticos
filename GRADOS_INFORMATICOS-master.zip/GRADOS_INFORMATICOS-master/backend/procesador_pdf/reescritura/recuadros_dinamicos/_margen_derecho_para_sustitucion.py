import pymupdf as fitz


def _margen_derecho_para_sustitucion(pagina, bbox):
    y_ref = bbox.y1
    mejor_x1 = None
    mejor_dist = None
    try:
        for d in pagina.get_drawings():
            r = d.get("rect")
            if not r:
                continue
            if r.height <= 2.5 and r.width > 100 and 0 <= (r.y0 - y_ref) <= 40:
                dist = r.y0 - y_ref
                if mejor_dist is None or dist < mejor_dist:
                    mejor_dist = dist
                    mejor_x1 = r.x1
    except Exception:
        pass
    if mejor_x1 is not None:
        return mejor_x1
    return max(bbox.x0 + 60.0, pagina.rect.width - bbox.x0)
