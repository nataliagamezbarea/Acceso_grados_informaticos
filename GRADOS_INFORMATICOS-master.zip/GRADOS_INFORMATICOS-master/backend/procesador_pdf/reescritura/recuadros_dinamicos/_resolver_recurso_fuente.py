import pymupdf as fitz

from backend.procesador_pdf.reescritura.tipografia import resolver_ruta_fuente_real
from backend.procesador_pdf.reescritura.recuadros_dinamicos._nombre_recurso import _nombre_recurso


def _resolver_recurso_fuente(font_name, flags, cache_fuentes):
    """Resuelve y cachea la fuente real para medir y dibujar."""
    if font_name in cache_fuentes:
        return cache_fuentes[font_name]

    ruta = None
    try:
        ruta, _familia = resolver_ruta_fuente_real(font_name, flags)
    except Exception:
        ruta = None

    nombre_recurso = None
    f_obj = None
    if ruta:
        try:
            f_obj = fitz.Font(fontfile=ruta)
            nombre_recurso = _nombre_recurso(font_name)
        except Exception:
            ruta = None
            f_obj = None

    if not ruta:
        ruta = None
        nombre_recurso = "helv"
        try:
            f_obj = fitz.Font("helv")
        except Exception:
            f_obj = None

    resultado = (ruta, nombre_recurso, f_obj)
    cache_fuentes[font_name] = resultado
    return resultado
