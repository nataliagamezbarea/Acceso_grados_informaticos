import pymupdf as fitz


def _redactar_y_marco(pagina, spans, rect_original, rect_final, color_borde, grosor_borde):
    for sp in spans:
        if sp["eliminar"] or sp["nuevo_texto"] or sp["persistente"]:
            pagina.add_redact_annot(sp["bbox"], fill=(1, 1, 1))

    if rect_original is not None:
        pagina.add_redact_annot(rect_original + (-2, -2, 2, 2), fill=(1, 1, 1))

    pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE)

    if rect_final is not None:
        pagina.draw_rect(rect_final, color=color_borde, width=grosor_borde)
