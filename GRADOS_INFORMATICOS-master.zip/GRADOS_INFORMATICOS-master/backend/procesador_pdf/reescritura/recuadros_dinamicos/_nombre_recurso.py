def _nombre_recurso(font_name):
    return f"font_{(font_name or 'orig').replace(' ', '_').replace('-', '_')}"
