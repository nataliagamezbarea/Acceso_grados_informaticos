import pymupdf as fitz

from backend.procesador_pdf.reescritura.recuadros_dinamicos._color_rgb import _color_rgb
from backend.procesador_pdf.reescritura.recuadros_dinamicos._resolver_recurso_fuente import _resolver_recurso_fuente


def _insertar_span_medido(pagina, texto, x, y, size, font_name, flags, color_num, cache_fuentes):
    """Reinserta un span y devuelve el ancho real ocupado."""
    color_rgb = _color_rgb(color_num)
    ruta_fuente, nombre_recurso, f_obj = _resolver_recurso_fuente(font_name, flags, cache_fuentes)

    ancho = None
    escrito = False
    if ruta_fuente:
        try:
            pagina.insert_font(fontname=nombre_recurso, fontfile=ruta_fuente)
            rc = pagina.insert_text((x, y), texto, fontsize=size, fontname=nombre_recurso, color=color_rgb)
            escrito = bool(rc)
        except Exception:
            escrito = False

    if not escrito:
        pagina.insert_text((x, y), texto, fontsize=size, fontname="helv", color=color_rgb)
        try:
            ancho = fitz.Font("helv").text_length(texto, fontsize=size)
        except Exception:
            ancho = None
    elif f_obj is not None:
        try:
            ancho = f_obj.text_length(texto, fontsize=size)
        except Exception:
            ancho = None

    if ancho is None:
        ancho = len(texto) * size * 0.5
    return ancho
