from backend.procesador_pdf.reescritura.recuadros_dinamicos._medir_ancho import _medir_ancho


def _envolver_con_guion(f_obj, texto, size, ancho_max):
    if ancho_max <= 0:
        return [texto]
    palabras = texto.split(" ")
    lineas = []
    actual = ""
    for palabra in palabras:
        candidata = (actual + " " + palabra).strip() if actual else palabra
        if _medir_ancho(f_obj, candidata, size) <= ancho_max:
            actual = candidata
            continue
        if actual:
            lineas.append(actual)
            actual = ""
        restante = palabra
        while _medir_ancho(f_obj, restante, size) > ancho_max and len(restante) > 1:
            corte = len(restante) - 1
            while corte > 1 and _medir_ancho(f_obj, restante[:corte] + "-", size) > ancho_max:
                corte -= 1
            if corte <= 1:
                break
            lineas.append(restante[:corte] + "-")
            restante = restante[corte:]
        actual = restante
    if actual:
        lineas.append(actual)
    return lineas or [""]
