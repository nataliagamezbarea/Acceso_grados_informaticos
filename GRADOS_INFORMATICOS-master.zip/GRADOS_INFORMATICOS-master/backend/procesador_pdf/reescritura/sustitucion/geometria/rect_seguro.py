import pymupdf as fitz


def rect_seguro(valor):
    try:
        r = fitz.Rect(valor)
        if not r.is_valid:
            return None
        if r.is_empty:
            return None
        if r.is_infinite:
            return None
        return r
    except Exception:
        return None
