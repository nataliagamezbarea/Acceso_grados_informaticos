import math


def valor_seguro(valor, defecto):
    if valor is None:
        return defecto
    try:
        valor = float(valor)
    except Exception:
        return defecto
    if not math.isfinite(valor):
        return defecto
    return valor
