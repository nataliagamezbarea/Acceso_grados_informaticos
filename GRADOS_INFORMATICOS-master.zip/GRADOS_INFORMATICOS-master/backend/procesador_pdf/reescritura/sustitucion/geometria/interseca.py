def interseca(a, b):
    return (
        a.x0 < b.x1
        and a.x1 > b.x0
        and a.y0 < b.y1
        and a.y1 > b.y0
    )
