import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_punto import (
    desplazar_punto,
)


def desplazar_quad(quad, dy):
    return fitz.Quad(
        desplazar_punto(quad.ul, dy),
        desplazar_punto(quad.ur, dy),
        desplazar_punto(quad.ll, dy),
        desplazar_punto(quad.lr, dy),
    )
