import pymupdf as fitz


def desplazar_rect(rect, dy):
    return fitz.Rect(rect.x0, rect.y0 + dy, rect.x1, rect.y1 + dy)
