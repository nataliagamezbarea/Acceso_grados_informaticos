import pymupdf as fitz


def desplazar_punto(punto, dy):
    return fitz.Point(punto.x, punto.y + dy)
