import pymupdf as fitz


def ampliar_rect(rect, margen):
    return fitz.Rect(
        rect.x0 - margen,
        rect.y0 - margen,
        rect.x1 + margen,
        rect.y1 + margen,
    )
