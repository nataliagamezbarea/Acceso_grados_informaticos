import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.configuracion import (
    MARGEN_INFERIOR_NUEVA_PAGINA,
    MARGEN_SUPERIOR_NUEVA_PAGINA,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_rect import (
    desplazar_rect,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)


from ..flujo_calculo.y_destino_pagina2 import y_destino_pagina2


def p2_cerrar_recuadro(pagina_2, rect_cuadro, color_borde, grosor_borde,
                       fn_final, limite_y_pag1, min_y_desborde,
                       elementos_texto_mover, lineas_reconstruir,
                       dibujos_mover, imagenes_mover, alto_pagina,
                       rect_cuadro_desplazado=None):
    """Recuadro en la página 2:
    - Si el recuadro empezó en la página 1: dibuja los laterales y el borde INFERIOR
      (sin borde superior, continuando la pág 1).
    - Si el recuadro se trasladó entero a la página 2: dibuja el rectángulo cerrado de 4 lados.
    """
    x0 = rect_cuadro.x0
    x1 = rect_cuadro.x1
    contenido_y2 = []

    for item in elementos_texto_mover:
        bbox_original = item["bbox"]
        rect_nuevo, y_top = y_destino_pagina2(bbox_original, fn_final, limite_y_pag1, min_y_desborde)
        if rect_nuevo is not None and y_top is not None:
            contenido_y2.append((y_top, y_top + bbox_original.height))

    for linea in lineas_reconstruir:
        rect_nuevo, y_top = y_destino_pagina2(linea["bbox"], fn_final, limite_y_pag1, min_y_desborde)
        if rect_nuevo is not None and y_top is not None:
            contenido_y2.append((y_top, y_top + linea["bbox"].height))

    for dibujo in dibujos_mover:
        r = rect_seguro(dibujo.get("rect"))
        if r is None:
            continue
        rect_nuevo, y_top = y_destino_pagina2(r, fn_final, limite_y_pag1, min_y_desborde)
        if rect_nuevo is not None and y_top is not None:
            contenido_y2.append((y_top, y_top + r.height))

    for imagen in imagenes_mover:
        r = imagen["rect"]
        rect_nuevo, y_top = y_destino_pagina2(r, fn_final, limite_y_pag1, min_y_desborde)
        if rect_nuevo is not None and y_top is not None:
            contenido_y2.append((y_top, y_top + r.height))

    if contenido_y2:
        primer_y2 = min(y0 for y0, _ in contenido_y2)
        ultimo_y2 = max(y1 for _, y1 in contenido_y2)
        y2_top = max(0.0, primer_y2 - 6.0)
        y2_bottom = ultimo_y2 + 8.0
    else:
        y2_top = MARGEN_SUPERIOR_NUEVA_PAGINA
        y2_bottom = y2_top + 40.0
    y2_bottom = min(y2_bottom, alto_pagina)

    empezo_en_pag1 = (rect_cuadro_desplazado is not None and rect_cuadro_desplazado.y0 < limite_y_pag1 - 20.0)
    if empezo_en_pag1:
        # Continuación de página 1: laterales + borde inferior (abierto por arriba)
        y2_top_cont = max(0.0, MARGEN_SUPERIOR_NUEVA_PAGINA - 6.0)
        pagina_2.draw_line(fitz.Point(x0, y2_top_cont), fitz.Point(x0, y2_bottom),
                           color=color_borde, width=grosor_borde, overlay=True)
        pagina_2.draw_line(fitz.Point(x1, y2_top_cont), fitz.Point(x1, y2_bottom),
                           color=color_borde, width=grosor_borde, overlay=True)
        pagina_2.draw_line(fitz.Point(x0, y2_bottom), fitz.Point(x1, y2_bottom),
                           color=color_borde, width=grosor_borde, overlay=True)
    else:
        # Todo el recuadro está en la página 2: rectángulo cerrado completo
        rect_p2 = fitz.Rect(x0, y2_top, x1, y2_bottom)
        pagina_2.draw_rect(rect_p2, color=color_borde, fill=(1, 1, 1),
                           width=grosor_borde, overlay=True)
