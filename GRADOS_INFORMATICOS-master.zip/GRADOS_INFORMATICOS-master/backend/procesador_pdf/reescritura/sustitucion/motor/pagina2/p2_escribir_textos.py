from backend.procesador_pdf.reescritura.sustitucion.fuentes.escribir_span_con_fuente import escribir_span_con_fuente
from ..flujo_calculo.y_destino_pagina2 import y_destino_pagina2


def p2_escribir_textos(pagina_2, elementos_texto_mover, fn_final,
                       limite_y_pag1, min_y_desborde, ratios_trazo):
    """Texto movido a la página 2, cada span con su estilo original."""
    for elem in elementos_texto_mover:
        rect_nuevo, y_top = y_destino_pagina2(
            elem["bbox"], fn_final, limite_y_pag1, min_y_desborde
        )
        if rect_nuevo is None:
            continue
        y_origen_p2 = y_top + (elem["origin"][1] - elem["bbox"].y0)
        escribir_span_con_fuente(
            pagina_2, elem["texto"],
            (elem["bbox"].x0, y_origen_p2),
            elem["font"], elem["flags"], elem["size"],
            elem["color"], elem.get("alpha", 255),
            ratios_trazo=ratios_trazo,
        )
