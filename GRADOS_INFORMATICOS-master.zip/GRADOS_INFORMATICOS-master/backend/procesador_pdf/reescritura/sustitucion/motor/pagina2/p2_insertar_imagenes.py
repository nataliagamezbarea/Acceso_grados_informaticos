import pymupdf as fitz
from ..flujo_calculo.y_destino_pagina2 import y_destino_pagina2


def p2_insertar_imagenes(pagina_2, imagenes_mover, fn_final,
                         limite_y_pag1, min_y_desborde):
    """Imágenes que desbordan: reutilizan su XREF ORIGINAL (sin recodificar)."""
    for imagen in imagenes_mover:
        r = imagen["rect"]
        rect_nuevo, y_top = y_destino_pagina2(
            r, fn_final, limite_y_pag1, min_y_desborde
        )
        if rect_nuevo is None:
            continue
        rect_p2 = fitz.Rect(rect_nuevo.x0, y_top,
                            rect_nuevo.x1, y_top + rect_nuevo.height)
        try:
            pagina_2.insert_image(rect_p2, xref=imagen["xref"],
                                  keep_proportion=False, overlay=True)
        except Exception:
            pass
