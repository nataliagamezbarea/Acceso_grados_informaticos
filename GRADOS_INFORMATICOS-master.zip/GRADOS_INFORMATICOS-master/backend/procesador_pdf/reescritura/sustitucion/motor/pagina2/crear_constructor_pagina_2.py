from .p2_cerrar_recuadro import p2_cerrar_recuadro
from .p2_escribir_lineas import p2_escribir_lineas
from .p2_escribir_textos import p2_escribir_textos
from .p2_insertar_imagenes import p2_insertar_imagenes
from .p2_mover_vectores import p2_mover_vectores


def crear_constructor_pagina_2(ratios_trazo, elementos_texto_mover,
                               lineas_reconstruir, dibujos_mover,
                               imagenes_mover, fn_desplazamiento_final,
                               limite_y_pag1, min_y_desborde, rect_cuadro,
                               rect_cuadro_desplazado, color_borde,
                               grosor_borde, alto_pagina):
    """Devuelve el CONSTRUCTOR DIFERIDO de la página de continuación: quien
    orquesta lo llama AL FINAL del bucle con la página ya creada (mismo
    mecanismo anti-renumeración que _empujar_contenido_hacia_abajo)."""
    def _construir_pagina_2(pagina_2):
        if rect_cuadro_desplazado is not None:
            p2_cerrar_recuadro(
                pagina_2, rect_cuadro, color_borde, grosor_borde,
                fn_desplazamiento_final, limite_y_pag1, min_y_desborde,
                elementos_texto_mover, lineas_reconstruir,
                dibujos_mover, imagenes_mover, alto_pagina)
        p2_mover_vectores(
            pagina_2, dibujos_mover, fn_desplazamiento_final,
            limite_y_pag1, min_y_desborde)
        p2_insertar_imagenes(
            pagina_2, imagenes_mover, fn_desplazamiento_final,
            limite_y_pag1, min_y_desborde)
        p2_escribir_textos(
            pagina_2, elementos_texto_mover, fn_desplazamiento_final,
            limite_y_pag1, min_y_desborde, ratios_trazo)
        p2_escribir_lineas(
            pagina_2, lineas_reconstruir, fn_desplazamiento_final,
            limite_y_pag1, min_y_desborde, ratios_trazo)
    return _construir_pagina_2
