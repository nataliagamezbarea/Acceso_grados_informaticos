from backend.procesador_pdf.reescritura.sustitucion.fuentes.escribir_linea_con_runs import escribir_linea_con_runs
from ..flujo_calculo.y_destino_pagina2 import y_destino_pagina2


def p2_escribir_lineas(pagina_2, lineas_reconstruir, fn_final,
                       limite_y_pag1, min_y_desborde, ratios_trazo):
    """Líneas reconstruidas que desbordan: se reescriben en la página 2 con
    sus runs por estilo."""
    for linea in lineas_reconstruir:
        rect_nuevo, y_top = y_destino_pagina2(
            linea["bbox"], fn_final, limite_y_pag1, min_y_desborde
        )
        if rect_nuevo is None:
            continue
        y_origen_p2 = y_top + (linea["origin"][1] - linea["bbox"].y0)
        escribir_linea_con_runs(
            pagina_2,
            linea.get("runs") or [{
                "texto": linea["texto"], "font": linea["font"],
                "flags": linea["flags"], "size": linea["size"],
                "color": linea["color"], "alpha": linea["alpha"],
            }],
            (linea["bbox"].x0, y_origen_p2),
            ratios_trazo=ratios_trazo,
        )
