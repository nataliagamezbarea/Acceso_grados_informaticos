from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import rect_seguro
from ..flujo_calculo.y_destino_pagina2 import y_destino_pagina2
from backend.procesador_pdf.reescritura.sustitucion.vectores.dibujar_vector_desplazado import dibujar_vector_desplazado


def p2_mover_vectores(pagina_2, dibujos_mover, fn_final,
                      limite_y_pag1, min_y_desborde):
    """Dibujos vectoriales que desbordan: se reconstruyen en la página 2 con
    TODOS sus atributos (color, fill, grosor, dashes, opacidades...)."""
    for dibujo in dibujos_mover:
        r = rect_seguro(dibujo.get("rect"))
        if r is None:
            continue
        rect_nuevo, y_destino = y_destino_pagina2(
            r, fn_final, limite_y_pag1, min_y_desborde
        )
        if rect_nuevo is None:
            continue
        dy = y_destino - r.y0
        dibujar_vector_desplazado(pagina_2, dibujo, dy)
