from backend.procesador_pdf.reescritura.sustitucion.configuracion import TOLERANCIA_Y
from backend.procesador_pdf.reescritura.sustitucion.geometria.interseca import (
    interseca,
)


def clasificar_texto_mover(spans_encontrados, spans_objetivo_originales,
                           spans_completamente_eliminados, lineas_afectadas,
                           fn_desplazamiento_elemento):
    """Spans de texto que deben MOVERSE (desplazamiento != 0), excluyendo el
    título sustituido (uno o varios spans si era multilínea), los spans de
    líneas vacías borradas y los spans que pertenecen a líneas ya
    reconstruidas."""
    spans_objetivo_originales = spans_objetivo_originales or []

    def pertenece_a_linea_afectada(span):
        return any(interseca(span["bbox"], linea["bbox"]) for linea in lineas_afectadas)

    elementos_texto_mover = []
    for span in spans_encontrados:
        if any(span is s for s in spans_objetivo_originales):
            continue
        if span in spans_completamente_eliminados:
            continue
        if pertenece_a_linea_afectada(span):
            continue
        if span["bbox"].y0 > 550:
            continue
        if abs(fn_desplazamiento_elemento(span["bbox"].y0)) > TOLERANCIA_Y:
            elementos_texto_mover.append(span)
    return elementos_texto_mover
