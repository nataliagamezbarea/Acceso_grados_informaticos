from backend.procesador_pdf.reescritura.sustitucion.geometria.interseca import interseca
from ..extraccion.reconstruir_linea_afectada import reconstruir_linea_afectada


def clasificar_borrado(lineas_originales, span_objetivo,
                       spans_objetivo_originales, elementos_texto_eliminar,
                       spans_encontrados):
    """Reparte las líneas tocadas por los textos a borrar en: líneas a
    reconstruir (quedan caracteres), líneas vacías eliminadas (provocan
    subida del contenido inferior) y spans que desaparecen por completo.

    spans_objetivo_originales: lista de spans REALES que componen el
    objetivo (uno solo en el caso simple; varios si el objetivo estaba
    repartido en varias líneas/spans). Se usa por identidad -- span_objetivo
    puede ser un span sintético fusionado que no es "is" ningún span real.
    """
    spans_objetivo_originales = spans_objetivo_originales or []

    def linea_es_del_titulo(linea):
        return any(
            interseca(linea["bbox"], s["bbox"])
            for s in spans_objetivo_originales
        )

    lineas_reconstruir = []
    lineas_vacias_eliminadas = []
    for linea in lineas_originales:
        if linea_es_del_titulo(linea):
            continue
        rects_linea = [
            r for r in elementos_texto_eliminar
            if interseca(linea["bbox"], r)
        ]
        if not rects_linea:
            continue
        estado, dato = reconstruir_linea_afectada(linea, rects_linea)
        if estado == "vacia":
            lineas_vacias_eliminadas.append(dato)
        else:
            lineas_reconstruir.append(dato)

    bloques_eliminados = []
    for linea in sorted(lineas_vacias_eliminadas, key=lambda x: x["bbox"].y0):
        r = linea["bbox"]
        bloques_eliminados.append({
            "y0": r.y0,
            "y1": r.y1,
            "altura": max(r.height * 1.8, linea["size"] * 1.8, 28.0),
            "elementos": [linea],
        })

    spans_completamente_eliminados = []
    for span in spans_encontrados:
        if any(span is s for s in spans_objetivo_originales):
            continue
        if any(interseca(span["bbox"], linea["bbox"]) for linea in lineas_vacias_eliminadas):
            spans_completamente_eliminados.append(span)

    return {
        "lineas_reconstruir": lineas_reconstruir,
        "lineas_vacias_eliminadas": lineas_vacias_eliminadas,
        "bloques_eliminados": bloques_eliminados,
        "spans_completamente_eliminados": spans_completamente_eliminados,
    }
