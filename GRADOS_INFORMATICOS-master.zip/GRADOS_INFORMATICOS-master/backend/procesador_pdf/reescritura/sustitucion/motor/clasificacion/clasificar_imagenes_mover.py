import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.configuracion import TOLERANCIA_Y
from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)


def clasificar_imagenes_mover(pagina, fn_desplazamiento_elemento):
    """Imágenes (por xref ORIGINAL + rect en la página) cuyo desplazamiento
    vertical no es nulo: se reinsertarán desplazadas reutilizando la xref."""
    imagenes_mover = []
    for img_info in pagina.get_images():
        try:
            xref = img_info[0]
        except Exception:
            continue
        try:
            rects_img = pagina.get_image_rects(xref)
        except Exception:
            continue
        for rect_img in rects_img:
            r = rect_seguro(rect_img)
            if r is None:
                continue
            if abs(fn_desplazamiento_elemento(r.y0)) > TOLERANCIA_Y:
                imagenes_mover.append({"xref": xref, "rect": r})
    return imagenes_mover
