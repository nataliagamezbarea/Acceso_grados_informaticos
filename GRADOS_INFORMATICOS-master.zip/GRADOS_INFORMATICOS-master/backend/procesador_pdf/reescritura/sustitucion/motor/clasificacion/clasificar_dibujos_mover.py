from backend.procesador_pdf.reescritura.sustitucion.configuracion import TOLERANCIA_Y
from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)


def clasificar_dibujos_mover(dibujos_originales, dibujo_recuadro,
                             fn_desplazamiento_elemento, rect_cuadro=None,
                             lineas_reconstruir=None, spans_encontrados=None,
                             spans_completamente_eliminados=None):
    """Dibujos vectoriales cuyo desplazamiento vertical no es nulo. El
    recuadro contenedor se excluye: se reconstruye con su propia geometría."""
    dibujos_mover = []
    max_txt_y_en_cuadro = None
    if rect_cuadro is not None:
        txt_ys = []
        for s in (spans_encontrados or []):
            if spans_completamente_eliminados and s in spans_completamente_eliminados:
                continue
            r_s = s["bbox"]
            if (r_s.x0 >= rect_cuadro.x0 - 2 and r_s.x1 <= rect_cuadro.x1 + 2
                and r_s.y0 >= rect_cuadro.y0 - 2 and r_s.y1 <= rect_cuadro.y1 + 2):
                txt_ys.append(r_s.y1)
        for l in (lineas_reconstruir or []):
            r_l = l["bbox"]
            if (r_l.x0 >= rect_cuadro.x0 - 2 and r_l.x1 <= rect_cuadro.x1 + 2
                and r_l.y0 >= rect_cuadro.y0 - 2 and r_l.y1 <= rect_cuadro.y1 + 2):
                txt_ys.append(r_l.y1)
        if txt_ys:
            max_txt_y_en_cuadro = max(txt_ys)

    for dibujo in dibujos_originales:
        r = rect_seguro(dibujo.get("rect"))
        if r is None:
            continue
        if dibujo_recuadro is not None and dibujo is dibujo_recuadro:
            continue
        if rect_cuadro is not None and max_txt_y_en_cuadro is not None:
            if (r.x0 >= rect_cuadro.x0 - 2 and r.x1 <= rect_cuadro.x1 + 2
                and r.y0 >= rect_cuadro.y0 - 2 and r.y1 <= rect_cuadro.y1 + 2):
                if r.y0 > max_txt_y_en_cuadro + 8.0:
                    continue
        if r.y0 > 550:
            continue
        if abs(fn_desplazamiento_elemento(r.y0)) > TOLERANCIA_Y:
            dibujos_mover.append(dibujo)
    return dibujos_mover
