from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.interseca import (
    interseca,
)


def buscar_rects_textos_eliminar(pagina, textos_eliminar, clip_busqueda=None):
    """Rects EXACTOS de las frases a borrar. Si el visor seleccionó una
    zona (clip_busqueda) solo cuentan los matches dentro de ella.
    Maneja textos multilínea dividiéndolos por renglón y buscando variantes."""
    elementos_texto_eliminar = []

    def anadir_rect(r):
        r = rect_seguro(r)
        if r is None or r.is_empty:
            return
        if clip_busqueda is not None and not interseca(r, clip_busqueda):
            return
        if not any(
            abs(x.x0 - r.x0) < 0.5 and abs(x.y0 - r.y0) < 0.5
            and abs(x.x1 - r.x1) < 0.5 and abs(x.y1 - r.y1) < 0.5
            for x in elementos_texto_eliminar
        ):
            elementos_texto_eliminar.append(r)

    for texto_buscar in textos_eliminar:
        texto_buscar = str(texto_buscar or "").strip()
        if not texto_buscar:
            continue

        lineas_texto = [l.strip() for l in texto_buscar.splitlines() if l.strip()]
        if not lineas_texto:
            lineas_texto = [texto_buscar]

        # Si la frase es multilínea, encontrar primero la posición base con las líneas más largas
        rects_lineas_largas = []
        for linea_t in lineas_texto:
            if len(linea_t.split()) >= 2 or len(linea_t) >= 14:
                try:
                    for r in pagina.search_for(linea_t, quads=False):
                        anadir_rect(r)
                        rects_lineas_largas.append(rect_seguro(r))
                except Exception:
                    pass

        # Para líneas cortas (ej. 'NOVIEMBRE'), si es parte de una frase multilínea,
        # solo aceptar coincidencias cercanas a las líneas largas de la misma frase
        for linea_t in lineas_texto:
            if len(linea_t.split()) < 2 and len(linea_t) < 14:
                try:
                    encontrados = pagina.search_for(linea_t, quads=False)
                except Exception:
                    encontrados = []
                for r in encontrados:
                    r_seg = rect_seguro(r)
                    if rects_lineas_largas:
                        # Debe estar cerca de alguna línea larga de esta frase (a menos de 60pt en Y)
                        if any(abs(r_seg.y0 - rl.y0) < 60.0 and abs(r_seg.x0 - rl.x0) < 150.0 for rl in rects_lineas_largas if rl):
                            anadir_rect(r)
                    elif len(lineas_texto) == 1:
                        # Si era una frase de 1 sola palabra explícita
                        anadir_rect(r)

    # Si hay un clip_busqueda (recuadro manual del usuario), asegurarse de que
    # TODAS las palabras/spans dentro de dicho recuadro quedan incluidas para borrar.
    if clip_busqueda is not None:
        try:
            for w in pagina.get_text("words"):
                r_w = fitz.Rect(w[:4])
                cx = (r_w.x0 + r_w.x1) / 2.0
                cy = (r_w.y0 + r_w.y1) / 2.0
                if clip_busqueda.x0 <= cx <= clip_busqueda.x1 and clip_busqueda.y0 <= cy <= clip_busqueda.y1:
                    anadir_rect(r_w)
        except Exception:
            pass

    return elementos_texto_eliminar
