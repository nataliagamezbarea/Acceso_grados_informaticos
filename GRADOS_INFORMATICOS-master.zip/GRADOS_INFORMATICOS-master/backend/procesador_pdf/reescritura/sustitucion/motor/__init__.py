from .extraccion import *
from .flujo_calculo import *
from .recuadros import *
from .clasificacion import *
from .pagina2 import *
from .redaccion_aplicacion import *
