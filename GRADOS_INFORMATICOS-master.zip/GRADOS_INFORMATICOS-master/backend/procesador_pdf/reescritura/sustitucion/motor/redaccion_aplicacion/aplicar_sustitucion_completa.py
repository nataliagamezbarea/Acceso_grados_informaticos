"""MOTOR PRINCIPAL · python/sustituir.py parametrizado para el visor: sin
input(); qué sustituir y qué eliminar llega por parámetros desde la lógica
de selección del propio visor (recuadros, popups de enunciado...)."""
from .preparar_contexto_sustitucion import preparar_contexto
from ..flujo_calculo.calcular_flujo_sustitucion import calcular_flujo_sustitucion
from .redactar_fases_sustitucion import redactar_fases_sustitucion
from .sustituir_enunciado import sustituir_enunciado
from .reescribir_lineas_pagina1 import reescribir_lineas_pagina1
from .mover_elementos_pagina1 import mover_elementos_pagina1
from ..recuadros.cerrar_recuadro_pagina1 import cerrar_recuadro_pagina1
from ..pagina2.crear_constructor_pagina_2 import crear_constructor_pagina_2


def aplicar_sustitucion_completa(doc, pagina, pno, texto_sustituir="",
                                 texto_nuevo="", textos_eliminar=(),
                                 ref_y=None, paginas_nuevas_pendientes=None,
                                 clip_busqueda=None):
    """Motor completo: análisis -> redacción -> reescritura -> continuación."""
    ctx = preparar_contexto(pagina, texto_sustituir, texto_nuevo, textos_eliminar, ref_y, clip_busqueda)
    if ctx is None:
        return False
    ctx = calcular_flujo_sustitucion(pagina, ctx)
    decision = ctx["decision"]
    if not decision["proceder"]:
        return False

    pagina = redactar_fases_sustitucion(
        doc, pagina, pno, ctx["hay_sustitucion"],
        ctx["spans_objetivo_originales"],
        ctx["lineas_afectadas"], ctx["textos_mover"], ctx["dibujos_mover"],
        ctx["imagenes_mover"], ctx["rect_cuadro"], ctx["dibujo_recuadro"],
        ctx["grosor_borde"])

    min_y_desb = decision["min_y_desborde"] if decision["hay_continuacion"] else None
    cerrar_recuadro_pagina1(
        doc, pno, ctx["rect_cuadro"], ctx["recuadro_desplazado"],
        ctx["color_borde"], ctx["grosor_borde"], decision["hay_continuacion"],
        ctx["limite_y_pag1"])
    mover_elementos_pagina1(
        doc, pno, ctx["textos_mover"], ctx["dibujos_mover"],
        ctx["imagenes_mover"], ctx["fn_final"], ctx["limite_y_pag1"],
        ctx["ratios_trazo"], min_y_desborde=min_y_desb)
    if ctx["hay_sustitucion"]:
        sustituir_enunciado(
            pagina, ctx["span_objetivo"], ctx["lineas_nuevas"],
            ctx["alto_linea_titulo"], ctx["fn_final"], ctx["ratios_trazo"])
    reescribir_lineas_pagina1(
        doc, pno, ctx["lineas_reconstruir"], ctx["fn_final"],
        ctx["limite_y_pag1"], ctx["ratios_trazo"], min_y_desborde=min_y_desb)

    if decision["hay_continuacion"] and paginas_nuevas_pendientes is not None:
        constructor = crear_constructor_pagina_2(
            ctx["ratios_trazo"], ctx["textos_mover"],
            ctx["lineas_reconstruir"], ctx["dibujos_mover"],
            ctx["imagenes_mover"], ctx["fn_final"], ctx["limite_y_pag1"],
            decision["min_y_desborde"], ctx["rect_cuadro"],
            ctx["recuadro_desplazado"], ctx["color_borde"],
            ctx["grosor_borde"], ctx["alto_pagina"])
        paginas_nuevas_pendientes.append({
            "despues_de": pno,
            "ancho": ctx["ancho_pagina"],
            "alto_pagina": ctx["alto_pagina"],
            "constructor": constructor,
        })
    return True
