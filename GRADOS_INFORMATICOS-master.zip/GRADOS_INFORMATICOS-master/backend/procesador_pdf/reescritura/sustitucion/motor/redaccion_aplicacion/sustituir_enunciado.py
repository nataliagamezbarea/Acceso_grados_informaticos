import os, pymupdf as fitz
from backend.procesador_pdf.reescritura.sustitucion.fuentes.obtener_objeto_fuente import obtener_objeto_fuente
from backend.procesador_pdf.reescritura.sustitucion.fuentes.escribir_span_con_fuente import escribir_span_con_fuente

def sustituir_enunciado(pagina, span_objetivo, lineas_nuevas,
                        alto_linea_titulo, fn_borrado, ratios_trazo):
    """Escribe el texto sustituto manteniendo centrado horizontal si el original estaba centrado."""
    if span_objetivo is None:
        return
    x_orig = span_objetivo["bbox"].x0
    y_cur = span_objetivo["origin"][1] + fn_borrado(span_objetivo["bbox"].y0)
    
    pw = pagina.rect.width
    x0, x1 = span_objetivo["bbox"].x0, span_objetivo["bbox"].x1
    orig_center_x = (x0 + x1) / 2.0
    margen_izq, margen_der = x0, pw - x1
    es_centrado = (x0 > 70.0) and (abs(margen_izq - margen_der) < 30.0) and (abs(orig_center_x - (pw / 2.0)) < 25.0)

    f_obj, ruta_fuente = obtener_objeto_fuente(span_objetivo["font"], span_objetivo["flags"])
    f_calc = fitz.Font(fontfile=ruta_fuente) if (ruta_fuente and os.path.exists(ruta_fuente)) else (f_obj or fitz.Font("helv"))

    for linea_txt in lineas_nuevas:
        if es_centrado:
            try:
                line_w = f_calc.text_length(linea_txt, fontsize=span_objetivo["size"])
                x_pos = max(10.0, orig_center_x - (line_w / 2.0))
            except Exception:
                x_pos = x_orig
        else:
            x_pos = x_orig

        escribir_span_con_fuente(
            pagina, linea_txt, (x_pos, y_cur),
            span_objetivo["font"], span_objetivo["flags"],
            span_objetivo["size"], span_objetivo["color"],
            span_objetivo.get("alpha", 255),
            ratios_trazo=ratios_trazo,
        )
        y_cur += alto_linea_titulo

