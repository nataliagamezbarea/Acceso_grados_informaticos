import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_rect import (
    desplazar_rect,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)
from backend.procesador_pdf.reescritura.sustitucion.fuentes.escribir_span_con_fuente import (
    escribir_span_con_fuente,
)
from backend.procesador_pdf.reescritura.sustitucion.vectores.dibujar_vector_desplazado import (
    dibujar_vector_desplazado,
)


def mover_elementos_pagina1(doc, pno, elementos_texto_mover, dibujos_mover,
                            imagenes_mover, fn_desplazamiento_final,
                            limite_y_pag1, ratios_trazo, min_y_desborde=None):
    """Mueve en la página 1 primero los vectores y las imágenes (fondo) y luego
    el texto (capa superior) cuyo rect final sigue cabiendo; lo que desborda
    lo recoge el constructor de la 2."""
    # 1. Vectores desplazados primero (fondo)
    for dibujo in dibujos_mover:
        r = rect_seguro(dibujo.get("rect"))
        if r is None:
            continue
        shift_elem = fn_desplazamiento_final(r.y0)
        nuevo_r = desplazar_rect(r, shift_elem)
        if nuevo_r.y1 > limite_y_pag1 or (min_y_desborde is not None and nuevo_r.y0 >= min_y_desborde - 2.0):
            continue
        pagina = doc.load_page(pno)
        dibujar_vector_desplazado(pagina, dibujo, shift_elem)

    # 2. Imágenes desplazadas (fondo)
    for imagen in imagenes_mover:
        r = imagen["rect"]
        shift_elem = fn_desplazamiento_final(r.y0)
        nuevo_r = desplazar_rect(r, shift_elem)
        if nuevo_r.y1 > limite_y_pag1 or (min_y_desborde is not None and nuevo_r.y0 >= min_y_desborde - 2.0):
            continue
        pagina = doc.load_page(pno)
        try:
            pagina.insert_image(nuevo_r, xref=imagen["xref"],
                                keep_proportion=False, overlay=True)
        except Exception:
            pass

    # 3. Texto desplazado al final (capa superior sobre vectores)
    for elem in elementos_texto_mover:
        bbox_original = elem["bbox"]
        shift_elem = fn_desplazamiento_final(bbox_original.y0)
        bbox_nuevo = desplazar_rect(bbox_original, shift_elem)
        if bbox_nuevo.y1 > limite_y_pag1 or (min_y_desborde is not None and bbox_nuevo.y0 >= min_y_desborde - 2.0):
            continue
        pagina = doc.load_page(pno)
        nuevo_origen = (elem["origin"][0], elem["origin"][1] + shift_elem)
        escribir_span_con_fuente(
            pagina, elem["texto"], (elem["bbox"].x0, nuevo_origen[1]),
            elem["font"], elem["flags"], elem["size"], elem["color"],
            elem.get("alpha", 255), ratios_trazo=ratios_trazo,
        )
