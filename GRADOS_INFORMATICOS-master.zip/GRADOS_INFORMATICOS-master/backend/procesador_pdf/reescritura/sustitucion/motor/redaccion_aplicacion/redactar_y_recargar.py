from backend.procesador_pdf.reescritura.sustitucion.configuracion import (
    PDF_REDACT_IMAGE_NONE,
    PDF_REDACT_LINE_ART_NONE,
    PDF_REDACT_TEXT_REMOVE,
)


def redactar_y_recargar(doc, pagina, pno, rects, fill=(1, 1, 1),
                        images=PDF_REDACT_IMAGE_NONE,
                        graphics=PDF_REDACT_LINE_ART_NONE,
                        text=PDF_REDACT_TEXT_REMOVE):
    """Añade anotaciones de redacción sobre EXACTAMENTE los rects dados, las
    aplica con las políticas indicadas (texto/vectores/imágenes) y recarga la
    página (los objetos de página quedan invalidados tras apply_redactions)."""
    if not rects:
        return pagina
    for r in rects:
        pagina.add_redact_annot(r, fill=fill, cross_out=False)
    pagina.apply_redactions(images=images, graphics=graphics, text=text)
    try:
        pagina.clean_contents()
    except Exception:
        pass
    return doc.load_page(pno)
