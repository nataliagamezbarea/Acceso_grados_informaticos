import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.configuracion import (
    PDF_REDACT_IMAGE_NONE,
    PDF_REDACT_IMAGE_REMOVE,
    PDF_REDACT_LINE_ART_NONE,
    PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED,
    PDF_REDACT_TEXT_NONE,
    PDF_REDACT_TEXT_REMOVE,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.ampliar_rect import (
    ampliar_rect,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.valor_seguro import valor_seguro
from .redactar_y_recargar import redactar_y_recargar


def redactar_fases_sustitucion(doc, pagina, pno, hay_sustitucion,
                               spans_objetivo_originales, lineas_afectadas,
                               elementos_texto_mover, dibujos_mover,
                               imagenes_mover, rect_cuadro, dibujo_recuadro,
                               grosor_borde):
    """Añade todas las anotaciones de redacción necesarias (título, líneas
    afectadas, textos a mover, dibujos vectoriales e imágenes) y aplica
    todas las redacciones en UNA SOLA PASADA ATÓMICA para garantizar que los
    comandos vectoriales se purguen limpiamente del stream de la página."""
    # 1. Título
    if hay_sustitucion:
        for s in (spans_objetivo_originales or []):
            pagina.add_redact_annot(
                fitz.Rect(s["bbox"].x0 - 2, s["bbox"].y0 - 2,
                          s["bbox"].x1 + 2, s["bbox"].y1 + 2),
                fill=(1, 1, 1), cross_out=False
            )

    # 2. Líneas afectadas
    if lineas_afectadas:
        for linea in lineas_afectadas:
            r = linea["bbox"] if (isinstance(linea, dict) and "bbox" in linea) else rect_seguro(linea)
            if r is not None:
                pagina.add_redact_annot(r, fill=(1, 1, 1), cross_out=False)

    # 3. Textos a mover
    if elementos_texto_mover:
        for elem in elementos_texto_mover:
            r = elem["bbox"] if (isinstance(elem, dict) and "bbox" in elem) else rect_seguro(elem)
            if r is not None:
                pagina.add_redact_annot(r, fill=(1, 1, 1), cross_out=False)

    # 4. Dibujos vectoriales a mover
    for dibujo in dibujos_mover:
        r = rect_seguro(dibujo.get("rect"))
        if r is not None:
            width = valor_seguro(dibujo.get("width"), 1.0)
            margen = max(2.0, width * 1.5)
            pagina.add_redact_annot(ampliar_rect(r, margen), fill=(1, 1, 1), cross_out=False)

    # 5. Imágenes a mover
    for imagen in imagenes_mover:
        pagina.add_redact_annot(imagen["rect"], fill=(1, 1, 1), cross_out=False)

    # 6. Recuadro contenedor si se desplaza
    if rect_cuadro is not None and dibujo_recuadro is not None:
        pagina.add_redact_annot(
            ampliar_rect(rect_cuadro, max(1.0, grosor_borde)),
            fill=None, cross_out=False
        )

    # APLICACIÓN ATÓMICA ÚNICA
    pagina.apply_redactions(
        images=PDF_REDACT_IMAGE_REMOVE if imagenes_mover else PDF_REDACT_IMAGE_NONE,
        graphics=PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED,
        text=PDF_REDACT_TEXT_REMOVE
    )
    try:
        pagina.clean_contents()
    except Exception:
        pass
    return doc.load_page(pno)
