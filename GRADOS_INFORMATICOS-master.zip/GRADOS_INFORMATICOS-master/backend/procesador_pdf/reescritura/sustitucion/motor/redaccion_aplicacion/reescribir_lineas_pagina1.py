from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_rect import (
    desplazar_rect,
)
from backend.procesador_pdf.reescritura.sustitucion.fuentes.escribir_linea_con_runs import (
    escribir_linea_con_runs,
)


def reescribir_lineas_pagina1(doc, pno, lineas_reconstruir,
                              fn_desplazamiento_final, limite_y_pag1,
                              ratios_trazo, min_y_desborde=None):
    """Vuelve a escribir las líneas afectadas que SIGUEN en la página 1, con
    sus runs originales y desplazadas lo justo. Las que desbordan continúan
    en la página 2 (constructor diferido)."""
    for linea in lineas_reconstruir:
        shift_elem = fn_desplazamiento_final(linea["bbox"].y0)
        bbox_nuevo = desplazar_rect(linea["bbox"], shift_elem)
        if bbox_nuevo.y1 > limite_y_pag1 or (min_y_desborde is not None and bbox_nuevo.y0 >= min_y_desborde - 2.0):
            continue
        pagina = doc.load_page(pno)
        escribir_linea_con_runs(
            pagina,
            linea.get("runs") or [{
                "texto": linea["texto"], "font": linea["font"], "flags": linea["flags"],
                "size": linea["size"], "color": linea["color"], "alpha": linea["alpha"],
            }],
            (linea["bbox"].x0, linea["origin"][1] + shift_elem),
            ratios_trazo=ratios_trazo,
        )
