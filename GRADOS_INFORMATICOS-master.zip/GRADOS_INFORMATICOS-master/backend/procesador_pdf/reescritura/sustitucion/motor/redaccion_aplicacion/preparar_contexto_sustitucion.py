"""FASES 1-4 · Análisis SIN tocar el PDF: spans objetivo, zona afectada,
recuadro contenedor y crecimiento del título."""
import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.trazo.detectar_ratios_trazo import detectar_ratios_trazo
from ..extraccion.extraer_spans import extraer_spans
from ..extraccion.extraer_lineas_rawdict import extraer_lineas_rawdict
from ..extraccion.localizar_objetivo import localizar_objetivo
from ..clasificacion.buscar_rects_eliminar import buscar_rects_textos_eliminar
from ..recuadros.localizar_recuadro import localizar_recuadro
from ..flujo_calculo.calcular_crecimiento_titulo import calcular_crecimiento_titulo
from ..clasificacion.clasificar_borrado import clasificar_borrado


def preparar_contexto(pagina, texto_sustituir, texto_nuevo, textos_eliminar,
                      ref_y, clip_busqueda):
    """Devuelve el contexto completo del motor o None si no hay nada que hacer."""
    alto_pagina = pagina.rect.height
    texto_sustituir = (texto_sustituir or "").strip()
    texto_nuevo = (texto_nuevo or "").strip()
    hay_sustitucion = bool(texto_sustituir and texto_nuevo)
    textos_eliminar = [t.strip() for t in (textos_eliminar or []) if t and t.strip()]
    ratios_trazo = detectar_ratios_trazo(pagina)
    spans_encontrados = extraer_spans(pagina)
    span_objetivo = None
    spans_objetivo_originales = []
    if hay_sustitucion:
        span_objetivo, spans_objetivo_originales = localizar_objetivo(
            spans_encontrados, texto_sustituir, ref_y, pagina)
    lineas_originales = extraer_lineas_rawdict(pagina)
    if hay_sustitucion and span_objetivo is None:
        return None
    if not hay_sustitucion and not textos_eliminar:
        return None
    dibujos_originales = pagina.get_drawings()
    elementos_texto_eliminar = buscar_rects_textos_eliminar(
        pagina, textos_eliminar, clip_busqueda)
    if span_objetivo is not None and span_objetivo["bbox"].y0 < 400:
        elementos_texto_eliminar = [r for r in elementos_texto_eliminar if r.y0 < 500]
    bbox_zona_afectada = fitz.Rect()
    if span_objetivo is not None:
        bbox_zona_afectada.include_rect(span_objetivo["bbox"])
    for r_del in elementos_texto_eliminar:
        bbox_zona_afectada.include_rect(r_del)
    rect_cuadro, dibujo_recuadro, color_borde, grosor_borde = localizar_recuadro(
        dibujos_originales, bbox_zona_afectada, elementos_texto_eliminar, span_objetivo=span_objetivo)
    if hay_sustitucion:
        lineas_nuevas, alto_titulo, desplazamiento_y = calcular_crecimiento_titulo(
            span_objetivo, texto_nuevo, pagina.rect.width)
    else:
        lineas_nuevas, alto_titulo, desplazamiento_y = [], 0.0, 0.0
    clasif = clasificar_borrado(
        lineas_originales, span_objetivo, spans_objetivo_originales,
        elementos_texto_eliminar, spans_encontrados)
    lr = clasif["lineas_reconstruir"]
    lve = clasif["lineas_vacias_eliminadas"]
    se = clasif["spans_completamente_eliminados"]
    be = clasif["bloques_eliminados"]
    if span_objetivo and span_objetivo["bbox"].y0 < 400:
        lr = [l for l in lr if l["bbox"].y0 < 550]
        lve = [l for l in lve if l["bbox"].y0 < 550]
        se = [s for s in se if s["bbox"].y0 < 550]
        be = [b for b in be if b["y0"] < 550]
    la = lr + lve
    return {
        "alto_pagina": alto_pagina,
        "ancho_pagina": pagina.rect.width,
        "hay_sustitucion": hay_sustitucion,
        "span_objetivo": span_objetivo,
        "spans_objetivo_originales": spans_objetivo_originales,
        "ratios_trazo": ratios_trazo,
        "spans_encontrados": spans_encontrados,
        "dibujos_originales": dibujos_originales,
        "rect_cuadro": rect_cuadro,
        "dibujo_recuadro": dibujo_recuadro,
        "color_borde": color_borde,
        "grosor_borde": grosor_borde,
        "lineas_nuevas": lineas_nuevas,
        "alto_linea_titulo": alto_titulo,
        "desplazamiento_y": desplazamiento_y,
        "lineas_reconstruir": lr,
        "lineas_afectadas": la,
        "bloques_eliminados": be,
        "spans_eliminados": se,
    }
