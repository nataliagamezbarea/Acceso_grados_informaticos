from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_rect import (
    desplazar_rect,
)


def construir_elementos_flujo(elementos_texto_mover, lineas_reconstruir,
                              dibujos_mover, imagenes_mover,
                              fn_desplazamiento_elemento):
    """Lista única de TODO lo que fluye (texto, líneas reconstruidas, vectores
    e imágenes) con su rect original y su rect base (desplazado sin compactar),
    ordenada por posición final."""
    def bbox_base(rect):
        return desplazar_rect(rect, fn_desplazamiento_elemento(rect.y0))

    elementos_flujo = []
    for elem in elementos_texto_mover:
        elementos_flujo.append({
            "tipo": "texto", "objeto": elem,
            "original": elem["bbox"], "bbox_base": bbox_base(elem["bbox"]),
        })
    for linea in lineas_reconstruir:
        elementos_flujo.append({
            "tipo": "texto_linea", "objeto": linea,
            "original": linea["bbox"], "bbox_base": bbox_base(linea["bbox"]),
        })
    for dibujo in dibujos_mover:
        r_original = rect_seguro(dibujo.get("rect"))
        if r_original is None:
            continue
        elementos_flujo.append({
            "tipo": "dibujo", "objeto": dibujo,
            "original": r_original, "bbox_base": bbox_base(r_original),
        })
    for imagen in imagenes_mover:
        elementos_flujo.append({
            "tipo": "imagen", "objeto": imagen,
            "original": imagen["rect"], "bbox_base": bbox_base(imagen["rect"]),
        })
    elementos_flujo.sort(key=lambda it: (it["bbox_base"].y0, it["bbox_base"].x0))
    return elementos_flujo
