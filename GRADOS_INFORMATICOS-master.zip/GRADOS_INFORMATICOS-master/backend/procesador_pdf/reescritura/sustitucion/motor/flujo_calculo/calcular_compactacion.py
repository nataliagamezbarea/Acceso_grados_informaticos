from backend.procesador_pdf.reescritura.sustitucion.configuracion import (
    AIRE_MINIMO_ENTRE_BLOQUES,
    TOLERANCIA_Y,
)


def calcular_compactacion(elementos_flujo, primer_indice_desborde, limite_y_pag1=None):
    """Hueco blanco real que puede comprimirse antes de saltar a la página 2:
    si el primer elemento que desborda tiene aire de sobra con el anterior,
    solo se compacta el EXCESO necesario para que los elementos quepan en la página
    (o hasta agotar el hueco disponible), preservando la posición natural y el
    espaciado del documento en vez de empujar todo el bloque hacia arriba."""
    compactacion_extra = 0.0
    y_corte_compactacion_original = None
    if primer_indice_desborde is not None:
        primer_desborde = elementos_flujo[primer_indice_desborde]
        bbox_primer_desborde = primer_desborde["bbox_base"]

        # Calcular el exceso real que sobrepasa el límite inferior
        if limite_y_pag1 is not None:
            max_y1 = max(item["bbox_base"].y1 for item in elementos_flujo)
            exceso = max(0.0, max_y1 - limite_y_pag1)
        else:
            exceso = None

        y_fin_anterior = None
        for item in elementos_flujo[:primer_indice_desborde]:
            bbox_item = item["bbox_base"]
            if y_fin_anterior is None or bbox_item.y1 > y_fin_anterior:
                y_fin_anterior = bbox_item.y1
        if y_fin_anterior is not None:
            hueco_real = max(0.0, bbox_primer_desborde.y0 - y_fin_anterior)
            hueco_disponible = max(0.0, hueco_real - AIRE_MINIMO_ENTRE_BLOQUES)
            if exceso is not None:
                compactacion_extra = min(exceso, hueco_disponible)
            else:
                compactacion_extra = hueco_disponible
            if compactacion_extra > TOLERANCIA_Y:
                y_corte_compactacion_original = primer_desborde["original"].y0
    return compactacion_extra, y_corte_compactacion_original
