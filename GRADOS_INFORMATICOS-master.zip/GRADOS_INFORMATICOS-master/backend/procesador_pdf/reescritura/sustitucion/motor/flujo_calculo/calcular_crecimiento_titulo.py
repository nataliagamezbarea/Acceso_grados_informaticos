from backend.procesador_pdf.reescritura.sustitucion.fuentes.obtener_objeto_fuente import (
    obtener_objeto_fuente,
)
from backend.procesador_pdf.reescritura.sustitucion.fuentes.dividir_lineas_con_fuente import (
    dividir_lineas_con_fuente,
)


def calcular_crecimiento_titulo(span_objetivo, texto_nuevo, ancho_pagina):
    """Cuánto CRECE el bloque del título al escribir el texto nuevo y con qué
    reparto de líneas: base para empujar SOLO lo que hay debajo."""
    f_obj_titulo, _ = obtener_objeto_fuente(span_objetivo["font"], span_objetivo["flags"])
    # Ancho disponible desde x0 hasta el margen derecho (36.0pt)
    margen_derecho = 36.0
    x0 = span_objetivo["bbox"].x0
    ancho_disponible = max(50.0, ancho_pagina - x0 - margen_derecho)
    size = span_objetivo["size"]

    lineas_nuevas = dividir_lineas_con_fuente(
        texto_nuevo, f_obj_titulo, size, ancho_disponible
    )
    if not lineas_nuevas:
        lineas_nuevas = [texto_nuevo]
    alto_linea_titulo = size * 1.25
    altura_original_titulo = max(span_objetivo["bbox"].height, alto_linea_titulo)
    altura_nueva_titulo = len(lineas_nuevas) * alto_linea_titulo
    desplazamiento_y = altura_nueva_titulo - altura_original_titulo
    return lineas_nuevas, alto_linea_titulo, desplazamiento_y
