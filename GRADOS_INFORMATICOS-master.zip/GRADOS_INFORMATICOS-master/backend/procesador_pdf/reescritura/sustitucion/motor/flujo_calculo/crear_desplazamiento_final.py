from backend.procesador_pdf.reescritura.sustitucion.configuracion import TOLERANCIA_Y


def crear_desplazamiento_final(fn_elemento, compactacion_extra,
                               y_corte_compactacion_original):
    """Devuelve f(y0): desplazamiento definitivo (base - compactación extra
    aplicada solo por debajo del punto de corte)."""
    def desplazamiento_final_elemento(y0):
        total = fn_elemento(y0)
        if (
            compactacion_extra > TOLERANCIA_Y
            and y_corte_compactacion_original is not None
            and y0 >= y_corte_compactacion_original - TOLERANCIA_Y
        ):
            total -= compactacion_extra
        return total
    return desplazamiento_final_elemento
