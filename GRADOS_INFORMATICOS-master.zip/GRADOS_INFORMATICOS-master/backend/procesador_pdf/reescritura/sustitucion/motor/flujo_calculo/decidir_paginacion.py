from backend.procesador_pdf.reescritura.sustitucion.configuracion import (
    MARGEN_SEGURIDAD_RECUADRO,
    TOLERANCIA_Y,
)


def decidir_paginacion(elementos_flujo, rect_cuadro_desplazado,
                       lineas_afectadas, hay_sustitucion, alto_pagina,
                       limite_y_pag1):
    """Decisión DEFINITIVA: ¿todo cabe en la página 1? ¿qué desborda?
    ¿hace falta página de continuación? ¿o no hay nada que hacer?"""
    limite_y_recuadro = alto_pagina - MARGEN_SEGURIDAD_RECUADRO
    if rect_cuadro_desplazado is not None:
        y_final_real = rect_cuadro_desplazado.y1
    else:
        y_final_real = max([item["bbox_final"].y1 for item in elementos_flujo] + [0.0])
    todo_cabe_en_pagina_1 = y_final_real <= limite_y_recuadro + TOLERANCIA_Y

    elementos_desborde = []
    if not todo_cabe_en_pagina_1:
        for item in elementos_flujo:
            r = item["bbox_final"]
            if r.y1 > limite_y_pag1:
                elementos_desborde.append((r.y0, item["tipo"], item["objeto"]))
    if elementos_desborde:
        min_y_desborde = min(item[0] for item in elementos_desborde)
    elif not todo_cabe_en_pagina_1 and rect_cuadro_desplazado is not None:
        min_y_desborde = rect_cuadro_desplazado.y0
    else:
        min_y_desborde = limite_y_pag1

    hay_continuacion = not todo_cabe_en_pagina_1
    proceder = bool(elementos_desborde or lineas_afectadas or hay_sustitucion or hay_continuacion)
    return {
        "todo_cabe": todo_cabe_en_pagina_1,
        "hay_continuacion": hay_continuacion,
        "min_y_desborde": min_y_desborde,
        "proceder": proceder,
    }
