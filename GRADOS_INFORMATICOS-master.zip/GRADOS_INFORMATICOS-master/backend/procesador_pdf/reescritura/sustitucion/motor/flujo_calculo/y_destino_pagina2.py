from backend.procesador_pdf.reescritura.sustitucion.configuracion import (
    MARGEN_SUPERIOR_NUEVA_PAGINA,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_rect import (
    desplazar_rect,
)


def y_destino_pagina2(rect_original, fn_desplazamiento_final,
                      limite_y_pag1, min_y_desborde):
    """Posición del elemento en la página de continuación.
    Devuelve (rect_nuevo, y_top_p2) o (None, None) si NO desborda."""
    shift_elem = fn_desplazamiento_final(rect_original.y0)
    rect_nuevo = desplazar_rect(rect_original, shift_elem)
    if rect_nuevo.y1 <= limite_y_pag1 and rect_nuevo.y0 < min_y_desborde - 2.0:
        return None, None
    y_top_p2 = MARGEN_SUPERIOR_NUEVA_PAGINA + max(0.0, rect_nuevo.y0 - min_y_desborde)
    return rect_nuevo, y_top_p2
