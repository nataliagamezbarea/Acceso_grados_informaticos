from backend.procesador_pdf.reescritura.sustitucion.configuracion import MARGEN_INFERIOR
from .desplazamientos_base import crear_desplazamiento_por_borrado, crear_desplazamiento_elemento
from .crear_desplazamiento_final import crear_desplazamiento_final
from ..clasificacion.clasificar_texto_mover import clasificar_texto_mover
from ..clasificacion.clasificar_dibujos_mover import clasificar_dibujos_mover
from ..clasificacion.clasificar_imagenes_mover import clasificar_imagenes_mover
from .construir_elementos_flujo import construir_elementos_flujo
from .calcular_flujo_base import calcular_flujo_base
from ..recuadros.asignar_bbox_final import asignar_bbox_final
from ..recuadros.ajustar_recuadro_final import ajustar_recuadro_final
from .decidir_paginacion import decidir_paginacion
from ..recuadros.calcular_ajuste_recuadro import calcular_ajuste_recuadro


def calcular_flujo_sustitucion(pagina, ctx):
    """Completa el contexto con funciones de desplazamiento y elementos a mover."""
    objetivo = ctx["span_objetivo"]
    y_inicio_titulo = objetivo["bbox"].y1 + 1.0 if objetivo is not None else None
    fn_borrado = crear_desplazamiento_por_borrado(ctx["bloques_eliminados"])
    rect_cuadro = ctx.get("rect_cuadro")
    limite_y_pag1 = ctx["alto_pagina"] - MARGEN_INFERIOR
    ajuste_recuadro = calcular_ajuste_recuadro(rect_cuadro, ctx, limite_y_pag1)

    fn_elem = crear_desplazamiento_elemento(
        fn_borrado, ctx["hay_sustitucion"], y_inicio_titulo,
        ctx["desplazamiento_y"], ajuste_recuadro=ajuste_recuadro)
    textos_mover = clasificar_texto_mover(
        ctx["spans_encontrados"], ctx["spans_objetivo_originales"],
        ctx["spans_eliminados"], ctx["lineas_afectadas"], fn_elem)
    dibujos_mover = clasificar_dibujos_mover(
        ctx["dibujos_originales"], ctx["dibujo_recuadro"], fn_elem,
        rect_cuadro=ctx["rect_cuadro"], lineas_reconstruir=ctx["lineas_reconstruir"],
        spans_encontrados=ctx["spans_encontrados"],
        spans_completamente_eliminados=ctx["spans_eliminados"])
    imagenes_mover = clasificar_imagenes_mover(pagina, fn_elem)

    elementos_flujo = construir_elementos_flujo(
        textos_mover, ctx["lineas_reconstruir"], dibujos_mover,
        imagenes_mover, fn_elem)
    _primer_indice, compactacion_extra, y_corte = calcular_flujo_base(
        elementos_flujo, limite_y_pag1)
    fn_final = crear_desplazamiento_final(fn_elem, compactacion_extra, y_corte)
    asignar_bbox_final(elementos_flujo, fn_final)
    recuadro_desplazado = ajustar_recuadro_final(
        pagina, ctx["rect_cuadro"], fn_final,
        ctx["spans_encontrados"], objetivo, ctx["spans_objetivo_originales"],
        ctx["lineas_reconstruir"], ctx["lineas_afectadas"],
        ctx["spans_eliminados"], ctx["dibujos_originales"],
        ctx["dibujo_recuadro"], len(ctx["lineas_nuevas"]),
        ctx["alto_linea_titulo"])
    decision = decidir_paginacion(
        elementos_flujo, recuadro_desplazado, ctx["lineas_afectadas"],
        ctx["hay_sustitucion"], ctx["alto_pagina"], limite_y_pag1)
    ctx.update({
        "fn_borrado": fn_borrado, "fn_elem": fn_elem, "fn_final": fn_final,
        "textos_mover": textos_mover, "dibujos_mover": dibujos_mover,
        "imagenes_mover": imagenes_mover, "limite_y_pag1": limite_y_pag1,
        "elementos_flujo": elementos_flujo,
        "recuadro_desplazado": recuadro_desplazado,
        "decision": decision,
    })
    return ctx
