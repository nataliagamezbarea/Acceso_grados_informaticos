from backend.procesador_pdf.reescritura.sustitucion.configuracion import TOLERANCIA_Y


def crear_desplazamiento_por_borrado(bloques_eliminados):
    def desplazamiento_por_borrado(y0):
        total = 0.0
        for grupo in bloques_eliminados:
            if grupo["y1"] <= y0 + TOLERANCIA_Y:
                total += grupo["altura"]
        return -total
    return desplazamiento_por_borrado


def crear_desplazamiento_elemento(fn_borrado, hay_sustitucion,
                                  y_inicio_contenido_titulo, desplazamiento_y,
                                  ajuste_recuadro=None):
    def desplazamiento_elemento(y0):
        if ajuste_recuadro is not None:
            r_box = ajuste_recuadro["rect"]
            if r_box.y0 - TOLERANCIA_Y <= y0 <= r_box.y1 + TOLERANCIA_Y:
                return ajuste_recuadro["shift"]
        total = fn_borrado(y0)
        # Si el elemento está en la zona de pie de página/portada (y0 > 500) con gran margen libre, no desplazar
        if (
            hay_sustitucion
            and y_inicio_contenido_titulo is not None
            and y0 >= y_inicio_contenido_titulo
        ):
            total += desplazamiento_y
        return total
    return desplazamiento_elemento
