from backend.procesador_pdf.reescritura.sustitucion.geometria.interseca import (
    interseca,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)


def padding_inferior_original(rect_cuadro, spans_encontrados,
                              spans_objetivo_originales, lineas_reconstruir,
                              lineas_afectadas, spans_completamente_eliminados,
                              dibujos_originales, dibujo_recuadro,
                              span_objetivo):
    """Distancia, en el PDF ORIGINAL (sin desplazar nada todavía), entre el
    borde inferior del recuadro y el contenido que sigue dentro tras el
    borrado. Es el hueco real que había bajo el texto en el documento de
    partida y que hay que conservar al reconstruir el recuadro.

    Antes se sustituía siempre por MARGEN_INTERIOR_RECUADRO (un valor fijo
    de 10pt), así que si el recuadro original dejaba más aire que eso bajo
    el texto, ese aire se perdía y el recuadro quedaba más "justo" de lo
    que estaba en el original. Devuelve None si no hay contenido de
    referencia (no se puede calcular).
    """
    spans_objetivo_originales = spans_objetivo_originales or []

    def dentro(r):
        return (
            r.x0 >= rect_cuadro.x0 - 1.0 and r.x1 <= rect_cuadro.x1 + 1.0
            and r.y0 >= rect_cuadro.y0 - 1.0 and r.y1 <= rect_cuadro.y1 + 1.0
        )

    def pertenece_a_linea_afectada(bbox):
        return any(interseca(bbox, linea["bbox"]) for linea in lineas_afectadas)

    y1s = []
    for span in spans_encontrados:
        if any(span is s for s in spans_objetivo_originales):
            continue
        if span in spans_completamente_eliminados:
            continue
        if pertenece_a_linea_afectada(span["bbox"]):
            continue
        if dentro(span["bbox"]):
            y1s.append(span["bbox"].y1)

    for linea in lineas_reconstruir:
        if dentro(linea["bbox"]):
            y1s.append(linea["bbox"].y1)

    for dibujo in dibujos_originales:
        if dibujo_recuadro is not None and dibujo is dibujo_recuadro:
            continue
        r = rect_seguro(dibujo.get("rect"))
        if r is not None and dentro(r):
            y1s.append(r.y1)

    if span_objetivo is not None and dentro(span_objetivo["bbox"]):
        y1s.append(span_objetivo["bbox"].y1)

    if not y1s:
        return None
    return max(0.0, rect_cuadro.y1 - max(y1s))
