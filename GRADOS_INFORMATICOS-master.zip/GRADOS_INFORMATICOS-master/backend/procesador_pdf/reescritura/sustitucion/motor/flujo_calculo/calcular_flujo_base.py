from .calcular_compactacion import calcular_compactacion


def calcular_flujo_base(elementos_flujo, limite_y_pag1):
    """Primer elemento cuyo bbox base desborda la página + compactación
    posible. Devuelve (primer_indice, compactacion_extra, y_corte)."""
    primer_indice_desborde = None
    for indice, item in enumerate(elementos_flujo):
        if item["bbox_base"].y1 > limite_y_pag1:
            primer_indice_desborde = indice
            break
    compactacion_extra, y_corte = calcular_compactacion(
        elementos_flujo, primer_indice_desborde, limite_y_pag1
    )
    return primer_indice_desborde, compactacion_extra, y_corte
