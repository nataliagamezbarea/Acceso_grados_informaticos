import pymupdf as fitz

def calcular_ajuste_recuadro(rect_cuadro, ctx, limite_y_pag1):
    """Calcula el ajuste hacia abajo del contenido y recorte superior del recuadro
    para que la última línea coincida exactamente con el final del original."""
    if rect_cuadro is None:
        return None
    spans_eliminados = ctx.get("spans_eliminados") or []
    spans_encontrados = ctx.get("spans_encontrados") or []
    spans_obj = ctx.get("spans_objetivo_originales") or []
    surviving = []
    for s in spans_encontrados:
        if s not in spans_eliminados and not any(s is so for so in spans_obj) and rect_cuadro.y0 - 1.0 <= s["bbox"].y0 <= rect_cuadro.y1 + 1.0:
            surviving.append(s["bbox"])
    for l in ctx.get("lineas_reconstruir") or []:
        if rect_cuadro.y0 - 1.0 <= l["bbox"].y0 <= rect_cuadro.y1 + 1.0:
            surviving.append(l["bbox"])
    if ctx.get("span_objetivo") and rect_cuadro.contains(ctx["span_objetivo"]["bbox"]):
        alt_tit = len(ctx.get("lineas_nuevas", [])) * ctx.get("alto_linea_titulo", 16.0)
        y0_tit = ctx["span_objetivo"]["bbox"].y0
        surviving.append(fitz.Rect(ctx["span_objetivo"]["bbox"].x0, y0_tit, ctx["span_objetivo"]["bbox"].x1, y0_tit + alt_tit))

    if not surviving:
        return None
    min_y0 = min(b.y0 for b in surviving)
    max_y1 = max(b.y1 for b in surviving)
    target_bottom_text = rect_cuadro.y1 - 13.5
    shift = max(0.0, target_bottom_text - max_y1)
    y1_box = rect_cuadro.y1
    y0_box = (min_y0 + shift) - 6.0
    return {"rect": rect_cuadro, "shift": shift, "y0_box": y0_box, "y1_box": y1_box}
