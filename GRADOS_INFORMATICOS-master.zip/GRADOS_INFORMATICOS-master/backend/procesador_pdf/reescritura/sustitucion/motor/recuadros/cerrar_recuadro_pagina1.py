import pymupdf as fitz


def cerrar_recuadro_pagina1(doc, pno, rect_cuadro, rect_cuadro_desplazado,
                            color_borde, grosor_borde, hay_continuacion,
                            limite_y_pag1):
    """Reconstruye el recuadro en la página 1. Si todo cabe: recuadro completo cerrado.
    Si hay continuación y el recuadro empezó en la pág 1: borde superior y laterales
    abiertos por abajo (la pág 2 continúa y cierra el recuadro)."""
    if rect_cuadro is None or rect_cuadro_desplazado is None:
        return
    pagina = doc.load_page(pno)
    x0 = rect_cuadro.x0
    x1 = rect_cuadro.x1
    if hay_continuacion:
        if rect_cuadro_desplazado.y0 < limite_y_pag1 - 20.0:
            y0_p1 = max(0.0, rect_cuadro_desplazado.y0)
            y1_p1 = limite_y_pag1
            pagina.draw_line(fitz.Point(x0, y0_p1), fitz.Point(x1, y0_p1),
                             color=color_borde, width=grosor_borde, overlay=True)
            pagina.draw_line(fitz.Point(x0, y0_p1), fitz.Point(x0, y1_p1),
                             color=color_borde, width=grosor_borde, overlay=True)
            pagina.draw_line(fitz.Point(x1, y0_p1), fitz.Point(x1, y1_p1),
                             color=color_borde, width=grosor_borde, overlay=True)
    else:
        pagina.draw_rect(rect_cuadro_desplazado, color=color_borde,
                         width=grosor_borde, overlay=True)
