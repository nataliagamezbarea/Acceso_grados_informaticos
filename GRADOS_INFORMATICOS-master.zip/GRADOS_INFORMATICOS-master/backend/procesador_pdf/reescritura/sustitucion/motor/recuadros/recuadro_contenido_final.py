import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_rect import (
    desplazar_rect,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.interseca import (
    interseca,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)


def recuadro_contenido_final(pagina, rect_cuadro, fn_desplazamiento_final,
                             spans_encontrados, spans_objetivo_originales,
                             lineas_reconstruir, lineas_afectadas,
                             spans_completamente_eliminados,
                             dibujos_originales, dibujo_recuadro):
    """Rects FINALES de todo el contenido que queda DENTRO del recuadro
    (texto, líneas reconstruidas, vectores e imágenes), para garantizar el
    margen interior del recuadro reconstruido.

    spans_objetivo_originales: lista de spans REALES del objetivo (uno o
    varios si el objetivo era multilínea) -- se excluyen porque van a ser
    borrados y reescritos, no "siguen existiendo" tal cual.
    """
    spans_objetivo_originales = spans_objetivo_originales or []

    def dentro(r_original):
        return (
            r_original.x0 >= rect_cuadro.x0 - 1.0 and r_original.x1 <= rect_cuadro.x1 + 1.0
            and r_original.y0 >= rect_cuadro.y0 - 1.0 and r_original.y1 <= rect_cuadro.y1 + 1.0
        )

    def pertenece_a_linea_afectada(bbox):
        return any(interseca(bbox, linea["bbox"]) for linea in lineas_afectadas)

    def bbox_final(r_original):
        return desplazar_rect(r_original, fn_desplazamiento_final(r_original.y0))

    contenido = []
    contenido_texto_orig = []
    for span in spans_encontrados:
        if any(span is s for s in spans_objetivo_originales):
            continue
        if span in spans_completamente_eliminados:
            continue
        if pertenece_a_linea_afectada(span["bbox"]):
            continue
        if dentro(span["bbox"]):
            contenido.append(bbox_final(span["bbox"]))
            contenido_texto_orig.append(span["bbox"])
    for linea in lineas_reconstruir:
        if dentro(linea["bbox"]):
            contenido.append(bbox_final(linea["bbox"]))
            contenido_texto_orig.append(linea["bbox"])
    for dibujo in dibujos_originales:
        if dibujo_recuadro is not None and dibujo is dibujo_recuadro:
            continue
        r_original = rect_seguro(dibujo.get("rect"))
        if r_original is not None and dentro(r_original):
            # Ignorar separadores/vectores bajo texto eliminado
            if contenido_texto_orig:
                max_txt_y = max(r.y1 for r in contenido_texto_orig)
                if r_original.y0 > max_txt_y + 8.0:
                    continue
            contenido.append(bbox_final(r_original))
    try:
        imagenes = pagina.get_images()
    except Exception:
        imagenes = []
    for img_info in imagenes:
        try:
            xref = img_info[0]
            rects_img = pagina.get_image_rects(xref)
        except Exception:
            continue
        for rect_img in rects_img:
            r_original = rect_seguro(rect_img)
            if r_original is not None and dentro(r_original):
                contenido.append(bbox_final(r_original))
    return contenido
