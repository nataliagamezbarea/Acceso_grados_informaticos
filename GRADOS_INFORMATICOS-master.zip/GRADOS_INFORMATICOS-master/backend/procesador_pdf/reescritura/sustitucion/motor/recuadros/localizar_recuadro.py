import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.valor_seguro import (
    valor_seguro,
)


def localizar_recuadro(dibujos_originales, bbox_zona_afectada, elementos_texto_eliminar=None, span_objetivo=None):
    """Primer dibujo vectorial CON BORDE que contiene el span objetivo (si hay título)
    o los textos a borrar."""
    rect_cuadro = None
    dibujo_recuadro = None
    color_borde = (0, 0, 0)
    grosor_borde = 1.0
    for dibujo in dibujos_originales:
        r = rect_seguro(dibujo.get("rect"))
        if r is None: continue
        if not (dibujo.get("color") or (dibujo.get("fill") and dibujo.get("type") in ("f", "fs"))): continue
        c = dibujo.get("color")
        if c and len(c) == 3 and all(v >= 0.98 for v in c) and not dibujo.get("fill"): continue
        if r.width < 40 or r.height < 20: continue
        r_amp = fitz.Rect(r.x0 - 4.0, r.y0 - 4.0, r.x1 + 4.0, r.y1 + 4.0)

        if span_objetivo is not None:
            obj_box = span_objetivo.get("bbox")
            if obj_box and r_amp.contains(obj_box):
                rect_cuadro, dibujo_recuadro = r, dibujo
                color_borde = dibujo.get("color") or (0, 0, 0)
                grosor_borde = valor_seguro(dibujo.get("width"), 1.0)
                break
        elif bbox_zona_afectada.is_valid and r_amp.contains(bbox_zona_afectada):
            rect_cuadro, dibujo_recuadro = r, dibujo
            color_borde = dibujo.get("color") or (0, 0, 0)
            grosor_borde = valor_seguro(dibujo.get("width"), 1.0)
            break
        elif elementos_texto_eliminar and not span_objetivo:
            if any(r_amp.contains(rect_seguro(re)) or (r.intersects(rect_seguro(re)) and (r & rect_seguro(re)).get_area() >= 0.5 * rect_seguro(re).get_area()) for re in elementos_texto_eliminar if rect_seguro(re)):
                rect_cuadro, dibujo_recuadro = r, dibujo
                color_borde = dibujo.get("color") or (0, 0, 0)
                grosor_borde = valor_seguro(dibujo.get("width"), 1.0)
                break
    return rect_cuadro, dibujo_recuadro, color_borde, grosor_borde
