import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.configuracion import (
    MARGEN_INTERIOR_RECUADRO,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_rect import desplazar_rect
from .recuadro_contenido_final import recuadro_contenido_final
from .recuadro_titulo_proyectado import recuadro_titulo_proyectado


def ajustar_recuadro_final(pagina, rect_cuadro, fn_desplazamiento_final,
                           spans_encontrados, span_objetivo,
                           spans_objetivo_originales,
                           lineas_reconstruir, lineas_afectadas,
                           spans_completamente_eliminados,
                           dibujos_originales, dibujo_recuadro,
                           numero_lineas_nuevas, alto_linea_titulo):
    """Ajusta el recuadro exactamente al contenido final: crece si el texto se expande
    y se recorta hacia arriba si se eliminan líneas o el texto es más corto."""
    if rect_cuadro is None:
        return None
    desplazamiento_recuadro = fn_desplazamiento_final(rect_cuadro.y0)
    y0_desplazado = rect_cuadro.y0 + desplazamiento_recuadro

    contenido_final_cuadro = recuadro_contenido_final(
        pagina, rect_cuadro, fn_desplazamiento_final,
        spans_encontrados, spans_objetivo_originales,
        lineas_reconstruir, lineas_afectadas,
        spans_completamente_eliminados,
        dibujos_originales, dibujo_recuadro,
    )
    titulo = recuadro_titulo_proyectado(
        span_objetivo, rect_cuadro, fn_desplazamiento_final,
        numero_lineas_nuevas, alto_linea_titulo,
    )
    if titulo is not None:
        contenido_final_cuadro.append(titulo)

    if contenido_final_cuadro:
        min_y0_contenido = min(r.y0 for r in contenido_final_cuadro)
        max_y1_contenido = max(r.y1 for r in contenido_final_cuadro)
        if rect_cuadro.y1 > 700.0:
            y1_final = rect_cuadro.y1
            y0_final = max(rect_cuadro.y0, min_y0_contenido - 6.0)
        else:
            y0_final = min(rect_cuadro.y0 + desplazamiento_recuadro, min_y0_contenido - 6.0)
            y1_final = max_y1_contenido + 8.0
        rect_cuadro_desplazado = fitz.Rect(
            rect_cuadro.x0,
            y0_final,
            rect_cuadro.x1,
            y1_final,
        )
    else:
        rect_cuadro_desplazado = fitz.Rect(
            rect_cuadro.x0,
            y0_desplazado,
            rect_cuadro.x1,
            y0_desplazado + rect_cuadro.height,
        )
    return rect_cuadro_desplazado
