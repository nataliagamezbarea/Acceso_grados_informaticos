from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_rect import (
    desplazar_rect,
)


def asignar_bbox_final(elementos_flujo, fn_desplazamiento_final):
    """Fija el rect FINAL de cada elemento del flujo (original desplazado con
    la función definitiva que ya incluye la compactación)."""
    for item in elementos_flujo:
        item["bbox_final"] = desplazar_rect(
            item["original"], fn_desplazamiento_final(item["original"].y0)
        )
    return elementos_flujo
