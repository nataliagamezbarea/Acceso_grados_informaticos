import pymupdf as fitz


def recuadro_titulo_proyectado(span_objetivo, rect_cuadro,
                               fn_desplazamiento_final, numero_lineas_nuevas,
                               alto_linea_titulo):
    """Si el título sustituido vive dentro del recuadro, proyecta su bbox
    FINAL (con las líneas nuevas que ocupe) para el margen interior."""
    if span_objetivo is None:
        return None
    bb = span_objetivo["bbox"]
    titulo_dentro = (
        bb.x0 >= rect_cuadro.x0 - 1.0 and bb.x1 <= rect_cuadro.x1 + 1.0
        and bb.y0 >= rect_cuadro.y0 - 1.0 and bb.y1 <= rect_cuadro.y1 + 1.0
    )
    if not titulo_dentro:
        return None
    titulo_shift_final = fn_desplazamiento_final(bb.y0)
    titulo_y0_final = bb.y0 + titulo_shift_final
    titulo_y1_final = titulo_y0_final + max(
        bb.height, numero_lineas_nuevas * alto_linea_titulo
    )
    return fitz.Rect(bb.x0, titulo_y0_final, bb.x1, titulo_y1_final)
