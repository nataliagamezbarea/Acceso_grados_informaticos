def seleccionar_span_objetivo(spans_encontrados, texto_sustituir, ref_y=None):
    """Elige el span que contiene el texto a sustituir. Como sabe el visor qué
    enunciado quiere sustituir: si hay posición de referencia (selección del
    usuario) nos quedamos con el candidato más cercano a ella."""
    span_objetivo = None
    mejores_y = None
    for item in spans_encontrados:
        if texto_sustituir.upper() not in item["texto_limpio"].upper():
            continue
        bbox = item["bbox"]
        if ref_y is not None:
            dist = abs(bbox.y0 - ref_y)
            if mejores_y is None or dist < mejores_y:
                mejores_y = dist
                span_objetivo = item
        else:
            if span_objetivo is None or bbox.y0 < span_objetivo["bbox"].y0:
                span_objetivo = item
    return span_objetivo
