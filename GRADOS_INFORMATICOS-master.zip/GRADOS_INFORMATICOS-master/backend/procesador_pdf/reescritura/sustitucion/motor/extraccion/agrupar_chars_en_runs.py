from backend.procesador_pdf.reescritura.sustitucion.geometria.valor_seguro import (
    valor_seguro,
)


def agrupar_chars_en_runs(chars_normalizados, fuente_def, size_def,
                          color_def, flags_def, alpha_def):
    """Agrupa caracteres restantes en RUNS de estilo idéntico: si una parte
    estaba en negrita y otra no, cada tramo conserva su estilo."""
    runs = []
    for ch in chars_normalizados:
        estilo_ch = ch["style"]
        clave_estilo = (
            estilo_ch.get("font", fuente_def),
            round(valor_seguro(estilo_ch.get("size"), size_def), 3),
            estilo_ch.get("color", color_def),
            estilo_ch.get("flags", flags_def),
            estilo_ch.get("alpha", alpha_def),
        )
        if runs and runs[-1]["clave"] == clave_estilo:
            runs[-1]["texto"] += ch["c"]
        else:
            runs.append({
                "clave": clave_estilo,
                "texto": ch["c"],
                "font": clave_estilo[0],
                "size": clave_estilo[1],
                "color": clave_estilo[2],
                "flags": clave_estilo[3],
                "alpha": clave_estilo[4],
            })
    for run in runs:
        del run["clave"]
    return runs
