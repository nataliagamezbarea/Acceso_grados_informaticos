import re


def _normalizar(texto):
    """Colapsa espacios/saltos y pasa a mayúsculas para comparar sin
    depender de cómo el PDF haya partido el texto en spans."""
    return re.sub(r"\s+", " ", texto or "").strip().upper()


def _alnum(texto):
    return re.sub(r"[^A-Z0-9]", "", (texto or "").upper())

def seleccionar_span_objetivo_multilinea(spans_encontrados, texto_sustituir, ref_y=None):
    objetivo_norm = _normalizar(texto_sustituir)
    obj_alnum = _alnum(texto_sustituir)
    if not objetivo_norm and not obj_alnum:
        return None

    n = len(spans_encontrados)
    candidatos = []

    for i in range(n):
        primer_span = spans_encontrados[i]
        primer_t = _alnum(primer_span["texto_limpio"])
        if not primer_t or (primer_t not in obj_alnum and not obj_alnum.startswith(primer_t)):
            continue
        acumulado = ""
        acum_alnum = ""
        grupo = []
        for j in range(i, n):
            span = spans_encontrados[j]
            texto_span = _normalizar(span["texto_limpio"])
            t_alnum = _alnum(span["texto_limpio"])
            if not texto_span:
                continue
            acumulado = (acumulado + " " + texto_span).strip()
            acum_alnum += t_alnum
            grupo.append(span)

            if objetivo_norm in acumulado or obj_alnum == acum_alnum or (obj_alnum in acum_alnum and len(acum_alnum) <= len(obj_alnum) + 10):
                candidatos.append((grupo[0]["bbox"].y0, list(grupo)))
                break

            if len(acum_alnum) > len(obj_alnum) + 20:
                break

    if not candidatos:
        return None

    if ref_y is not None:
        candidatos.sort(key=lambda c: abs(c[1][0]["bbox"].y0 - ref_y))
    else:
        candidatos.sort(key=lambda c: c[0])

    return candidatos[0][1]
