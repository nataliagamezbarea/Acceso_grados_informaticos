import re
import pymupdf as fitz


def _norm(s):
    return re.sub(r"\s+", " ", s or "").strip().casefold()


def _chars_de_span(pagina, span_objetivo):
    """Encuentra los caracteres rawdict que pertenecen al span seleccionado.
    Se identifica por texto, bbox, fuente y tamaño para no depender de un ID
    interno del PDF.
    """
    texto_obj = span_objetivo.get("texto", "")
    fuente_obj = span_objetivo.get("font", "")
    size_obj = float(span_objetivo.get("size", 0) or 0)
    bbox_obj = fitz.Rect(span_objetivo["bbox"])
    mejor = None
    mejor_puntuacion = None

    try:
        bloques = pagina.get_text("rawdict").get("blocks", [])
    except Exception:
        return None

    for bloque in bloques:
        for linea in bloque.get("lines", []):
            for span in linea.get("spans", []):
                chars = span.get("chars", [])
                if not chars:
                    continue
                texto = "".join(ch.get("c", "") for ch in chars)
                bbox = span.get("bbox")
                if not bbox:
                    continue
                try:
                    r = fitz.Rect(bbox)
                except Exception:
                    continue
                score = abs(r.x0 - bbox_obj.x0) + abs(r.y0 - bbox_obj.y0) + abs(r.x1 - bbox_obj.x1) + abs(r.y1 - bbox_obj.y1)
                if span.get("font", "") == fuente_obj:
                    score -= 20.0
                try:
                    score += abs(float(span.get("size", 0) or 0) - size_obj) * 2.0
                except Exception:
                    pass
                if _norm(texto) == _norm(texto_obj):
                    score -= 100.0
                elif _norm(texto_obj) in _norm(texto):
                    score -= 50.0
                if mejor_puntuacion is None or score < mejor_puntuacion:
                    mejor_puntuacion = score
                    mejor = (span, chars)
    return mejor


def ajustar_span_objetivo_a_subcadena(pagina, span_objetivo, texto_sustituir):
    """Si el texto seleccionado es solo una PARTE de un span PDF, reduce el
    bbox del objetivo a esa subcadena. Así, al sustituir 'PRÁCTICA' dentro de
    'PRÁCTICA 1', el '1' que no fue seleccionado queda intacto.

    Si el objetivo ocupa el span completo, no cambia nada.
    """
    if not pagina or not span_objetivo or not texto_sustituir:
        return span_objetivo

    objetivo = str(texto_sustituir)
    encontrado = _chars_de_span(pagina, span_objetivo)
    if not encontrado:
        return span_objetivo
    raw_span, chars = encontrado

    texto_span = "".join(ch.get("c", "") for ch in chars)
    # Caso habitual: coincidencia exacta del texto completo.
    if _norm(texto_span) == _norm(objetivo):
        return span_objetivo

    # Buscar la subcadena de forma case-insensitive, conservando posiciones
    # reales de caracteres. Se evita normalizar eliminando caracteres porque
    # eso rompería el mapeo de índices.
    low_span = texto_span.casefold()
    low_obj = objetivo.casefold()
    pos = low_span.find(low_obj)

    if pos < 0:
        # Segundo intento: espacios equivalentes.
        compact_span = re.sub(r"\s+", " ", texto_span).strip().casefold()
        compact_obj = re.sub(r"\s+", " ", objetivo).strip().casefold()
        pos_compact = compact_span.find(compact_obj)
        if pos_compact < 0:
            return span_objetivo
        # Para esta ruta solo usamos coincidencias de longitud equivalente;
        # si hay espacios múltiples, es más seguro no tocar el bbox completo.
        return span_objetivo

    fin = pos + len(objetivo)
    if pos >= len(chars) or fin > len(chars):
        return span_objetivo

    chars_obj = chars[pos:fin]
    if not chars_obj:
        return span_objetivo

    rect = None
    for ch in chars_obj:
        try:
            r = fitz.Rect(ch["bbox"])
        except Exception:
            continue
        rect = fitz.Rect(r) if rect is None else (rect.include_rect(r) or rect)

    if rect is None or rect.is_empty:
        return span_objetivo

    # No ampliar artificialmente hasta el resto del span: el objetivo debe
    # cubrir exclusivamente los caracteres seleccionados.
    nuevo = dict(span_objetivo)
    nuevo["bbox"] = rect

    # La posición de escritura debe arrancar exactamente donde comienza la
    # subcadena seleccionada, no donde empieza todo el span.
    try:
        nuevo["origin"] = (rect.x0, span_objetivo["origin"][1])
    except Exception:
        nuevo["origin"] = (rect.x0, rect.y1)
    nuevo["_subcadena_ajustada"] = True
    nuevo["_span_texto_original"] = texto_span
    return nuevo
