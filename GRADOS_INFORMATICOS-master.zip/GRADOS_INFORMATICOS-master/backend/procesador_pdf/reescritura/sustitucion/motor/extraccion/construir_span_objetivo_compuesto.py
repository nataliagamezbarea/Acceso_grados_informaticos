import pymupdf as fitz


def construir_span_objetivo_compuesto(grupo_spans):
    """Fusiona una secuencia de spans (que juntos forman el texto a
    sustituir) en un único span "sintético" compatible con el resto del
    motor, que solo sabe trabajar con UN span:

    - bbox: caja que envuelve TODOS los spans del grupo (para saber si el
      objetivo cae dentro de un recuadro, para el recuadro de fechas, etc).
    - font/flags/size/color/alpha/origin: se toman del PRIMER span del
      grupo, igual que python/sustituir.py asume que un título tiene un
      único estilo (el texto nuevo se escribe con ese estilo, desde la
      posición del primer span).

    No modifica los spans originales: el resto del motor sigue teniendo
    acceso a ellos vía spans_objetivo_originales para poder borrar CADA
    span real (no solo la caja fusionada) y para excluirlos correctamente
    de "qué otro contenido sigue existiendo".
    """
    primero = grupo_spans[0]
    bbox = fitz.Rect(primero["bbox"])
    for span in grupo_spans[1:]:
        bbox.include_rect(span["bbox"])

    compuesto = dict(primero)
    compuesto["bbox"] = bbox
    return compuesto
