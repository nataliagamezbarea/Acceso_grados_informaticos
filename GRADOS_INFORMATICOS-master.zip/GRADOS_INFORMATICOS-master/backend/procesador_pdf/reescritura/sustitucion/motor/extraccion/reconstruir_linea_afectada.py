from backend.procesador_pdf.reescritura.sustitucion.geometria.interseca import interseca
from .agrupar_chars_en_runs import agrupar_chars_en_runs
from .normalizar_chars import normalizar_chars


def reconstruir_linea_afectada(linea, rects_linea):
    """Una línea tocada por los textos a borrar se REDACTA entera y se
    REESCRIBE solo con los caracteres que sobreviven (runs por estilo).
    Devuelve ('vacia', linea) si no queda texto o ('ok', entrada)."""
    chars_restantes = [
        ch for ch in linea["chars"]
        if not any(interseca(ch["bbox"], r) for r in rects_linea)
    ]
    chars_normalizados = normalizar_chars(chars_restantes)
    while chars_normalizados and chars_normalizados[0]["c"] in " ,-–.:;•·\t":
        chars_normalizados.pop(0)
    texto_restante = "".join(ch["c"] for ch in chars_normalizados).strip()
    if not texto_restante:
        return "vacia", linea
    runs = agrupar_chars_en_runs(
        chars_normalizados,
        linea["font"], linea["size"], linea["color"],
        linea["flags"], linea["alpha"],
    )
    return "ok", {
        "bbox": linea["bbox"],
        "origin": linea["origin"],
        "font": linea["font"],
        "size": linea["size"],
        "color": linea["color"],
        "flags": linea["flags"],
        "alpha": linea["alpha"],
        "texto": texto_restante,
        "runs": runs,
        "altura": max(linea["bbox"].height, linea["size"] * 1.25),
    }
