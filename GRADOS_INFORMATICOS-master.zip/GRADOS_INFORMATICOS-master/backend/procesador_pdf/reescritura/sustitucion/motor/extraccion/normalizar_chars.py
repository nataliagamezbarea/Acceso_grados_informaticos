def normalizar_chars(chars_restantes):
    """Normaliza espacios SIN perder el estilo por carácter: sin espacios
    iniciales, sin espacios dobles y sin espacio final."""
    chars_normalizados = []
    for ch in chars_restantes:
        es_espacio = ch["c"].isspace()
        if es_espacio:
            if not chars_normalizados:
                continue
            if chars_normalizados[-1]["c"].isspace():
                continue
        chars_normalizados.append(ch)
    while chars_normalizados and chars_normalizados[-1]["c"].isspace():
        chars_normalizados.pop()
    return chars_normalizados
