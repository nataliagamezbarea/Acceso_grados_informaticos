from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.valor_seguro import (
    valor_seguro,
)


def extraer_spans(pagina):
    """Extrae todos los spans de texto de la página como diccionarios con su
    geometría y estilo (sin modificar el PDF)."""
    spans_encontrados = []
    for bloque in pagina.get_text("dict").get("blocks", []):
        if "lines" not in bloque:
            continue
        for linea in bloque.get("lines", []):
            for span in linea.get("spans", []):
                texto_original = span.get("text", "")
                texto = texto_original.strip()
                if not texto:
                    continue
                bbox = rect_seguro(span.get("bbox"))
                if bbox is None:
                    continue
                origen = span.get("origin")
                if origen is None:
                    origen = (bbox.x0, bbox.y1)
                spans_encontrados.append({
                    "texto": texto_original,
                    "texto_limpio": texto,
                    "bbox": bbox,
                    "origin": origen,
                    "font": span.get("font", "helv"),
                    "size": valor_seguro(span.get("size"), 11.0),
                    "color": span.get("color", 0),
                    "flags": span.get("flags", 0),
                    "alpha": span.get("alpha", 255),
                })
    return spans_encontrados
