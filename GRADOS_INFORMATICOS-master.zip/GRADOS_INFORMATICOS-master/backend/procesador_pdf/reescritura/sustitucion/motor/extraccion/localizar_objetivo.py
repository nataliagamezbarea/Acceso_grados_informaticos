from .seleccionar_span_objetivo import seleccionar_span_objetivo
from .seleccionar_span_objetivo_multilinea import seleccionar_span_objetivo_multilinea
from .construir_span_objetivo_compuesto import construir_span_objetivo_compuesto
from .ajustar_span_objetivo_a_subcadena import ajustar_span_objetivo_a_subcadena

def localizar_objetivo(spans_encontrados, texto_sustituir, ref_y, pagina=None):
    """Localiza span objetivo simple o compuesto multilínea."""
    span_unico = seleccionar_span_objetivo(spans_encontrados, texto_sustituir, ref_y)
    if span_unico is not None:
        if pagina is not None:
            ajustado = ajustar_span_objetivo_a_subcadena(pagina, span_unico, texto_sustituir)
            if ajustado is not span_unico:
                # Solo este span es el objetivo real. No mutamos el objeto
                # original de extraer_spans: así el resto del PDF conserva
                # sus coordenadas y estilos intactos.
                return ajustado, [ajustado]
        return span_unico, [span_unico]
    grupo = seleccionar_span_objetivo_multilinea(spans_encontrados, texto_sustituir, ref_y)
    if grupo is not None:
        return construir_span_objetivo_compuesto(grupo), grupo
    return None, None
