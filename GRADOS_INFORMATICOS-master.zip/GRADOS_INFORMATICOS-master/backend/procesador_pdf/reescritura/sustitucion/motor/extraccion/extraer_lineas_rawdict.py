import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.geometria.rect_seguro import (
    rect_seguro,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.valor_seguro import (
    valor_seguro,
)


def extraer_lineas_rawdict(pagina):
    """Líneas con sus CARACTERES individuales y estilo por carácter
    (get_text('rawdict')); base para reconstruir líneas parcialmente borradas."""
    lineas_originales = []
    raw_original = pagina.get_text("rawdict")
    for bloque in raw_original.get("blocks", []):
        if "lines" not in bloque:
            continue
        for linea_raw in bloque.get("lines", []):
            chars_linea = []
            for span_raw in linea_raw.get("spans", []):
                estilo = {
                    "font": span_raw.get("font", "helv"),
                    "size": valor_seguro(span_raw.get("size"), 11.0),
                    "color": span_raw.get("color", 0),
                    "flags": span_raw.get("flags", 0),
                    "alpha": span_raw.get("alpha", 255),
                    "origin": span_raw.get("origin"),
                }
                for ch in span_raw.get("chars", []):
                    cch = ch.get("c", "")
                    r = rect_seguro(ch.get("bbox"))
                    if not cch or r is None:
                        continue
                    chars_linea.append({"c": cch, "bbox": r, "style": estilo})
            if not chars_linea:
                continue
            bbox_linea = fitz.Rect(chars_linea[0]["bbox"])
            for ch in chars_linea[1:]:
                bbox_linea.include_rect(ch["bbox"])
            estilo_base = chars_linea[0]["style"]
            origen_base = estilo_base.get("origin")
            if origen_base is None:
                origen_base = (bbox_linea.x0, bbox_linea.y1)
            lineas_originales.append({
                "chars": chars_linea,
                "bbox": bbox_linea,
                "font": estilo_base["font"],
                "size": estilo_base["size"],
                "color": estilo_base["color"],
                "flags": estilo_base["flags"],
                "alpha": estilo_base["alpha"],
                "origin": origen_base,
                "texto": "".join(ch["c"] for ch in chars_linea),
            })
    return lineas_originales
