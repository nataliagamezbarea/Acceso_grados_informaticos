def detectar_ratios_trazo(pagina):
    """Mapa {(fuente, size redondeado): border_width} con el trazo relativo
    usado por cada combinación fuente+tamaño del original (modo relleno+trazo
    "2 Tr"). get_text("dict") no expone esto; get_texttrace() sí."""
    ratios = {}
    try:
        for entrada in pagina.get_texttrace():
            fuente = entrada.get("font")
            size = entrada.get("size")
            linewidth = entrada.get("linewidth")
            if not fuente or not size:
                continue
            if not linewidth:
                continue
            clave = (fuente, round(size, 1))
            if clave not in ratios:
                ratios[clave] = linewidth / size
    except Exception:
        return {}
    return ratios
