def obtener_ratio_trazo(ratios, nombre_fuente, size):
    try:
        clave = (nombre_fuente, round(float(size), 1))
    except Exception:
        return None
    return ratios.get(clave)
