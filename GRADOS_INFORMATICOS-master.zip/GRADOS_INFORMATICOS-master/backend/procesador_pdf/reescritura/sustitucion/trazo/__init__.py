from backend.procesador_pdf.reescritura.sustitucion.trazo.detectar_ratios_trazo import (
    detectar_ratios_trazo,
)
from backend.procesador_pdf.reescritura.sustitucion.trazo.obtener_ratio_trazo import (
    obtener_ratio_trazo,
)

__all__ = ["detectar_ratios_trazo", "obtener_ratio_trazo"]
