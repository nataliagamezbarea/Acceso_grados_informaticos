import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.geometria.valor_seguro import (
    valor_seguro,
)
from backend.procesador_pdf.reescritura.sustitucion.vectores.opacidades_vector import (
    opacidades_vector,
)
from backend.procesador_pdf.reescritura.sustitucion.vectores.reconstruir_simple import (
    reconstruir_vector_simple,
)
from backend.procesador_pdf.reescritura.sustitucion.vectores.trazar_items import (
    trazar_items,
)


def dibujar_vector_desplazado(pagina_destino, dibujo, dy):
    """Reconstruye EXACTAMENTE los comandos vectoriales de get_drawings()
    (líneas, Bézier, rects, quads) desplazados dy, conservando color, fill,
    grosor, dashes, transparencias, lineCap/lineJoin y closePath."""
    try:
        shape = pagina_destino.new_shape()
    except Exception:
        return

    if not trazar_items(shape, dibujo, dy):
        return

    color = dibujo.get("color")
    fill = dibujo.get("fill")
    dashes = dibujo.get("dashes")
    even_odd = dibujo.get("even_odd", False)
    close_path = dibujo.get("closePath", False)

    line_join = dibujo.get("lineJoin", 0)
    if line_join is None:
        line_join = 0
    line_cap = dibujo.get("lineCap", 0)
    if line_cap is None:
        line_cap = 0
    if isinstance(line_cap, (tuple, list)):
        line_cap = max(line_cap) if line_cap else 0

    width = valor_seguro(dibujo.get("width"), 1.0)
    stroke_opacity, fill_opacity = opacidades_vector(dibujo)

    try:
        shape.finish(
            fill=fill,
            color=color,
            dashes=dashes,
            even_odd=bool(even_odd),
            closePath=bool(close_path),
            lineJoin=int(line_join),
            lineCap=int(line_cap),
            width=width,
            stroke_opacity=stroke_opacity,
            fill_opacity=fill_opacity,
        )
        shape.commit(overlay=True)
    except Exception:
        reconstruir_vector_simple(
            pagina_destino, dibujo, dy, fill, color, width,
            line_join, line_cap, close_path)
