from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_punto import (
    desplazar_punto,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_rect import (
    desplazar_rect,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_quad import (
    desplazar_quad,
)


def trazar_items(shape, dibujo, dy):
    """Vuelca en el shape los comandos del dibujo desplazados dy
    (líneas, Bézier, rects, quads). Devuelve True si trazó algo."""
    hubo_comandos = False
    for item in dibujo.get("items", []):
        if not item:
            continue
        tipo = item[0]
        try:
            if tipo == "l":
                shape.draw_line(desplazar_punto(item[1], dy), desplazar_punto(item[2], dy))
                hubo_comandos = True
            elif tipo == "c":
                shape.draw_bezier(
                    desplazar_punto(item[1], dy),
                    desplazar_punto(item[2], dy),
                    desplazar_punto(item[3], dy),
                    desplazar_punto(item[4], dy),
                )
                hubo_comandos = True
            elif tipo == "re":
                shape.draw_rect(desplazar_rect(item[1], dy))
                hubo_comandos = True
            elif tipo == "qu":
                shape.draw_quad(desplazar_quad(item[1], dy))
                hubo_comandos = True
        except Exception:
            continue
    return hubo_comandos
