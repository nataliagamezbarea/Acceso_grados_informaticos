import pymupdf as fitz

from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_punto import (
    desplazar_punto,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_rect import (
    desplazar_rect,
)
from backend.procesador_pdf.reescritura.sustitucion.geometria.desplazar_quad import (
    desplazar_quad,
)


def reconstruir_vector_simple(pagina_destino, dibujo, dy, fill, color,
                              width, line_join, line_cap, close_path):
    """Respaldo si un dibujo muy raro no acepta transparencias/dashes:
    se reconstruye SIN esas propiedades secundarias (nunca desaparecer)."""
    try:
        shape = pagina_destino.new_shape()
        for item in dibujo.get("items", []):
            tipo = item[0]
            if tipo == "l":
                shape.draw_line(desplazar_punto(item[1], dy), desplazar_punto(item[2], dy))
            elif tipo == "c":
                shape.draw_bezier(
                    desplazar_punto(item[1], dy),
                    desplazar_punto(item[2], dy),
                    desplazar_punto(item[3], dy),
                    desplazar_punto(item[4], dy),
                )
            elif tipo == "re":
                shape.draw_rect(desplazar_rect(item[1], dy))
            elif tipo == "qu":
                shape.draw_quad(desplazar_quad(item[1], dy))
        shape.finish(
            fill=fill,
            color=color,
            width=width,
            lineJoin=int(line_join),
            lineCap=int(line_cap),
            closePath=bool(close_path),
            stroke_opacity=1.0,
            fill_opacity=1.0,
        )
        shape.commit(overlay=True)
    except Exception:
        pass
