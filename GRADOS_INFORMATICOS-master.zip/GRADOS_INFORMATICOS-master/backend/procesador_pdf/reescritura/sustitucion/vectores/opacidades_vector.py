from backend.procesador_pdf.reescritura.sustitucion.geometria.valor_seguro import (
    valor_seguro,
)


def opacidades_vector(dibujo):
    """Opacidades de trazo/relleno del dibujo original con respaldos:
    stroke_opacity/fill_opacity -> opacity antigua -> 1.0, siempre en [0,1]."""
    stroke_opacity = dibujo.get("stroke_opacity")
    fill_opacity = dibujo.get("fill_opacity")
    opacity_antigua = dibujo.get("opacity")
    if stroke_opacity is None:
        stroke_opacity = opacity_antigua
    if fill_opacity is None:
        fill_opacity = opacity_antigua
    if stroke_opacity is None:
        stroke_opacity = 1.0
    if fill_opacity is None:
        fill_opacity = 1.0
    stroke_opacity = max(0.0, min(1.0, valor_seguro(stroke_opacity, 1.0)))
    fill_opacity = max(0.0, min(1.0, valor_seguro(fill_opacity, 1.0)))
    return stroke_opacity, fill_opacity
