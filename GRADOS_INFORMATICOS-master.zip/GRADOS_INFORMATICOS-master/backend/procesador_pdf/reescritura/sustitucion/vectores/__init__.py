from backend.procesador_pdf.reescritura.sustitucion.vectores.dibujar_vector_desplazado import (
    dibujar_vector_desplazado,
)

__all__ = ["dibujar_vector_desplazado"]
