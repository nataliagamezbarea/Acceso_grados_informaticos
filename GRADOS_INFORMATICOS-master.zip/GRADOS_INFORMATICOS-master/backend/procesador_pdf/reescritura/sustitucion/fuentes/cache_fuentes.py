"""CACHE compartida de fuentes ya instaladas por (página, archivo TTF).

vive aquí para que todos los submódulos de escritura compartan el MISMO
registro (una sola insert_font por página+archivo)."""

fuentes_registradas = {}
contador_fuentes = [0]
