import sys
import os

from backend.procesador_pdf.reescritura.sustitucion.fuentes.obtener_objeto_fuente import (
    obtener_objeto_fuente
)
from backend.procesador_pdf.reescritura.sustitucion.trazo.obtener_ratio_trazo import (
    obtener_ratio_trazo
)
from backend.procesador_pdf.reescritura.tipografia._fuente_cubre_todo import (
    _fuente_cubre_todo
)


def escribir_span_con_fuente(
    pagina_destino,
    texto,
    origen_xy,
    nombre_fuente,
    flags,
    size,
    color_int,
    alpha=255,
    ratios_trazo=None
):
    """
    Escribe un span conservando automáticamente la tipografía original.

    - Usa el nombre de fuente y los flags reales del span.
    - Intenta reutilizar la fuente localizada correspondiente.
    - Si existe un archivo de fuente válido, lo incrusta directamente.
    - Conserva el tamaño original.
    - Conserva color y transparencia.
    - NO utiliza char_flags para decidir el grosor.
    - Solo usa Helvetica como último recurso si no existe una fuente válida.
    """

    if not texto:
        return

    # ---------------------------------------------------------
    # COLOR
    # ---------------------------------------------------------
    c = color_int or 0

    color_rgb = (
        ((c >> 16) & 255) / 255.0,
        ((c >> 8) & 255) / 255.0,
        (c & 255) / 255.0,
    )

    # ---------------------------------------------------------
    # ALPHA
    # ---------------------------------------------------------
    try:
        alpha_float = max(
            0.0,
            min(1.0, float(alpha) / 255.0)
        )
    except Exception:
        alpha_float = 1.0

    if alpha_float <= 0.0:
        alpha_float = 1.0

    # ---------------------------------------------------------
    # IMPORTANTE:
    # La fuente se obtiene usando SOLO:
    #
    #   nombre_fuente
    #   flags
    #
    # Los flags deben ser los del span original.
    # No usamos char_flags para decidir Bold/Light.
    # ---------------------------------------------------------
    try:
        f_obj, ruta_fuente = obtener_objeto_fuente(
            nombre_fuente,
            flags
        )
    except Exception as e:
        f_obj = None
        ruta_fuente = None
        print(
            f"[escribir_span_con_fuente] "
            f"error obteniendo fuente "
            f"font={nombre_fuente!r} flags={flags!r}: {e!r}",
            file=sys.stderr
        )

    # ---------------------------------------------------------
    # TRAZO
    # ---------------------------------------------------------
    try:
        ratio_trazo = obtener_ratio_trazo(
            ratios_trazo or {},
            nombre_fuente,
            size
        )
    except Exception:
        ratio_trazo = None

    kwargs_trazo = {}

    if ratio_trazo:
        kwargs_trazo = {
            "render_mode": 2,
            "border_width": ratio_trazo,
            "fill": color_rgb,
            "stroke_opacity": alpha_float,
        }

    # ---------------------------------------------------------
    # 1. PRIORIDAD ABSOLUTA:
    #    FUENTE LOCALIZADA / ARCHIVO TTF
    #
    # Si la fuente corresponde al span original y contiene
    # todos los caracteres del texto, se utiliza directamente.
    # ---------------------------------------------------------
    if (
        ruta_fuente
        and os.path.exists(ruta_fuente)
    ):
        try:
            cubre_todo = _fuente_cubre_todo(
                ruta_fuente,
                [texto]
            )
        except Exception:
            cubre_todo = False

        if cubre_todo:
            nombre_recurso_unico = (
                "f_"
                + os.path.splitext(
                    os.path.basename(ruta_fuente)
                )[0]
                .replace("-", "_")
                .replace(" ", "_")
            )

            try:
                pagina_destino.insert_text(
                    origen_xy,
                    texto,
                    fontsize=size,
                    fontfile=ruta_fuente,
                    fontname=nombre_recurso_unico,
                    color=color_rgb,
                    fill_opacity=alpha_float,
                    overlay=True,
                    **kwargs_trazo,
                )

                return

            except Exception as e:
                print(
                    f"[escribir_span_con_fuente] "
                    f"falló insertando con fuente original "
                    f"{ruta_fuente!r}: {e!r}",
                    file=sys.stderr
                )

    # ---------------------------------------------------------
    # 2. Si no se pudo insertar con fontfile, NO pasamos el objeto
    #    fitz.Font a fontname: PyMuPDF espera un nombre de recurso (str).
    #    Pasar un objeto Font aquí puede provocar errores de MuPDF.
    #
    #    Solo usamos nombres Base-14 conocidos como recurso directo.
    # ---------------------------------------------------------
    nombre_base14 = str(nombre_fuente or "").strip().lower()
    base14 = {
        "helv", "helvetica", "courier", "times-roman", "timesroman",
        "times-bold", "times-italic", "times-bolditalic",
        "symbol", "zapfdingbats"
    }

    if nombre_base14 in base14:
        try:
            pagina_destino.insert_text(
                origen_xy,
                texto,
                fontsize=size,
                fontname=nombre_base14,
                color=color_rgb,
                fill_opacity=alpha_float,
                overlay=True,
                **kwargs_trazo,
            )
            return
        except Exception as e:
            print(
                f"[escribir_span_con_fuente] fallo con recurso base-14 "
                f"{nombre_base14!r}: {e!r}",
                file=sys.stderr
            )

    # ---------------------------------------------------------
    # 3. ÚLTIMO RECURSO:
    #    HELVETICA
    #
    # Solo se utiliza si NO se ha podido localizar/utilizar
    # la fuente original.
    # ---------------------------------------------------------
    try:
        pagina_destino.insert_text(
            origen_xy,
            texto,
            fontsize=size,
            fontname="helv",
            color=color_rgb,
            fill_opacity=alpha_float,
            overlay=True,
        )

    except Exception as e:
        print(
            f"[escribir_span_con_fuente] "
            f"fallo TAMBIÉN con 'helv' "
            f"texto={texto[:40]!r}: {e!r}",
            file=sys.stderr
        )
