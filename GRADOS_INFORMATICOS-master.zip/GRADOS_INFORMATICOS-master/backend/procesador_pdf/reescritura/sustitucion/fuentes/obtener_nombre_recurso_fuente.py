import os

from backend.procesador_pdf.reescritura.sustitucion.fuentes.cache_fuentes import (
    fuentes_registradas,
    contador_fuentes,
)
from backend.procesador_pdf.reescritura.sustitucion.fuentes.obtener_objeto_fuente import (
    obtener_objeto_fuente,
)


def obtener_nombre_recurso_fuente(pagina_destino, nombre_fuente, flags=0):
    """Instala (una sola vez por página+archivo) la fuente real en la página y
    devuelve el nombre de recurso a usar en insert_text."""
    f_obj, ruta = obtener_objeto_fuente(nombre_fuente, flags)
    if not ruta or not os.path.exists(ruta):
        return "helv", f_obj
    doc_id = id(getattr(pagina_destino, "parent", None))
    clave = (doc_id, pagina_destino.number, os.path.abspath(ruta))
    if clave in fuentes_registradas:
        return fuentes_registradas[clave], f_obj
    contador_fuentes[0] += 1
    nombre_recurso = f"font_custom_{contador_fuentes[0]}"
    try:
        pagina_destino.insert_font(fontname=nombre_recurso, fontfile=ruta)
        fuentes_registradas[clave] = nombre_recurso
        return nombre_recurso, f_obj
    except Exception:
        return "helv", f_obj
