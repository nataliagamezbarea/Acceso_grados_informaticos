from backend.procesador_pdf.reescritura.sustitucion.fuentes.escribir_span_con_fuente import (
    escribir_span_con_fuente,
)
from backend.procesador_pdf.reescritura.sustitucion.fuentes.obtener_nombre_recurso_fuente import (
    obtener_nombre_recurso_fuente,
)


def escribir_linea_con_runs(pagina_destino, runs, origen_xy, ratios_trazo=None):
    """Una línea reconstruida puede mezclar estilos (negrita + normal...).
    Cada tramo se escribe con su propio estilo avanzando el cursor horizontal
    según el ancho real del tramo."""
    x_cursor, y = origen_xy
    for run in runs:
        texto_run = run.get("texto", "")
        if not texto_run:
            continue
        escribir_span_con_fuente(
            pagina_destino, texto_run, (x_cursor, y),
            run["font"], run["flags"], run["size"],
            run["color"], run.get("alpha", 255),
            ratios_trazo=ratios_trazo,
        )
        _, f_run = obtener_nombre_recurso_fuente(
            pagina_destino, run["font"], run["flags"]
        )
        try:
            ancho_run = f_run.text_length(texto_run, fontsize=run["size"])
        except Exception:
            ancho_run = len(texto_run) * run["size"] * 0.5
        x_cursor += ancho_run
