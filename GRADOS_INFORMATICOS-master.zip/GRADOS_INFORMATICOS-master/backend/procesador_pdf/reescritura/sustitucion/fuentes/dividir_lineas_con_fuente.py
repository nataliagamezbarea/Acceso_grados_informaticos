def dividir_lineas_con_fuente(texto, f_obj, size, max_w):
    """Envuelve el texto a varias líneas dentro de max_w sin guiones artificiales."""
    palabras = texto.split(" ")
    lineas = []
    actual = ""
    for palabra in palabras:
        candidato = (actual + " " + palabra).strip() if actual else palabra
        try:
            ancho = f_obj.text_length(candidato, fontsize=size)
        except Exception:
            ancho = len(candidato) * size * 0.5
        if ancho <= max_w:
            actual = candidato
            continue
        if actual:
            lineas.append(actual)
        actual = palabra
        while len(actual) > 1:
            try:
                ancho_actual = f_obj.text_length(actual, fontsize=size)
            except Exception:
                ancho_actual = len(actual) * size * 0.5
            if ancho_actual <= max_w:
                break
            corte = len(actual) - 1
            while corte > 1:
                candidato_cortado = actual[:corte] + "-"
                try:
                    ancho_cortado = f_obj.text_length(candidato_cortado, fontsize=size)
                except Exception:
                    ancho_cortado = len(candidato_cortado) * size * 0.5
                if ancho_cortado <= max_w:
                    break
                corte -= 1
            if corte <= 1:
                break
            lineas.append(actual[:corte] + "-")
            actual = actual[corte:]
    if actual:
        lineas.append(actual)
    return lineas
