from backend.procesador_pdf.reescritura.sustitucion.fuentes.cache_fuentes import (
    fuentes_registradas,
    contador_fuentes,
)
from backend.procesador_pdf.reescritura.sustitucion.fuentes.obtener_objeto_fuente import (
    obtener_objeto_fuente,
)
from backend.procesador_pdf.reescritura.sustitucion.fuentes.obtener_nombre_recurso_fuente import (
    obtener_nombre_recurso_fuente,
)
from backend.procesador_pdf.reescritura.sustitucion.fuentes.escribir_span_con_fuente import (
    escribir_span_con_fuente,
)
from backend.procesador_pdf.reescritura.sustitucion.fuentes.escribir_linea_con_runs import (
    escribir_linea_con_runs,
)
from backend.procesador_pdf.reescritura.sustitucion.fuentes.dividir_lineas_con_fuente import (
    dividir_lineas_con_fuente,
)

__all__ = [
    "fuentes_registradas",
    "contador_fuentes",
    "obtener_objeto_fuente",
    "obtener_nombre_recurso_fuente",
    "escribir_span_con_fuente",
    "escribir_linea_con_runs",
    "dividir_lineas_con_fuente",
]
