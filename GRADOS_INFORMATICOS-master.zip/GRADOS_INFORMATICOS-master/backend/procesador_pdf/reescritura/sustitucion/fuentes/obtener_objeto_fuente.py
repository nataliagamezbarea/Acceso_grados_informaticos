import os
import re

import pymupdf as fitz

from backend.procesador_pdf.reescritura.tipografia import resolver_ruta_fuente_real


def _normalizar_nombre_fuente(valor):
    valor = str(valor or '').lower()
    return re.sub(r'[^a-z0-9]+', '', valor)


def _inferir_estilo_fuente(nombre_fuente, flags=0):
    """
    Detecta el estilo de la fuente.

    IMPORTANTE:
    El nombre de la fuente tiene prioridad absoluta.

    NO se interpreta char_flags.
    Tampoco se utiliza flags & 16 como Bold, porque eso
    provoca que fuentes Light/Regular terminen como Bold.
    """

    nombre_norm = _normalizar_nombre_fuente(nombre_fuente)

    patrones = (
        ('extrabolditalic', 'ExtraBoldItalic'),
        ('semibolditalic', 'SemiBoldItalic'),
        ('demibolditalic', 'DemiBoldItalic'),
        ('bolditalic', 'BoldItalic'),
        ('lightitalic', 'LightItalic'),
        ('mediumitalic', 'MediumItalic'),
        ('regularitalic', 'Italic'),
        ('extrabold', 'ExtraBold'),
        ('semibold', 'SemiBold'),
        ('demibold', 'DemiBold'),
        ('ultrabold', 'UltraBold'),
        ('bold', 'Bold'),
        ('italic', 'Italic'),
        ('oblique', 'Oblique'),
        ('ultralight', 'UltraLight'),
        ('extralight', 'ExtraLight'),
        ('medium', 'Medium'),
        ('light', 'Light'),
        ('regular', 'Regular'),
        ('book', 'Book'),
        ('thin', 'Thin'),
        ('black', 'Black'),
        ('heavy', 'Heavy'),
    )

    for patron, estilo in patrones:
        if patron in nombre_norm:
            return estilo

    # ---------------------------------------------------------
    # FALLBACK:
    # Solo utilizamos flags para detectar cursiva.
    #
    # NO usamos flags & 16 para decidir Bold.
    # ---------------------------------------------------------
    try:
        flags = int(flags or 0)
    except Exception:
        flags = 0

    # Bit de italic de PyMuPDF
    if flags & 2:
        return 'Italic'

    return 'Regular'


def _separar_familia_y_estilo(nombre_fuente, estilo=None, flags=0):
    """
    Separa familia y estilo evitando cosas como:

        Avenir Next LT Pro Light Light

    o:

        AvenirNextLTPro Bold Bold
    """

    familia = str(nombre_fuente or '').strip()
    estilo_final = str(estilo or '').strip()

    detectado = _inferir_estilo_fuente(
        familia,
        flags
    )

    if not estilo_final:
        estilo_final = detectado

    fam_norm = _normalizar_nombre_fuente(familia)

    sufijos = (
        'extrabolditalic',
        'semibolditalic',
        'demibolditalic',
        'bolditalic',
        'lightitalic',
        'mediumitalic',
        'regularitalic',
        'italic',
        'oblique',
        'extrabold',
        'semibold',
        'demibold',
        'ultrabold',
        'bold',
        'ultralight',
        'extralight',
        'medium',
        'light',
        'regular',
        'book',
        'thin',
        'black',
        'heavy',
    )

    for sufijo in sufijos:
        if fam_norm.endswith(sufijo):

            familia = re.sub(
                rf'(?i)[ _-]*{re.escape(sufijo)}[ _-]*$',
                '',
                familia
            ).strip(' _-')

            if (
                not estilo_final
                or
                _normalizar_nombre_fuente(estilo_final)
                ==
                _normalizar_nombre_fuente(detectado)
            ):
                estilo_final = detectado

            break

    return familia, (estilo_final or 'Regular')


def obtener_objeto_fuente(nombre_fuente, flags=0):
    """
    Obtiene la fuente REAL que se utilizará para medir/escribir.

    PRIORIDAD:

    1. Fuente localizada según nombre + estilo real.
    2. Fuente del entorno.
    3. Fuente descargada/localizada.
    4. Fuente instalada de PyMuPDF.
    5. Helvetica como último recurso.

    IMPORTANTE:
    - No convierte Light en Bold por char_flags.
    - No convierte una fuente en Bold usando flags & 16.
    """

    ruta = None

    # ---------------------------------------------------------
    # 1. Resolver fuente usando nombre + flags
    # ---------------------------------------------------------
    try:
        ruta, _ = resolver_ruta_fuente_real(
            nombre_fuente,
            flags
        )
    except Exception:
        ruta = None

    # ---------------------------------------------------------
    # 2. Si no aparece, separar familia/estilo y volver a buscar
    # ---------------------------------------------------------
    if not ruta or not os.path.exists(ruta):

        familia_real, estilo_real = _separar_familia_y_estilo(
            nombre_fuente,
            None,
            flags
        )

        # Primera búsqueda con familia real
        try:
            ruta, _ = resolver_ruta_fuente_real(
                familia_real,
                flags
            )
        except Exception:
            ruta = None

        # Segunda búsqueda: intentar explícitamente la familia
        # + estilo para evitar que Light termine como Bold.
        if not ruta or not os.path.exists(ruta):

            nombre_con_estilo = (
                f"{familia_real} {estilo_real}"
            ).strip()

            try:
                ruta, _ = resolver_ruta_fuente_real(
                    nombre_con_estilo,
                    flags
                )
            except Exception:
                ruta = None

    # ---------------------------------------------------------
    # 3. Utilizar archivo de fuente localizado
    # ---------------------------------------------------------
    if ruta and os.path.exists(ruta):

        try:
            fuente = fitz.Font(
                fontfile=ruta
            )

            return fuente, ruta

        except Exception:
            pass

    # ---------------------------------------------------------
    # 4. Intentar fuente instalada con el nombre original
    # ---------------------------------------------------------
    try:
        fuente = fitz.Font(
            fontname=nombre_fuente
        )

        return fuente, None

    except Exception:
        pass

    # ---------------------------------------------------------
    # 5. Intentar nombre normalizado/familia
    # ---------------------------------------------------------
    try:
        familia_real, _ = _separar_familia_y_estilo(
            nombre_fuente,
            None,
            flags
        )

        if familia_real:

            fuente = fitz.Font(
                fontname=familia_real
            )

            return fuente, None

    except Exception:
        pass

    # ---------------------------------------------------------
    # 6. ÚLTIMO RECURSO: Helvetica
    # ---------------------------------------------------------
    return fitz.Font("helv"), None
