"""PAQUETE SUSTITUCIÓN COMPLETA · motor de python/sustituir.py dividido por
funciones: geometría, trazo (falso negrita), fuentes, vectores y motor."""
from backend.procesador_pdf.reescritura.sustitucion.motor import (
    aplicar_sustitucion_completa,
)

__all__ = ["aplicar_sustitucion_completa"]
