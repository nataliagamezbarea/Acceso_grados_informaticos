"""CONSTANTES DE CONFIGURACIÓN del motor de sustitución completa
(valores idénticos a python/sustituir.py)."""

import pymupdf as fitz

# Margen real que dejamos debajo del recuadro cuando cabe completo.
MARGEN_INFERIOR = 12.0

# Margen mínimo visual entre el borde inferior del recuadro y el final de
# la página (comprobación informativa para cerrar el recuadro).
MARGEN_SEGURIDAD_RECUADRO = 30.0

# Márgenes de la página 2 cuando el contenido no cabe en la página 1.
MARGEN_SUPERIOR_NUEVA_PAGINA = 30.0
MARGEN_INFERIOR_NUEVA_PAGINA = 30.0

# Tolerancia para decidir si un objeto está debajo del título.
TOLERANCIA_Y = 1.0

# Margen interior mínimo entre contenido real y borde inferior del recuadro.
MARGEN_INTERIOR_RECUADRO = 10.0

# Aire mínimo que debe quedar entre bloques al compactar antes de paginar.
AIRE_MINIMO_ENTRE_BLOQUES = 4.0


PDF_REDACT_IMAGE_NONE = getattr(fitz, "PDF_REDACT_IMAGE_NONE", 0)
PDF_REDACT_IMAGE_REMOVE = getattr(fitz, "PDF_REDACT_IMAGE_REMOVE", 1)
PDF_REDACT_LINE_ART_NONE = getattr(fitz, "PDF_REDACT_LINE_ART_NONE", 0)
PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED = getattr(fitz, "PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED", 2)
PDF_REDACT_TEXT_REMOVE = getattr(fitz, "PDF_REDACT_TEXT_REMOVE", 0)
PDF_REDACT_TEXT_NONE = getattr(fitz, "PDF_REDACT_TEXT_NONE", 1)
