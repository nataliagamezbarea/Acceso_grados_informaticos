from backend.procesador_pdf.reescritura.enunciados._procesar_un_enunciado import _procesar_un_enunciado


def sustituir_enunciados_de_pagina(doc, pagina, pno, lineas, enunciados,
                                   enunciados_ya_hechos, paginas_nuevas_pendientes,
                                   resaltar_cambios=False, textos_eliminar=()):
    """Procesa los enunciados con el motor único de sustituir.py.

    ``textos_eliminar`` se entrega al primer enunciado que realmente se pueda
    procesar. De ese modo sustitución y eliminación ocurren en la MISMA pasada
    del motor, exactamente como en python/sustituir.py. Si no hay enunciado
    aplicable, el orquestador hace una pasada de eliminación independiente.
    """
    modificado = False
    hechos = (enunciados_ya_hechos if isinstance(enunciados_ya_hechos, set)
              else set(enunciados_ya_hechos))
    rects_ya_sustituidos = []
    pendientes_eliminar = tuple(textos_eliminar or ())

    for q in enunciados:
        hizo = _procesar_un_enunciado(
            doc, pagina, pno, q, lineas, hechos, rects_ya_sustituidos,
            paginas_nuevas_pendientes, textos_eliminar=pendientes_eliminar
        )
        if hizo:
            modificado = True
            # Nombres/colegio ya se procesaron dentro de esta misma llamada.
            pendientes_eliminar = ()

    return modificado
