import pymupdf as fitz

from backend.procesador_pdf.busqueda_rectangulos import buscar_rango_lineas_enunciado
from backend.procesador_pdf.reescritura.sustitucion import aplicar_sustitucion_completa


def _procesar_un_enunciado(doc, pagina, pno, q, lineas, hechos,
                           rects_ya_sustituidos, paginas_nuevas_pendientes,
                           textos_eliminar=()):
    """Procesa un enunciado usando el MISMO motor de sustituir.py.

    La diferencia con la versión anterior del visor es importante: las
    eliminaciones (nombres/colegio) se entregan al MISMO llamado que hace la
    sustitución del enunciado. Así el flujo es literalmente el de
    python/sustituir.py: una sustitución + todos los textos a eliminar en la
    misma pasada del motor.
    """
    start_txt = q.get("start", "")
    end_txt = q.get("end", "")
    new_txt = q.get("new", "")
    inc_enunc = q.get("include", True)
    q_page = q.get("page")
    if q_page is not None and q_page != pno:
        return False
    clave_q = (q.get("id"), start_txt, end_txt, new_txt, inc_enunc)
    if clave_q in hechos:
        return False

    ref_y = None
    if q.get("pct_top") is not None:
        try:
            ref_y = (float(q["pct_top"]) / 100.0) * pagina.rect.height
        except Exception:
            ref_y = None

    i_s, i_e = buscar_rango_lineas_enunciado(
        lineas, start_txt, end_txt, ref_y=ref_y
    )
    if i_s is None or i_s == -1:
        return False

    lx0 = lineas[i_s][0]
    ly0 = lineas[i_s][1]
    lx1 = lineas[i_e][2]
    ly1 = lineas[i_e][3]

    r_q = fitz.Rect(lx0, ly0, lx1, ly1)
    for r_h in rects_ya_sustituidos:
        inter = r_q & r_h
        if not inter.is_empty and inter.get_area() >= 0.9 * min(r_q.get_area(), r_h.get_area()):
            return False
    rects_ya_sustituidos.append(r_q)

    texto_original = " ".join(
        lineas[k][4].strip() for k in range(i_s, i_e + 1)
        if lineas[k][4].strip()
    )
    if not texto_original:
        return False
    texto_sustituir = (start_txt.strip() if (start_txt and not end_txt and i_s == i_e) else texto_original)

    if not inc_enunc:
        texto_nuevo = ""
    elif new_txt and new_txt.strip():
        texto_nuevo = new_txt.strip()
    else:
        if not textos_eliminar:
            return False
        texto_nuevo = texto_original

    resultado = aplicar_sustitucion_completa(
        doc, pagina, pno,
        texto_sustituir=texto_sustituir,
        texto_nuevo=texto_nuevo,
        textos_eliminar=tuple(textos_eliminar or ()),
        ref_y=ref_y,
        paginas_nuevas_pendientes=paginas_nuevas_pendientes,
    )

    if resultado:
        hechos.add(clave_q)
        return True
    return False
