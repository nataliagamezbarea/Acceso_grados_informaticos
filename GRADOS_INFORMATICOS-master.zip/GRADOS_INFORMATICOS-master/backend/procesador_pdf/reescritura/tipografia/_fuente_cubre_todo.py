import pymupdf as fitz

def _fuente_cubre_todo(ruta_ttf, lineas_txt):
    """Comprueba que la TTF tiene glifo REAL para cada carácter a escribir.
    Si falta alguno, la escritura produciría huecos/.notdef invisibles: mejor
    abortar YA y que el llamador use su respaldo (nunca dejar un agujero)."""
    try:
        f_chk = fitz.Font(fontfile=ruta_ttf)
    except Exception:
        return False
    for ln in lineas_txt or []:
        for ch in ln:
            if ch in (" ", "\xa0", "\t"):
                continue
            try:
                if not f_chk.has_glyph(ord(ch)):
                    return False
            except Exception:
                return False
    return True
