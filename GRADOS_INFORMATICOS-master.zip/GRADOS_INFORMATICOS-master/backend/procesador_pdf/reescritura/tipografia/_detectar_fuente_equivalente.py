import pymupdf as fitz

from backend.procesador_pdf.fuentes_y_texto import mapear_fuente_estandar

def _detectar_fuente_equivalente(nombre_fuente_orig, banderas_orig, fs):
    """DETECTA la tipografía del texto original y devuelve su equivalente
    estándar SIN añadir/incrustar ninguna fuente nueva al documento.

    Método UNIVERSAL (vale contra todas las tipografías): usa las BANDERAS del
    descriptor de la fuente que ya está dentro del PDF (serif/mono/negrita/cursiva)
    para elegir el equivalente base-14 nativo (Times/Helvetica/Courier). El
    nombre solo se usa como último respaldo si las banderas vinieran vacías.

    Devuelve (objeto_fitx_font_validado, nombre_base14)."""
    es_serif = bool(banderas_orig & 4)
    es_mono = bool(banderas_orig & 8)
    es_negrita = bool(banderas_orig & 16)
    es_cursiva = bool(banderas_orig & 2)

    if es_mono:
        base = "Courier"
        variantes = {"negrita": "Courier-Bold", "cursiva": "Courier-Oblique", "negrita_cursiva": "Courier-BoldOblique"}
    elif es_serif:
        base = "Times-Roman"
        variantes = {"negrita": "Times-Bold", "cursiva": "Times-Italic", "negrita_cursiva": "Times-BoldItalic"}
    else:
        fn = (nombre_fuente_orig or "").lower()
        if any(s in fn for s in ["times", "georgia", "garamond", "cambria", "serif", "book antiqua", "palatino"]):
            base = "Times-Roman"
            variantes = {"negrita": "Times-Bold", "cursiva": "Times-Italic", "negrita_cursiva": "Times-BoldItalic"}
        else:
            base = "Helvetica"
            variantes = {"negrita": "Helvetica-Bold", "cursiva": "Helvetica-Oblique", "negrita_cursiva": "Helvetica-BoldOblique"}

    if es_negrita and es_cursiva: elegido = variantes["negrita_cursiva"]
    elif es_negrita:              elegido = variantes["negrita"]
    elif es_cursiva:              elegido = variantes["cursiva"]
    else:                         elegido = base

    if not banderas_orig:
        elegido = mapear_fuente_estandar(nombre_fuente_orig, banderas_orig)

    for cand in [elegido, base, "Helvetica"]:
        try:
            f_obj = fitz.Font(cand)
            if f_obj.text_length("Ag 123", fontsize=max(6.0, fs)) > 0:
                return f_obj, cand
        except Exception:
            continue
    return fitz.Font("helv"), "helv"
