import pymupdf as fitz

def _fuente_solo_medidas(doc, num_pagina, nombre_fuente_orig):
    """Carga la fuente original SOLO EN MEMORIA para MEDIR anchos de línea con
    sus métricas reales (envolver el texto igual que la tipografía original).
    El objeto NUNCA se guarda ni registra en el PDF."""
    try:
        fuentes = doc.get_page_fonts(num_pagina)
    except Exception:
        return None
    tfn = (nombre_fuente_orig or "").lower()
    for f in fuentes:
        xref = f[0]
        fname = (f[3] or "").lower()
        if tfn in fname or fname.split("+")[-1] == tfn:
            try:
                buf = doc.extract_font(xref)[3]
                if buf:
                    f_med = fitz.Font(fontbuffer=buf)
                    if f_med.text_length("Ag 123", fontsize=10.0) > 0:
                        return f_med
            except Exception:
                continue
    return None
