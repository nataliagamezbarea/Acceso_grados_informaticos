from backend.procesador_pdf.reescritura.tipografia._constantes import _CODIFICACIONES_SEGURAS

def obtener_recurso_fuente_reutilizable(doc, num_pagina, nombre_fuente_objetivo):
    """Localiza el RECURSO de fuente que YA existe dentro de la página y cuya
    cara coincide con la del texto original. NO crea ni añade ningún recurso.

    Devuelve {'nombre': '/F5', 'tipo': ..., 'encoding': ..., 'es_cid': bool}
    en dos casos, ambos reutilizando glifos reales de la MISMA fuente
    incrustada, sin ambigüedad:
      · Cara simple con codificación estándar de 8 bits (WinAnsi/MacRoman/
        Standard) → cadena literal (comportamiento previo).
      · Cara Type0/CID con cualquier encoding (el caso MÁS FRECUENTE en PDFs
        actuales) → cadena hexadecimal de CIDs de 2 bytes calculados a partir de
        la propia fuente incrustada. El CID coincide con el índice de glifo
        real del subconjunto, así que el texto sale con la letra EXACTA.
    Si ninguno aplica, devuelve None (el llamador cae al respaldo base-14)."""
    try:
        fuentes = doc.get_page_fonts(num_pagina)
    except Exception:
        return None
    objetivo = (nombre_fuente_objetivo or "").lower().split("+")[-1]
    if not objetivo:
        return None
    for f in fuentes:
        try:
            xref, ext, tipo, basefont, nombre_rec = f[0], f[1], f[2], f[3], f[4]
            encoding = f[5] if len(f) > 5 else ""
        except Exception:
            continue
        bf = (basefont or "").lower().split("+")[-1]
        if objetivo not in bf and bf != objetivo:
            continue
        enc = str(encoding or "").strip()
        tipo_s = str(tipo or "")
        es_cid = "cid" in tipo_s.lower() or "type0" in tipo_s.lower()
        if not es_cid:
            if enc.lower() not in _CODIFICACIONES_SEGURAS:
                continue
        return {"nombre": str(nombre_rec or "").lstrip("/"), "tipo": tipo_s, "encoding": enc, "es_cid": es_cid}
    return None
