import pymupdf as fitz

from backend.procesador_pdf.reescritura.tipografia._constantes import _RW_DEBUG


def resolver_ruta_fuente_real(nombre_fuente_orig, banderas_orig=0):
    """Resuelve la ruta de la fuente conservando el nombre y estilo reales.

    Los flags son los flags del SPAN original de PyMuPDF y solo se usan como
    respaldo cuando el nombre no contiene el estilo. No se usa char_flags.
    """
    from backend.procesador_pdf.reescritura.fuentes_descarga import (
        parse_font_family_and_style,
        resolver_fuente_real,
    )

    familia, _estilo = parse_font_family_and_style(nombre_fuente_orig or "")

    try:
        ruta = resolver_fuente_real(
            nombre_fuente_orig or "",
            banderas=int(banderas_orig or 0),
        )
    except Exception:
        if _RW_DEBUG:
            import traceback
            traceback.print_exc()
        ruta = None

    return ruta, familia
