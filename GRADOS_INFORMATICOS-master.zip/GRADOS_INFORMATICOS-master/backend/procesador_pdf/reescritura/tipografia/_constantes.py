import os

# Depuración opcional: RW_DEBUG=1 imprime las excepciones silenciadas de las
# fases de reescritura (útil para diagnosticar sustituciones que no se aplican).
_RW_DEBUG = os.environ.get("RW_DEBUG") == "1"

_CODIFICACIONES_SEGURAS = {"winansiencoding", "macromanencoding", "standardencoding"}
