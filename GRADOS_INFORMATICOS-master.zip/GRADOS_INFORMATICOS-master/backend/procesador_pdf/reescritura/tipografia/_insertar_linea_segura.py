import pymupdf as fitz

from backend.procesador_pdf.reescritura.tipografia._constantes import _RW_DEBUG

def _insertar_linea_segura(pagina, pos, texto, tam, fuente, color):
    """Inserta una línea de texto con respaldo automático a Helvetica si la
    fuente elegida fallara en el último momento (nunca deja la línea sin escribir).

    NOTA DE COMPATIBILIDAD: Page.insert_text() de esta versión de PyMuPDF NO
    acepta el parámetro 'align' (TypeError silencioso → texto jamás escrito).
    La alineación se resuelve calculando la X de partida en el llamador."""
    try:
        rc = pagina.insert_text(pos, texto, fontsize=tam, fontname=fuente, color=color)
        if _RW_DEBUG: print(f'[RW]   insert rc={rc} y={pos[1]:.1f} {texto[:30]!r}')
        return rc
    except Exception as _e:
        if _RW_DEBUG: print(f'[RW]   insert EXCEPCION {_e!r} y={pos[1]:.1f} {texto[:30]!r}')
        try:
            return pagina.insert_text(pos, texto, fontsize=tam, fontname="helv", color=color)
        except Exception as _e2:
            if _RW_DEBUG: print(f'[RW]   insert FALLA TB con helv: {_e2!r}')
            return 0
