import pymupdf as fitz

from backend.procesador_pdf.reescritura.tipografia._constantes import _RW_DEBUG
from backend.procesador_pdf.reescritura.tipografia._fuente_cubre_todo import _fuente_cubre_todo
from backend.procesador_pdf.ayudas_render import _envolver_texto

def escribir_bloque_fuente_real(pagina, ruta_ttf, nombre_interno, lineas_txt, fs,
                                color, x0, y0, alto_linea,
                                centrado=False, derecha=False, x1=None, f_med=None,
                                baseline_primera=None, ancho_max=None):
    """Escribe el bloque de sustitución con la FUENTE REAL descargada (la misma
    letra exacta del original). Registra la fuente en el PDF con insert_font()
    y escribe cada línea verificando que PyMuPDF la acepte.

    `baseline_primera`: si se conoce la línea base REAL del texto original, la
    primera línea se dibuja EXACTAMENTE donde estaba la original.

    `ancho_max`: si se pasa, RE-ENVUELVE cada línea midiendo con la fuente REAL
    para que NUNCA supere el margen derecho (y parte palabras largas con '-').

    Devuelve True si TODAS las líneas se escribieron correctamente."""
    if not ruta_ttf or not lineas_txt:
        return False
    if not _fuente_cubre_todo(ruta_ttf, lineas_txt):
        if _RW_DEBUG: print(f'[RW] fuente real SIN glifos completos ({nombre_interno}) → respaldo')
        return False
    try:
        pagina.insert_font(fontname=nombre_interno, fontfile=ruta_ttf)
    except Exception as e:
        if _RW_DEBUG: print(f'[RW] insert_font EXC {e!r} ({nombre_interno})')
        return False

    f_render = None
    if ancho_max is not None:
        try:
            f_render = fitz.Font(fontfile=ruta_ttf)
        except Exception:
            f_render = f_med

    try:
        page_h = float(pagina.rect.height)
        y_pdf = float(y0)
        y = page_h - y_pdf if y_pdf is not None and y_pdf > 0 else y_pdf
        escritas = 0
        for i, ln in enumerate(lineas_txt):
            if i == 0 and baseline_primera is not None:
                bp = float(baseline_primera)
                y = page_h - bp if bp > 0 else bp
            x = float(x0)
            if (centrado or derecha) and x1 is not None:
                w = (f_med.text_length(ln, fontsize=fs) if f_med else len(ln) * fs * 0.5)
                if centrado:
                    x = x0 + max(0.0, ((x1 - x0) - w) / 2.0)
                elif derecha:
                    x = max(x0, x1 - w)

            if ancho_max is not None and f_render:
                w_real = f_render.text_length(ln, fontsize=fs)
                if w_real > ancho_max:
                    sub_lineas = _envolver_texto(f_render, ln, fs, ancho_max)
                    for sl in sub_lineas:
                        rc = pagina.insert_text((x, y), sl, fontsize=fs,
                                                fontname=nombre_interno, color=color)
                        if _RW_DEBUG: print(f'[RW]   real insert sub={rc} y={y:.1f} {sl[:30]!r}')
                        if not rc:
                            if _RW_DEBUG: print(f'[RW]   real insert sub FALLO; se continúa')
                            y += float(alto_linea)
                            continue
                        escritas += 1
                        y += float(alto_linea)
                    continue

            rc = pagina.insert_text((x, y), ln, fontsize=fs,
                                    fontname=nombre_interno, color=color)
            if _RW_DEBUG: print(f'[RW]   real insert rc={rc} y={y:.1f} {ln[:30]!r}')
            if not rc:
                if _RW_DEBUG: print(f'[RW]   real insert FALLO línea {i}; se continúa (anti-duplicado)')
                y += float(alto_linea)
                continue
            escritas += 1
            y += float(alto_linea)
        return escritas > 0
    except Exception as e:
        if _RW_DEBUG: print(f'[RW] bloque fuente real EXC: {e!r}')
        return False
