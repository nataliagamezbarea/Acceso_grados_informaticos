import pymupdf as fitz

def _tapar_zona(pagina, x0, y0, lineas_txt, fs, alto_linea, f_med, bg_color):
    """Pinta un rectángulo del color de fondo sobre la zona del bloque intentado.
    Es la reversión anti-duplicado: borra cualquier texto fantasma dejado por un
    intento fallido ANTES de que el llamador pruebe el siguiente respaldo."""
    try:
        ancho_est = max((f_med.text_length(ln, fontsize=fs) if f_med else len(ln) * fs * 0.5) for ln in lineas_txt)
        r = fitz.Rect(
            max(0.0, x0 - 3),
            max(0.0, y0 - 2),
            min(pagina.rect.width - 1, x0 + ancho_est + 8),
            min(pagina.rect.height - 1, y0 + alto_linea * len(lineas_txt) + 3),
        )
        pagina.draw_rect(r, color=None, fill=bg_color)
    except Exception:
        pass
