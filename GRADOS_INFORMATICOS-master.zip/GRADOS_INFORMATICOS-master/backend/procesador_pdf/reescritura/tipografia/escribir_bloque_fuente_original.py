import pymupdf as fitz

from backend.procesador_pdf.reescritura.tipografia._constantes import _RW_DEBUG
from backend.procesador_pdf.reescritura.tipografia._tapar_zona import _tapar_zona

def escribir_bloque_fuente_original(pagina, doc, recurso_nombre, lineas_txt, fs,
                                    color, x0, y0, alto_linea,
                                    centrado=False, derecha=False, x1=None, f_med=None,
                                    bg_color=None, baseline_primera=None):
    """Escribe el bloque de sustitución usando el recurso de fuente ORIGINAL que
    ya está dentro del PDF (misma letra EXACTA, mismo peso). No incrusta nada.

    ANCLAJE CORRECTO: la primera línea se dibuja en la LÍNEA BASE VISUAL
    `baseline_primera` (Y desde ARRIBA) —exactamente donde estaba el original—
    y las siguientes BAJAN una debajo de otra.

    AUTO-VERIFICACIÓN CON REVERSIÓN REAL: tras escribir, se lee la zona y se
    compara con lo esperado; si no coincide (>=70% de aciertos) se TAPA la zona
    con el color de fondo para que no quede texto fantasma y se devuelve False.

    Devuelve True si se escribió Y verificó bien; False en otro caso."""
    if not recurso_nombre or not lineas_txt:
        return False
    try:
        alto_pagina = float(pagina.rect.height)
        b1 = float(baseline_primera) if baseline_primera is not None else float(y0)
        esperado = "".join(lineas_txt)

        for i, ln in enumerate(lineas_txt):
            y = alto_pagina - (b1 + i * float(alto_linea))
            x = float(x0)
            if (centrado or derecha) and x1 is not None:
                w = (f_med.text_length(ln, fontsize=fs) if f_med else len(ln) * fs * 0.5)
                if centrado:
                    x = x0 + max(0.0, ((x1 - x0) - w) / 2.0)
                elif derecha:
                    x = max(x0, x1 - w)

            rc = pagina.insert_text((x, y), ln, fontsize=fs, fontname=recurso_nombre, color=color)
            if _RW_DEBUG: print(f'[RW]   insert rc={rc} y={y:.1f} {ln[:30]!r} font={recurso_nombre}')

            if rc == 0:
                _tapar_zona(pagina, x0, b1 - fs * 0.85, lineas_txt, fs, alto_linea, f_med,
                            bg_color if bg_color is not None else (1.0, 1.0, 1.0))
                return False

        # ---- VERIFICACIÓN leyendo la zona recién escrita ----
        import re as _re
        ancho_estimado = max((f_med.text_length(ln, fontsize=fs) if f_med else len(ln) * fs * 0.5) for ln in lineas_txt)
        rect_zona = fitz.Rect(
            max(0, x0 - 4),
            max(0, b1 - fs * 0.9),
            min(pagina.rect.width, x0 + ancho_estimado + 12),
            min(pagina.rect.height, b1 + alto_linea * (len(lineas_txt) - 1) + fs * 0.35 + 2),
        )
        leido = pagina.get_text("text", clip=rect_zona)
        def _norm(s):
            return _re.sub(r"[^0-9a-záéíóúüñçäëïöàèù]+", "", s.lower())
        objetivo = _norm(esperado)
        obtenido = _norm(leido)
        if not objetivo:
            return True
        aciertos = sum(1 for ch in objetivo if ch in obtenido)
        proporcion = aciertos / len(objetivo)
        if _RW_DEBUG:
            print(f'[RW] verificación fuente original: aciertos={proporcion:.2f} esperado={objetivo[:30]!r} leído={obtenido[:30]!r}')
        if proporcion < 0.7:
            _tapar_zona(pagina, x0, b1 - fs * 0.85, lineas_txt, fs, alto_linea, f_med,
                        bg_color if bg_color is not None else (1.0, 1.0, 1.0))
            return False
        return True
    except Exception as e:
        if _RW_DEBUG: print(f"[RW] fuente original EXC: {e!r}")
        try:
            _tapar_zona(pagina, x0, float(baseline_primera or y0) - fs * 0.85, lineas_txt, fs, alto_linea, f_med,
                        bg_color if bg_color is not None else (1.0, 1.0, 1.0))
        except Exception:
            pass
        return False
