def _codigos_cid_para_texto(f_med, texto):
    """Traduce cada carácter a su CID (índice de glifo real) DENTRO de la
    fuente incrustada `f_med` (cargada solo en memoria desde el propio PDF).

    Devuelve la cadena hexadecimal lista para '<...>Tj', o None si algún
    carácter no tiene glifo en esa fuente (entonces caer al respaldo)."""
    if f_med is None:
        return None
    partes = []
    for ch in texto:
        try:
            gid = f_med.has_glyph(ord(ch))
        except Exception:
            gid = 0
        if not gid:
            return None
        partes.append(f"{gid:04X}")
    return "".join(partes)
