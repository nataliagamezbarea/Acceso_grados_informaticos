"""
PAQUETE DE REESCRITURA · Organizado por funciones en submódulos:
  - tipografia.py   → detección universal de la fuente original + escritura segura
  - enunciados.py   → sustitución de enunciados en 3 fases (leer→borrar→escribir)
  - orquestador.py  → limpieza de nombres/colegio/imagenes + guardado seguro
API pública idéntica a la que ofrecía el antiguo módulo único reescritura_pdf.
"""

from backend.procesador_pdf.reescritura.tipografia import (
    _RW_DEBUG, _detectar_fuente_equivalente, _fuente_solo_medidas,
    _insertar_linea_segura,
)
from backend.procesador_pdf.reescritura.enunciados import (
    sustituir_enunciados_de_pagina,
)
from backend.procesador_pdf.reescritura.orquestador import (
    reescribir_y_limpiar_pdf, resaltar_documento_original,
)
from backend.procesador_pdf.reescritura.sustitucion import (
    aplicar_sustitucion_completa,
)

__all__ = [
    "reescribir_y_limpiar_pdf",
    "resaltar_documento_original",
    "sustituir_enunciados_de_pagina",
    "aplicar_sustitucion_completa",
    "_detectar_fuente_equivalente",
    "_fuente_solo_medidas",
    "_insertar_linea_segura",
    "_RW_DEBUG",
]
