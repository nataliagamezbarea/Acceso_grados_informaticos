"""COMPATIBILIDAD · el motor vive ahora dividido en el paquete
reescritura/sustitucion/ (geometria/, trazo/, fuentes/, vectores/, motor/).
Este archivo solo reexporta la entrada principal para no romper imports."""
from backend.procesador_pdf.reescritura.sustitucion import (
    aplicar_sustitucion_completa,
)

__all__ = ["aplicar_sustitucion_completa"]
