import pymupdf as fitz

from ..cuadros.color_fondo import color_fondo as obtener_color_fondo_rect
from ..texto_materializacion.lineas_ajustadas import lineas_ajustadas as _obtener_lineas_ajustadas
from ..empuje_flujo.mover_bajo_imagen import _mover_contenido_bajo_imagen_borrada
from ..cuadros.rects_cuadros import _obtener_rects_cuadros
from ..cuadros.fondos_cuadros import _obtener_fondos_cuadros
from .compactar_bucle import _compactar_bucle
from ..cuadros.restaurar_cuadros_fijos import _restaurar_cuadros_fijos

def compactar_huecos_blancos_pagina(pagina, rects_imagenes_borradas=None, min_gap=45.0, margin=24.0, zona_protegida_superior=None, rects_cuadros_protegidos=None):
    """Detecta y elimina huecos blancos excesivos dejados por bloques o imágenes eliminados.

    PROTECCIÓN DE CABECERA (zona_protegida_superior): al borrar una imagen que
    estaba justo ENCIMA de un elemento de cabecera/portada (p.ej. el cuadro
    decorativo del título), este compactador podía tirar de ese cuadro hacia
    arriba hasta dejarlo pegado al borde de la página. Ahora, si el bloque
    que subiría con la compactación está dentro de esta franja superior, ese
    hueco NO se cierra (el cuadro se queda donde está). El resto de huecos de
    la página (cuerpo del documento, imágenes 'al lado' de otro contenido,
    etc.) se siguen compactando exactamente igual que antes.

    PROTECCIÓN DE CUADROS (rects_cuadros_protegidos): si se pasan recuadros
    específicos, estos se mantienen SIEMPRE en su posición original y solo
    el texto se mueve hacia arriba para llenar el espacio."""
    try:
        if rects_imagenes_borradas is None:
            rects_imagenes_borradas = []
        if rects_cuadros_protegidos is None:
            rects_cuadros_protegidos = []
        if zona_protegida_superior is None:
            # Por defecto, el ~22% superior de la página: ahí suele vivir la
            # cabecera/título de portada. Ajustable si tu plantilla usa otra
            # proporción.
            zona_protegida_superior = pagina.rect.height * 0.22

        # Detectar imágenes visibles/activas en la página para no aplastarlas.
        img_rects = []
        try:
            for info in pagina.get_image_info(xrefs=True):
                bbox = info.get("bbox")
                if bbox:
                    r_img = fitz.Rect(bbox)
                    if r_img.width > 30 and r_img.height > 30:
                        fue_borrada = any(
                            abs(r_img.x0 - rb.x0) < 5 and abs(r_img.y0 - rb.y0) < 5
                            for rb in rects_imagenes_borradas
                        )
                        if not fue_borrada:
                            img_rects.append(r_img)
        except Exception:
            pass

        modificado = False

        # --- PASE DEDICADO: imágenes borradas ---
        if rects_imagenes_borradas:
            pno = pagina.number
            for rb in rects_imagenes_borradas:
                try:
                    _mover_contenido_bajo_imagen_borrada(pagina, rb, pno)
                    modificado = True
                except Exception:
                    pass

        # Obtener barreras de cuadros ANTES del bucle.
        fondos_cuadros = _obtener_fondos_cuadros(pagina)
        rects_cuadros = _obtener_rects_cuadros(pagina)

        valid_blocks = _obtener_lineas_ajustadas(pagina)
        if len(valid_blocks) < 2:
            return modificado

        if _compactar_bucle(pagina, valid_blocks, fondos_cuadros, rects_cuadros,
                            img_rects, rects_imagenes_borradas, rects_cuadros_protegidos,
                            min_gap, margin):
            modificado = True

        _restaurar_cuadros_fijos(pagina)
        return modificado
    except Exception:
        return False

compactar = compactar_huecos_blancos_pagina
