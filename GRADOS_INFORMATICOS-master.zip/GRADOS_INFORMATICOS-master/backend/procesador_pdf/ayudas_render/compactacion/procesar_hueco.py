import pymupdf as fitz

from .aplicar_compactacion_hueco import _aplicar_compactacion_hueco

def _procesar_hueco(pagina, prev_y1, next_y0, gap, fondos_cuadros, rects_cuadros,
                    img_rects, rects_cuadros_protegidos, margin):
    """Evalúa un hueco entre dos bloques y, si procede, lo compacta.
    Devuelve (modificado, nuevas_valid_blocks): si modificado es True,
    nuevas_valid_blocks es la lista de bloques recalculada tras mover."""
    # Si hay un fondo de cuadro DENTRO del hueco, el contenido
    # solo sube hasta ese fondo (barrera del cuadro), no más allá.
    fondo_barrera = None
    for fc in fondos_cuadros:
        if prev_y1 < fc < next_y0:
            fondo_barrera = fc
            break
    if fondo_barrera is not None:
        # Hay un cuadro fijo en el hueco: NO compactar este hueco.
        return (False, None)

    # BARRERA POR RECUADRO COMPLETO: si algún recuadro dibujado
    # EMPIEZA dentro del hueco, cerrar el hueco arrastraría el recuadro
    # entero hacia arriba. Ese blanco es diseño original: no compactar.
    hueco_toca_cuadro = any(
        (prev_y1 - 2 < r_c.y0 < next_y0 + 2) or (prev_y1 < r_c.y1 < next_y0)
        for r_c in rects_cuadros
    )
    if hueco_toca_cuadro:
        return (False, None)

    # Comprobar si hay una imagen activa/visible en el hueco.
    hay_imagen_en_hueco = any(
        (prev_y1 - 10 <= r_img.y0 <= next_y0 + 10) or (prev_y1 - 10 <= r_img.y1 <= next_y0 + 10)
        for r_img in img_rects
    )
    if True:
        # NOTA: antes, si había una imagen tocando el hueco, se dejaba TODO
        # quieto para no tocarla. Ahora se compacta igual: show_pdf_page mueve
        # la franja de abajo COMPLETA (imagen incluida) hacia arriba.

        # FIX: si hay cuadros protegidos en el hueco, el texto se mueve hacia
        # arriba pero respetando el cuadro como barrera (el cuadro permanece).
        hay_cuadro_protegido_en_hueco = any(
            (prev_y1 - 10 <= r_c.y0 <= next_y0 + 10) or (prev_y1 - 10 <= r_c.y1 <= next_y0 + 10)
            for r_c in rects_cuadros_protegidos
        )

        shift = gap - margin
        if shift > 12:
            pno = pagina.number

            # Si hay cuadro protegido, calcular el límite superior del movimiento.
            if hay_cuadro_protegido_en_hueco:
                cuadro_limitante = None
                for r_c in rects_cuadros_protegidos:
                    if r_c.y0 > prev_y1 and r_c.y0 < next_y0:
                        if cuadro_limitante is None or r_c.y0 < cuadro_limitante.y0:
                            cuadro_limitante = r_c
                if cuadro_limitante:
                    espacio_hasta_cuadro = cuadro_limitante.y0 - prev_y1 - margin
                    shift = min(shift, espacio_hasta_cuadro)
                    if shift <= 0:
                        return (False, None)

            nuevas = _aplicar_compactacion_hueco(pagina, prev_y1, next_y0, margin, shift)
            return (True, nuevas)
    return (False, None)
