import pymupdf as fitz

from ..cuadros.color_fondo import color_fondo as obtener_color_fondo_rect
from ..texto_materializacion.lineas_ajustadas import lineas_ajustadas as _obtener_lineas_ajustadas

def _aplicar_compactacion_hueco(pagina, prev_y1, next_y0, margin, shift):
    """Re_llena un hueco blanco moviendo hacia arriba (VECTOR, show_pdf_page)
    la franja inferior, y devuelve la lista de bloques de texto recalculada."""
    pno = pagina.number
    rect_below = fitz.Rect(0, next_y0 - 2, pagina.rect.width, pagina.rect.height)
    rect_target = fitz.Rect(0, prev_y1 + margin, pagina.rect.width,
                           prev_y1 + margin + rect_below.height)

    # Mover el contenido de abajo HACIA ARRIBA manteniéndolo como
    # VECTOR (texto real, modificable; NO rasterizado).
    try:
        src = fitz.open(stream=pagina.parent.tobytes(), filetype="pdf")
    except Exception:
        src = None

    # COLOR DE FONDO: el propio HUECO (entre prev_y1 y next_y0) es
    # fondo puro, la muestra más fiel de cómo ha de verse la zona.
    rect_muestra_fondo = fitz.Rect(0, prev_y1 + 4, pagina.rect.width, next_y0 - 2)
    if rect_muestra_fondo.height > 4:
        bg_col = obtener_color_fondo_rect(pagina, rect_muestra_fondo)
    else:
        bg_col = obtener_color_fondo_rect(pagina, rect_below)

    rect_clear = fitz.Rect(0, prev_y1 + 4, pagina.rect.width, pagina.rect.height)
    pagina.add_redact_annot(rect_clear, fill=bg_col)
    pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS)

    if src is not None:
        try:
            pagina.show_pdf_page(rect_target, src, pno, clip=rect_below)
        except Exception:
            pix = pagina.get_pixmap(clip=rect_below, dpi=200)
            pagina.insert_image(rect_target, pixmap=pix)
        src.close()
    else:
        pix = pagina.get_pixmap(clip=rect_below, dpi=200)
        pagina.insert_image(rect_target, pixmap=pix)

    rects = _obtener_lineas_ajustadas(pagina)
    return sorted(rects, key=lambda b: b[1])
