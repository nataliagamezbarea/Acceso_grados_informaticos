import pymupdf as fitz

from .procesar_hueco import _procesar_hueco

def _compactar_bucle(pagina, valid_blocks, fondos_cuadros, rects_cuadros,
                     img_rects, rects_imagenes_borradas, rects_cuadros_protegidos,
                     min_gap, margin):
    """Recorre los bloques de texto y compacta los huecos blancos suficientes.
    Devuelve True si movió algo."""
    modificado = False
    i = 0
    while i < len(valid_blocks) - 1:
        prev_y1 = valid_blocks[i][3]
        next_y0 = valid_blocks[i + 1][1]
        gap = next_y0 - prev_y1
        if gap >= min_gap and next_y0 < pagina.rect.height - 30:
            # CORRECCIÓN (indentación): el borrado y repegado se ejecuta SOLO
            # cuando hay hueco real a compactar (shift suficiente, sin imagen
            # ni cuadro protegido de por medio), evitando variables STALE.
            movido, nuevas = _procesar_hueco(
                pagina, prev_y1, next_y0, gap, fondos_cuadros, rects_cuadros,
                img_rects, rects_cuadros_protegidos, margin
            )
            if movido:
                modificado = True
                if nuevas is not None:
                    valid_blocks = nuevas
        i += 1
    return modificado
