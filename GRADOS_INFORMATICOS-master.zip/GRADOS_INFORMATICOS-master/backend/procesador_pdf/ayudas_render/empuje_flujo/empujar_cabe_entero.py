import pymupdf as fitz

from ..cuadros.color_fondo import color_fondo as obtener_color_fondo_rect

def _empujar_cabe_entero(pagina, rect_bajo, y_destino, alto_total):
    """Desplaza hacia abajo todo el contenido de rect_bajo cuando cabe entero
    en la página (VECTOR con show_pdf_page)."""
    try:
        src = fitz.open(stream=pagina.parent.tobytes(), filetype="pdf")
    except Exception:
        src = None
    bg_col = obtener_color_fondo_rect(pagina, rect_bajo)
    pagina.add_redact_annot(rect_bajo, fill=bg_col)
    pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS)
    rect_destino = fitz.Rect(0, y_destino, pagina.rect.width, y_destino + alto_total)
    if src is not None:
        try:
            pagina.show_pdf_page(rect_destino, src, pagina.number, clip=rect_bajo)
        except Exception:
            pass
        src.close()
    else:
        # Fallback: pixmap solo si falla show_pdf_page
        pix = pagina.get_pixmap(clip=rect_bajo, dpi=200)
        bg_col = obtener_color_fondo_rect(pagina, rect_bajo)
        pagina.add_redact_annot(rect_bajo, fill=bg_col)
        pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS)
        rect_destino = fitz.Rect(0, y_destino, pagina.rect.width, y_destino + alto_total)
        pagina.insert_image(rect_destino, pixmap=pix)
    return True
