import pymupdf as fitz

from ..cuadros.cajas_dibujadas import _cajas_dibujadas_desde
from .empujar_cabe_entero import _empujar_cabe_entero
from .empujar_no_cabe import _empujar_no_cabe

def _empujar_contenido_hacia_abajo(pagina, y_origen, desplazamiento, paginas_pendientes=None, y_hasta=None):
    """Desplaza hacia abajo TODO el contenido de la página situado por debajo de y_origen,
    dejando hueco libre para un enunciado reescrito más largo que el original (así la
    sustitución conserva EXACTAMENTE la letra y el tamaño originales, sin encoger).

    CORRECCIÓN IMPORTANTE ("bad page number(s)" / PDF corrupto): si el sobrante necesita
    una página de continuación, YA NO se crea aquí dentro. Crear páginas con doc.new_page()
    DENTRO del bucle que enumera las páginas renumeraba el resto del documento y provocaba
    'ValueError: bad page number(s)' y archivos en caché corruptos. Ahora la página
    pendiente se APUNTA en 'paginas_pendientes' y quien llama la materializa con
    materializar_paginas_pendientes() al terminar el bucle.

    El contenido empujado se reinserta SIEMPRE a su tamaño real (nunca comprimido).
    Devuelve True si el desplazamiento se aplicó y False si no se pudo aplicar.
    """
    try:
        if desplazamiento <= 0:
            return True
        alto_pagina = pagina.rect.height
        if y_origen >= alto_pagina - 1:
            return True
        # y_hasta: límite INFERIOR del empuje. Si se indica, TODO lo que esté
        # por debajo de y_hasta (p.ej. un recuadro "cuadrado" aislado en la parte
        # baja) se DEJA QUIETO: el empuje solo mueve el contenido de arriba y no
        # arrastra ni fragmenta elementos independientes que no colisionarían.
        y_fin = y_hasta if (y_hasta is not None and y_hasta > y_origen) else alto_pagina
        rect_bajo = fitz.Rect(0, y_origen, pagina.rect.width, y_fin)
        if rect_bajo.height <= 1:
            return True
        y_destino = min(alto_pagina, y_origen + desplazamiento)
        alto_que_cabe = max(0.0, alto_pagina - y_destino)
        alto_total = rect_bajo.height

        if alto_que_cabe >= alto_total - 0.5:
            # Cabe entero: mover con show_pdf_page (VECTOR)
            return _empujar_cabe_entero(pagina, rect_bajo, y_destino, alto_total)

        # No cabe entero: detectar si el corte partiría un cuadro atómico
        y_corte = y_origen + alto_que_cabe
        for _caja in _cajas_dibujadas_desde(pagina, y_origen):
            if _caja.y0 < y_corte < _caja.y1:
                alto_que_cabe = max(0.0, _caja.y0 - y_origen)
                break

        if alto_que_cabe <= 1:
            return False

        # Empujar solo lo que quepa en esta página (VECTOR con show_pdf_page)
        return _empujar_no_cabe(pagina, rect_bajo, y_destino, alto_que_cabe, y_origen, y_fin, paginas_pendientes, alto_pagina)
    except Exception:
        return False
