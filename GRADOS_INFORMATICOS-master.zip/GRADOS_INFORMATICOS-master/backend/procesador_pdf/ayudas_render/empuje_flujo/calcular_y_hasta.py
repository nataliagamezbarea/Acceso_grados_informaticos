import pymupdf as fitz

def _calcular_y_hasta_para_no_mover_independiente(pagina, y_origen, desplazamiento):
    """Si por debajo de y_origen hay un elemento INDEPENDIENTE (p.ej. un recuadro
    "cuadrado" aislado en la parte baja de la página) separado del cuerpo principal
    por un hueco suficiente, devuelve la coordenada en la que debe TERMINAR el empuje
    (el fondo del cuerpo, justo por encima del hueco), de modo que ese elemento
    independiente NO se mueva: empujar el contenido de arriba por 'desplazamiento'
    no lo alcanza porque el hueco es >= desplazamiento.

    Devuelve None si no aplica (comportamiento normal: empujar todo hacia abajo).
    """
    try:
        altura = pagina.rect.height
        ancho = pagina.rect.width
        bloques = pagina.get_text("blocks")
        inferiores = [b for b in bloques if len(b) >= 5 and b[3] > y_origen + 1]
        if len(inferiores) < 2:
            return None
        inferiores.sort(key=lambda b: b[1])
        ultimo = inferiores[-1]
        top_ult = ultimo[1]
        bot_ult = ultimo[3]
        ancho_ult = ultimo[2] - ultimo[0]
        alto_ult = bot_ult - top_ult
        # Criterio de "elemento independiente": pequeño en alto, no a todo el
        # ancho de la página (es un recuadro/cuadro, no un párrafo de cuerpo).
        es_independiente = (alto_ult < 0.3 * altura) and (ancho_ult < 0.6 * ancho)
        if not es_independiente:
            return None
        penult = inferiores[-2]
        hueco = top_ult - penult[3]
        # Si el hueco es mayor o igual que el desplazamiento, empujar el cuerpo de
        # arriba NO alcanza al elemento -> lo dejamos quieto.
        if hueco >= desplazamiento - 0.5:
            return penult[3]  # fondo del cuerpo (justo encima del hueco)
    except Exception:
        return None
    return None
