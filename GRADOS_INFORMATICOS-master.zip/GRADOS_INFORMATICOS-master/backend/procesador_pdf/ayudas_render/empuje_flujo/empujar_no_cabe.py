import pymupdf as fitz

from ..cuadros.color_fondo import color_fondo as obtener_color_fondo_rect

def _empujar_no_cabe(pagina, rect_bajo, y_destino, alto_que_cabe, y_origen, y_fin, paginas_pendientes, alto_pagina):
    """Empuja solo la parte que cabe en esta página (VECTOR con show_pdf_page)
    y deja el resto como página de continuación pendiente."""
    rect_parte_actual = fitz.Rect(0, y_origen, pagina.rect.width, y_origen + alto_que_cabe)
    rect_parte_resto = fitz.Rect(0, y_origen + alto_que_cabe, pagina.rect.width, y_fin)
    try:
        src = fitz.open(stream=pagina.parent.tobytes(), filetype="pdf")
    except Exception:
        src = None
    bg_col = obtener_color_fondo_rect(pagina, rect_bajo)
    pagina.add_redact_annot(rect_bajo, fill=bg_col)
    pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS)
    if src is not None:
        try:
            # Parte que cabe en esta página. OJO: el destino debe tener la
            # MISMA altura que el recorte de origen (alto_que_cabe), que
            # puede haberse REDUCIDO justo arriba para no partir un cuadro
            # atómico (tabla/recuadro). Antes el destino siempre llegaba
            # hasta 'alto_pagina' aunque el origen fuera más pequeño:
            # show_pdf_page ESTIRABA el contenido verticalmente para
            # rellenar ese hueco de más, deformando tablas y recuadros
            # justo por el borde donde se cortaban ("tabla cortada por
            # arriba"/con las filas desplazadas). Ahora el destino mide
            # exactamente lo mismo que el origen: sin estirar nada.
            rect_dest_actual = fitz.Rect(0, y_destino, pagina.rect.width, y_destino + alto_que_cabe)
            pagina.show_pdf_page(rect_dest_actual, src, pagina.number, clip=rect_parte_actual)

            # Resto -> página de continuación.
            # CORRECCIÓN: el pixmap del "resto" se capturaba de 'pagina'
            # (la página YA REDACTADA/borrada unas líneas más arriba con
            # add_redact_annot+apply_redactions sobre TODO 'rect_bajo',
            # que incluye justo esta zona). Es decir, se guardaba una
            # imagen en blanco/fondo en vez del contenido real -> la
            # tabla/recuadro que debía continuar en la página siguiente
            # aparecía cortada o vacía. Ahora se captura de 'src', la
            # copia intacta tomada ANTES de borrar nada.
            rect_parte_resto = fitz.Rect(0, y_origen + alto_que_cabe, pagina.rect.width, y_fin)
            if rect_parte_resto.height > 10:
                if paginas_pendientes is not None:
                    pix_resto = src[pagina.number].get_pixmap(clip=rect_parte_resto, dpi=200)
                    paginas_pendientes.append({
                        "despues_de": pagina.number,
                        "ancho": pagina.rect.width,
                        "alto_pagina": alto_pagina,
                        "pix": pix_resto,
                        "alto": rect_parte_resto.height
                    })
        except Exception:
            pass
        src.close()
    return True
