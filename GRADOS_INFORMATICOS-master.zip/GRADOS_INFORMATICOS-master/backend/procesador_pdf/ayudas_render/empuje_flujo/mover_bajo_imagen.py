import pymupdf as fitz

def _mover_contenido_bajo_imagen_borrada(pagina, rb, pno):
    """Mueve hacia arriba (vector, show_pdf_page) TODO el contenido situado por
    debajo de una imagen borrada para rellenar su hueco.

    El recorte de ORIGEN arranca en el TOPE INFERIOR de la imagen (rb.y1) y no
    en la primera línea de texto: de ese modo el marco/decoración que rodea al
    texto (que queda por debajo de la imagen) viaja ENTERO con él y no se
    parte. El DESTINO es el tope superior de la imagen (rb.y0), así el hueco
    queda ocupado por el contenido de abajo."""
    w = pagina.rect.width
    h = pagina.rect.height
    y_top = rb.y0
    y_bot = rb.y1
    if y_bot >= h - 1:
        return
    rect_below = fitz.Rect(0, y_bot, w, h)
    rect_target = fitz.Rect(0, y_top, w, y_top + (h - y_bot))
    try:
        src = fitz.open(stream=pagina.parent.tobytes(), filetype="pdf")
    except Exception:
        src = None
    rect_clear = fitz.Rect(0, y_bot, w, h)
    pagina.add_redact_annot(rect_clear, fill=(1, 1, 1))
    pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS)
    if src is not None:
        try:
            pagina.show_pdf_page(rect_target, src, pno, clip=rect_below)
        except Exception:
            pix = pagina.get_pixmap(clip=rect_below, dpi=200)
            pagina.insert_image(rect_target, pixmap=pix)
        src.close()
    else:
        pix = pagina.get_pixmap(clip=rect_below, dpi=200)
        pagina.insert_image(rect_target, pixmap=pix)
