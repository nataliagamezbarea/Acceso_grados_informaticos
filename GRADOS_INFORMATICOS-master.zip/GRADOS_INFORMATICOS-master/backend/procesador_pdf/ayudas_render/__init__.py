from .cuadros import (
    obtener_color_fondo_rect, _ajustar_un_cuadro, _obtener_fondos_cuadros,
    _procesar_cuadros_dibujados_despues_de_borrado, _cajas_dibujadas_desde,
    _restaurar_cuadros_fijos, _obtener_rects_cuadros
)
from .texto_materializacion import (
    materializar_paginas_pendientes, _envolver_texto, _obtener_lineas_ajustadas,
    envolver_texto, lineas_ajustadas, materializar
)
from .compactacion import (
    _procesar_hueco, compactar_huecos_blancos_pagina, _aplicar_compactacion_hueco,
    _compactar_bucle
)
from .empuje_flujo import (
    _mover_contenido_bajo_imagen_borrada, _empujar_no_cabe,
    _empujar_contenido_hacia_abajo, _empujar_cabe_entero,
    _calcular_y_hasta_para_no_mover_independiente
)
