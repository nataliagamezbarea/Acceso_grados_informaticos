import pymupdf as fitz

def materializar_paginas_pendientes(doc, paginas_pendientes):
    """Crea AL FINAL del bucle (nunca durante) las páginas de continuación dejadas
    pendientes por _empujar_contenido_hacia_abajo. Se procesan en orden DESCENDENTE
    de posición para que cada inserción no desplace los números de página de los
    siguientes pendientes."""
    if not paginas_pendientes:
        return False
    creado = False
    for item in sorted(paginas_pendientes, key=lambda it: it.get("despues_de", 0), reverse=True):
        try:
            pno_base = item["despues_de"]
            ancho = item.get("ancho", 595.0)
            alto = item.get("alto_pagina", 842.0)
            pagina_extra = doc.new_page(pno=pno_base + 1, width=ancho, height=alto)
            # NUEVO FORMATO: el motor puede dejar una función constructora que
            # escribe el contenido de la página 2 de forma vectorial (texto,
            # imágenes y dibujos reutilizados), en vez de un pixmap plano. Esto
            # permite que la continuación de un enunciado conserve la capa de
            # texto y los vectores originales. El formato antiguo con 'pix'
            # se conserva para compatibilidad.
            if callable(item.get("constructor")):
                item["constructor"](pagina_extra)
                creado = True
            elif item.get("pix") is not None:
                margen_sup = 24.0
                rect_dest = fitz.Rect(0, margen_sup, ancho, margen_sup + item["alto"])
                pagina_extra.insert_image(rect_dest, pixmap=item["pix"])
                creado = True
        except Exception:
            continue
    return creado
