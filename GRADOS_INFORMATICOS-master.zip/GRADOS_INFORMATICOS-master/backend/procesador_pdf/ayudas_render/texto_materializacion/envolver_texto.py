import pymupdf as fitz

def _envolver_texto(fuente, texto, fontsize, ancho_max):
    """Reparte un texto en varias líneas que caben en ancho_max.

    · RESPETA EL MARGEN DERECHO: aplica una pequeña reserva de seguridad para
      que la línea escrita nunca roce ni sobrepase el margen.
    · PALABRA LARGA: si una palabra sola no cabe entera en el ancho, se corta
      con GUIÓN '-' al final de la línea y continúa debajo."""
    try:
        def _ancho(s):
            return float(fuente.text_length(s, fontsize=fontsize))
    except Exception:
        def _ancho(s):
            return len(s) * fontsize * 0.5

    # Reserva de seguridad (~3% del ancho útil): aire junto al margen derecho
    ancho_utl = ancho_max * 0.97

    def _cabe(s):
        return _ancho(s) <= ancho_utl

    def _romper(w):
        """Corta una palabra demasiado larga en trozos con '-' al final."""
        trozos = []
        t = ""
        for ch in w:
            prueba = t + ch
            if t and not _cabe(prueba + "-"):
                trozos.append(t + "-")
                t = ch
            else:
                t = prueba
        trozos.append(t)
        return trozos

    lineas = []
    actual = ""
    for w in texto.split():
        prueba = (actual + " " + w).strip()
        if _cabe(prueba):
            actual = prueba
            continue
        if actual:
            lineas.append(actual)
            actual = ""
        if _cabe(w):
            actual = w
        else:
            trozos = _romper(w)
            for tz in trozos[:-1]:
                lineas.append(tz)
            actual = trozos[-1]
    if actual:
        lineas.append(actual)
    return lineas or [""]

envolver_texto = _envolver_texto
