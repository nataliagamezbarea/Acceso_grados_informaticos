import pymupdf as fitz

def _obtener_lineas_ajustadas(pagina):
    """Devuelve los rectángulos de TEXTO de la página usando get_text("dict").

    A diferencia de get_text("blocks"), cada rectángulo es una LÍNEA con un
    bbox ajustado a los glifos reales (sin el padding del bloque). Eso evita
    que la compactación mida huecos demasiado pequeños y apenas mueva el
    contenido de abajo al borrar una imagen."""
    lineas = []
    try:
        td = pagina.get_text("dict")
        for b in td.get("blocks", []):
            for l in b.get("lines", []):
                lb = l.get("bbox")
                # Descartar líneas fuera de página (get_text("dict") a veces
                # devuelve una línea basura a y<0) y las de altura irrelevante:
                # esas líneas creaban un "hueco" falso que cascabeaba y tiraba
                # de TODO el contenido hacia el borde superior.
                if lb and (lb[3] - lb[1]) > 0.5 and lb[1] > 0.5 and lb[3] < pagina.rect.height:
                    lineas.append([lb[0], lb[1], lb[2], lb[3]])
    except Exception:
        pass
    return lineas

lineas_ajustadas = _obtener_lineas_ajustadas
