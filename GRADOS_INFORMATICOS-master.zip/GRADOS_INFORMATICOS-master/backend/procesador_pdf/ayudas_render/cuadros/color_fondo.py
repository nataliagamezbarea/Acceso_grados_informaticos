import pymupdf as fitz

def obtener_color_fondo_rect(pagina, rect):
    """Muestrea el color de fondo alrededor de un rectángulo de forma robusta.

    CORRECCIÓN (fondo blanco al sustituir): antes se tomaba la MODA de 9 puntos
    con cada componente RGB redondeada a múltiplos de 16; sobre fondos de color,
    degradados o fondos con trama eso devolvía un color equivocado (casi blanco)
    y al sustituir el enunciado quedaba una mancha blanca que no estaba en el
    original. Ahora:
      1. Se muestrea una rejilla más densa (4x4) dentro y alrededor del rect.
      2. Se DESCARTAN los píxeles de tinta/texto (mucho más oscuros o claros que
         la mediana de luminancia), que antes podían "ganar" la moda y oscurecer
         o ensuciar el color detectado.
      3. Se devuelve el PROMEDIO de los píxeles restantes (sin cuantizar), mucho
         más fiel al fondo real sea liso, suave o degradado."""
    try:
        clip_rect = fitz.Rect(
            max(0, rect.x0 - 6),
            max(0, rect.y0 - 6),
            min(pagina.rect.width, rect.x1 + 6),
            min(pagina.rect.height, rect.y1 + 6)
        )
        pix = pagina.get_pixmap(clip=clip_rect, dpi=96)
        if pix.width < 3 or pix.height < 3:
            return (1.0, 1.0, 1.0)

        # 1. Muestrear rejilla 4x4
        colores = []
        for gy in range(4):
            for gx in range(4):
                px = int((gx + 0.5) * pix.width / 4)
                py = int((gy + 0.5) * pix.height / 4)
                px = max(0, min(px, pix.width - 1))
                py = max(0, min(py, pix.height - 1))
                try:
                    r, g, b = pix.pixel(px, py)[:3]
                except Exception:
                    continue
                colores.append((float(r), float(g), float(b)))
        if not colores:
            return (1.0, 1.0, 1.0)

        # 2. Filtrar píxeles de tinta/texto: se queda con los cercanos a la
        #    luminancia mediana (el fondo siempre es la mayoría de la zona).
        lums = sorted(sum(c) / 3.0 for c in colores)
        mediana = lums[len(lums) // 2]
        fondo = [c for c in colores if abs(sum(c) / 3.0 - mediana) <= 60.0]
        if not fondo:
            fondo = colores

        # 3. Promedio sin cuantización brusca (fiel también en degradados)
        n = float(len(fondo))
        return (
            max(0.0, min(1.0, sum(c[0] for c in fondo) / n / 255.0)),
            max(0.0, min(1.0, sum(c[1] for c in fondo) / n / 255.0)),
            max(0.0, min(1.0, sum(c[2] for c in fondo) / n / 255.0))
        )
    except Exception:
        return (1.0, 1.0, 1.0)

color_fondo = obtener_color_fondo_rect
