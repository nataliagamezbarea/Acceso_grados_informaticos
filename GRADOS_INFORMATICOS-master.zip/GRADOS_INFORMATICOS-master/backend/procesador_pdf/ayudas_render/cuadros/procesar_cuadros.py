import pymupdf as fitz

from .ajustar_cuadro import _ajustar_un_cuadro

def _procesar_cuadros_dibujados_despues_de_borrado(pagina, rects_borrados):
    """Tras redactar nombres/colegio dentro de un recuadro (p.ej. el cuadro
    "FECHA DE ENTREGA / FECHA DEL TRABAJO TERMINADO / <nombre>, <grado>..."),
    ENCOGE ese recuadro para que no quede hueco en blanco donde antes había
    texto borrado.

    ANCLAJE POR ABAJO (clave): el borde INFERIOR del recuadro (r.y1) NUNCA
    se mueve — el recuadro siempre "termina donde terminaba el original".
    Encoger el recuadro significa bajar su borde SUPERIOR (r.y0) hasta pegarlo
    al contenido que queda, y desplazar ese contenido restante hacia abajo la
    misma distancia, para que quede pegado al nuevo borde superior con el
    mismo margen interior que tenía siempre. El recuadro JAMÁS se desplaza
    hacia arriba (su y1 es fijo); solo se reduce su altura.
    """
    if not rects_borrados:
        return False
    try:
        dibujos = pagina.get_drawings()
    except Exception:
        return False
    if not dibujos:
        return False
    if not hasattr(pagina, '_cuadros_fijos'):
        pagina._cuadros_fijos = []
    modificado = False
    for d in dibujos:
        rect = d.get("rect")
        if not rect:
            continue
        r = fitz.Rect(rect)
        color = d.get("color")
        ancho = d.get("width") or 0
        if not color or ancho <= 0:
            continue
        if r.width < 40 or r.height < 40:
            continue
        if not any(r.contains(fitz.Rect(rb)) for rb in rects_borrados):
            continue
        if _ajustar_un_cuadro(pagina, r, color, ancho, rects_borrados):
            modificado = True
    return modificado
