import pymupdf as fitz

from .color_fondo import color_fondo as obtener_color_fondo_rect
from ..texto_materializacion.lineas_ajustadas import _obtener_lineas_ajustadas

def _ajustar_un_cuadro(pagina, r, color, ancho, rects_borrados):
    """Ajusta UN cuadro dibujado tras borrar su contenido: encoge desde arriba
    (el borde inferior y1 es fijo) y redibuja el trazo con la nueva geometría.
    Devuelve True porque siempre modifica el trazo del recuadro."""
    y0_original = r.y0
    y1_original = r.y1  # ANCLA FIJA: el borde INFERIOR nunca se mueve.
    # Se recorta el SOBRANTE de ARRIBA (no el de abajo), así el recuadro
    # siempre "termina donde terminaba el original" y conserva la misma
    # distancia al pie de página que tenía en el documento original.

    # Líneas de texto que SIGUEN dentro del recuadro tras la redacción.
    lineas_restantes = [
        ln for ln in _obtener_lineas_ajustadas(pagina)
        if ln[0] >= r.x0 - 2 and ln[2] <= r.x1 + 2
        and ln[1] >= r.y0 - 2 and ln[3] <= r.y1 + 2
    ]

    if not lineas_restantes:
        # No queda contenido: mantener el recuadro tal cual (evita un
        # recuadro degenerado / invisible). Solo se refresca el trazo.
        pagina._cuadros_fijos.append({'rect': r, 'color': color, 'width': ancho})
        try:
            pagina.draw_rect(r, color=color, width=ancho)
        except Exception:
            pass
        return True

    lineas_restantes.sort(key=lambda ln: ln[1])
    top_contenido = lineas_restantes[0][1]
    bot_contenido = lineas_restantes[-1][3]
    # Margen interior INFERIOR original: como y1 no se toca, esta
    # distancia (contenido -> borde de abajo) sigue siendo válida y es la
    # que se replica arriba para que el recuadro quede simétrico.
    padding_inf = max(4.0, y1_original - bot_contenido)
    contenido_alto = max(0.0, bot_contenido - top_contenido)

    nuevo_alto = padding_inf + contenido_alto + padding_inf
    nuevo_alto = min(nuevo_alto, r.height)  # nunca crecer, solo encoger
    freed = r.height - nuevo_alto

    if freed > 1.0:
        # El contenido que queda ya está pegado a su margen inferior
        # original (no hace falta moverlo). Solo se borra la franja
        # SOBRANTE de ARRIBA (texto ya eliminado + antiguo borde
        # superior) y se redibuja el recuadro más corto, con el mismo
        # borde inferior de siempre.
        bg_col = obtener_color_fondo_rect(pagina, fitz.Rect(r.x0 - 3, r.y0 - 3, r.x1 + 3, r.y1 + 3))
        nuevo_y0 = y1_original - nuevo_alto
        franja_sobrante = fitz.Rect(
            r.x0 - 3, y0_original - 3,
            r.x1 + 3, nuevo_y0 + 3
        )
        pagina.add_redact_annot(franja_sobrante, fill=bg_col)
        pagina.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS)
        r = fitz.Rect(r.x0, nuevo_y0, r.x1, y1_original)

    # Registrar como cuadro fijo con su nueva geometría (y1 SIEMPRE igual
    # al original) y redibujar el trazo.
    pagina._cuadros_fijos.append({'rect': r, 'color': color, 'width': ancho})
    try:
        pagina.draw_rect(r, color=color, width=ancho)
    except Exception:
        pass
    return True
