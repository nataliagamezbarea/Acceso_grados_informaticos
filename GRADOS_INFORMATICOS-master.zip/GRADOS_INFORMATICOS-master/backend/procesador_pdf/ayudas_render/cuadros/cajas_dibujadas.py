import pymupdf as fitz

def _cajas_dibujadas_desde(pagina, y_min):
    """Devuelve los rects de los cuadros con trazo (recuadros con borde, p.ej.
    "FECHA DE ENTREGA") cuyo borde inferior está por debajo de y_min. Se usa
    para tratar esos cuadros como bloques ATÓMICOS al empujar/paginar: nunca
    se debe dejar el borde superior en su sitio mientras el resto del cuadro
    se desplaza o se pasa a otra página, porque eso rompe el recuadro
    visualmente (queda "partido", como si no coincidiera con el original)."""
    try:
        dibujos = pagina.get_drawings()
    except Exception:
        return []
    cajas = []
    for d in dibujos:
        rect = d.get("rect")
        if not rect:
            continue
        r = fitz.Rect(rect)
        color = d.get("color")
        ancho = d.get("width") or 0
        if not color or ancho <= 0:
            continue
        if r.width < 40 or r.height < 40:
            continue
        if r.y1 <= y_min:
            continue
        cajas.append(r)
    return cajas
