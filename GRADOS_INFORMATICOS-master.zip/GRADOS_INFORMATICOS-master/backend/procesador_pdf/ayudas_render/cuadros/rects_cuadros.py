import pymupdf as fitz

def _obtener_rects_cuadros(pagina):
    """Devuelve los Rect COMPLETOS de los cuadros dibujados (rectángulos con
    trazo) de la página. Se usa para que la compactación trate cada recuadro
    como un elemento ATÓMICO: si un hueco blanco toca o contiene cualquier
    parte de un recuadro (aunque solo sea su borde SUPERIOR, caso típico de
    "texto arriba + recuadro abajo"), ese hueco NO debe cerrarse, porque
    cerrarlo arrastra el recuadro hacia arriba dejándolo pegado al texto."""
    try:
        dibujos = pagina.get_drawings()
    except Exception:
        return []
    rects = []
    for d in dibujos:
        rect = d.get("rect")
        if not rect:
            continue
        r = fitz.Rect(rect)
        color = d.get("color")
        ancho = d.get("width") or 0
        if not color or ancho <= 0:
            continue
        if r.width < 40 or r.height < 40:
            continue
        rects.append(r)
    return rects
