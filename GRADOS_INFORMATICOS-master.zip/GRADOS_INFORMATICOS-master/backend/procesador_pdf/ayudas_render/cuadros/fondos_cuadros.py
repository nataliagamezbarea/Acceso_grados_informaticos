import pymupdf as fitz

def _obtener_fondos_cuadros(pagina):
    """Devuelve una lista de coordenadas Y (bottom) de los bordes inferiores
    de los cuadros dibujados (rectángulos con trazo) que actúan como barreras
    para la compactación hacia arriba. El contenido no subirá más allá de
    estos límites."""
    try:
        dibujos = pagina.get_drawings()
    except Exception:
        return []
    fondos = []
    for d in dibujos:
        rect = d.get("rect")
        if not rect:
            continue
        r = fitz.Rect(rect)
        color = d.get("color")
        ancho = d.get("width") or 0
        if not color or ancho <= 0:
            continue
        if r.width < 40 or r.height < 40:
            continue
        # Es un cuadro con trazo: su borde inferior es una barrera.
        fondos.append(r.y1)
    return sorted(set(fondos))
