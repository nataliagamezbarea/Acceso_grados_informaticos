import pymupdf as fitz

def _restaurar_cuadros_fijos(pagina):
    """Redibuja los cuadros fijos en su posición ORIGINAL (y1_original) tras la
    compactación, para que no queden desplazados por el arrastre de contenido."""
    if hasattr(pagina, '_cuadros_originales') and pagina._cuadros_originales:
        for cuadro_id, y1_orig in pagina._cuadros_originales.items():
            cuadro_fijo = None
            if hasattr(pagina, '_cuadros_fijos'):
                for c in pagina._cuadros_fijos:
                    if c.get('id') == cuadro_id:
                        cuadro_fijo = c
                        break
            if cuadro_fijo:
                r = cuadro_fijo['rect']
                color = cuadro_fijo['color']
                ancho = cuadro_fijo['width']
                r_orig = fitz.Rect(r.x0, r.y0, r.x1, y1_orig)
                try:
                    pagina.draw_rect(r_orig, color=color, width=ancho)
                except Exception:
                    pass
