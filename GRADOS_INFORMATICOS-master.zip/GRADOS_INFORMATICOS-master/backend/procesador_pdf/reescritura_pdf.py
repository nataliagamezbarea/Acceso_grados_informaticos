"""
Módulo de redacción, reescritura de enunciados y aplicación de cambios visuales
sobre PDFs.

ARCHIVO COMPATIBLE (shim): la implementación real está dividida por funciones en
el paquete backend/procesador_pdf/reescritura/ (tipografia, enunciados,
orquestador). Este archivo se mantiene para que TODOS los imports antiguos
siguan funcionando sin cambios.
"""

from backend.procesador_pdf.reescritura import (  # noqa: F401
    reescribir_y_limpiar_pdf,
    resaltar_documento_original,
    sustituir_enunciados_de_pagina,
    _detectar_fuente_equivalente,
    _fuente_solo_medidas,
    _insertar_linea_segura,
    _RW_DEBUG,
)

# Re-exportaciones históricas que este módulo ofrecía (definidas en ayudas_render)
from backend.procesador_pdf.ayudas_render import (  # noqa: F401
    compactar_huecos_blancos_pagina,
    obtener_color_fondo_rect,
)
