"""
Paquete modular Procesador PDF.
Exporta todas las funciones públicas de procesamiento, redacción, previsualización y Git.
"""

from backend.procesador_pdf.fuentes_y_texto import (
    _normalizar_nfc,
    mapear_fuente_estandar,
    extraer_buffer_fuente,
    preservar_prefijo_enunciado
)
from backend.procesador_pdf.busqueda_rectangulos import (
    buscar_rectangulos_nombres,
    buscar_rectangulos_colegio,
    extraer_lineas_pagina,
    buscar_rango_lineas_enunciado,
    extraer_texto_de_recuadro
)
from backend.procesador_pdf.reescritura_pdf import (
    resaltar_documento_original,
    reescribir_y_limpiar_pdf,
    compactar_huecos_blancos_pagina,
    obtener_color_fondo_rect
)
from backend.procesador_pdf.renderizado_cache import (
    obtener_previsualizacion,
    obtener_informacion_documento,
    generar_miniatura_bytes,
    purgar_imagenes_cache,
    limpiar_cache_pdf,
    precalentar_cache_segundo_plano
)
from backend.procesador_pdf.operaciones_git import (
    aplicar_cambios_rama_limpia,
    aplicar_cambios_un_archivo
)

__all__ = [
    "_normalizar_nfc",
    "mapear_fuente_estandar",
    "extraer_buffer_fuente",
    "preservar_prefijo_enunciado",
    "buscar_rectangulos_nombres",
    "buscar_rectangulos_colegio",
    "extraer_lineas_pagina",
    "buscar_rango_lineas_enunciado",
    "extraer_texto_de_recuadro",
    "resaltar_documento_original",
    "reescribir_y_limpiar_pdf",
    "compactar_huecos_blancos_pagina",
    "obtener_color_fondo_rect",
    "obtener_previsualizacion",
    "obtener_informacion_documento",
    "generar_miniatura_bytes",
    "purgar_imagenes_cache",
    "limpiar_cache_pdf",
    "aplicar_cambios_rama_limpia",
    "aplicar_cambios_un_archivo",
]
