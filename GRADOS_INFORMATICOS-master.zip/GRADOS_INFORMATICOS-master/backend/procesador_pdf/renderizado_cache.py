import os, tempfile, hashlib, math
import pymupdf as fitz
from backend.configuracion import DIRECTORIO_CACHE, DIRECTORIO_CACHE_IMAGENES
from backend.gestor_datos import (
    leer_archivo_original, cargar_reescrituras, cargar_revision,
    clave_registro
)
from backend.procesador_pdf.busqueda_rectangulos import (
    buscar_rectangulos_nombres, buscar_rectangulos_colegio,
    extraer_lineas_pagina
)

_DOC_INFO_MEM_CACHE = {}


def generar_clave_cache(grado, archivo, modo, hacer_enunciado=True, hacer_interior=True, hacer_colegio=True, hacer_internet=False):
    partes = [grado, archivo, modo]
    if hacer_enunciado: partes.append('enc')
    if hacer_interior: partes.append('int')
    if hacer_colegio: partes.append('col')
    if hacer_internet: partes.append('net')
    return hashlib.md5('|'.join(partes).encode('utf-8')).hexdigest()

_generar_clave_cache = generar_clave_cache


def generar_clave_memoria(grado, archivo, modo, hacer_enunciado, hacer_interior, hacer_colegio, hacer_internet):
    return (f"{grado}|{archivo}|{modo}|"
            f"{int(bool(hacer_enunciado))}|{int(bool(hacer_interior))}|"
            f"{int(bool(hacer_colegio))}|{int(bool(hacer_internet))}")


def limpiar_cache_memoria(grado=None, archivo=None):
    global _DOC_INFO_MEM_CACHE
    if grado and archivo:
        prefijo = f"{grado}|{archivo}|"
        claves_borrar = [k for k in _DOC_INFO_MEM_CACHE if k.startswith(prefijo)]
        for k in claves_borrar:
            _DOC_INFO_MEM_CACHE.pop(k, None)
    else:
        _DOC_INFO_MEM_CACHE.clear()


def obtener_previsualizacion(grado, archivo, modo, hacer_enunciado=True,
                             hacer_interior=True, hacer_colegio=True, hacer_internet=False):
    # No se cachea en disco (DIRECTORIO_CACHE). La previsualización 'new' se
    # entrega como bytes; así funciona igual en local y en serverless (Vercel),
    # donde el sistema de ficheros es de solo lectura.
    if modo == 'old': return None
    datos = leer_archivo_original(grado, archivo)
    if not datos: return None
    try:
        from backend.procesador_pdf import reescribir_y_limpiar_pdf
        rw_list = cargar_reescrituras(grado) or []
        item_rw = next((e for e in rw_list if os.path.basename(e.get('archivo', '')) == os.path.basename(archivo)), None)
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as tmp:
            tmp.write(datos)
            tmp_path = tmp.name
        try:
            reescribir_y_limpiar_pdf(
                tmp_path, archivo, item_reescritura=item_rw,
                limpiar_nombres=hacer_interior, limpiar_colegio=hacer_colegio,
                hacer_enunciado=hacer_enunciado, grado=grado, hacer_internet=hacer_internet
            )
            with open(tmp_path, 'rb') as f: return f.read()
        finally:
            try: os.unlink(tmp_path)
            except Exception: pass
    except Exception as exc:
        print(f'Error procesando PDF: {exc}')
        return datos


def _texto_en_rect(pagina, rect):
    try:
        palabras = []
        for w in pagina.get_text('words'):
            wx0, wy0, wx1, wy1, txt = w[:5]
            cx, cy = (wx0 + wx1) / 2.0, (wy0 + wy1) / 2.0
            if rect.x0 <= cx <= rect.x1 and rect.y0 <= cy <= rect.y1:
                palabras.append((cy, wx0, str(txt)))
        palabras.sort(key=lambda x: (x[0], x[1]))
        if not palabras: return ''
        lineas, actual, yref = [], [], None
        for cy, x0, txt in palabras:
            if yref is None or abs(cy - yref) <= 4.0:
                actual.append((x0, txt))
                yref = cy if yref is None else (yref + cy) / 2.0
            else:
                lineas.append(' '.join(t for _, t in sorted(actual)))
                actual, yref = [(x0, txt)], cy
        if actual: lineas.append(' '.join(t for _, t in sorted(actual)))
        return "\n".join(x for x in lineas if x.strip()).strip()
    except Exception:
        return ''


def _buscar_rect_fuzzy(pagina, texto, ref_y=None):
    if not texto or not texto.strip(): return None
    norm_obj = ''.join(c for c in texto.lower() if c.isalnum())
    if not norm_obj: return None

    matched_lines = []
    for b in pagina.get_text('dict').get('blocks', []):
        for l in b.get('lines', []):
            raw_txt = ''.join(s['text'] for s in l['spans']).strip()
            norm_l = ''.join(c for c in raw_txt.lower() if c.isalnum())
            if not norm_l: continue
            if (norm_l == norm_obj) or (norm_l in norm_obj) or (norm_obj in norm_l) or (texto.strip() in raw_txt) or (len(norm_l) >= 4 and norm_l[:4] in norm_obj):
                matched_lines.append((fitz.Rect(l['bbox']), norm_l))

    if not matched_lines: return None
    if ref_y is not None:
        matched_lines.sort(key=lambda item: abs(item[0].y0 - ref_y))

    total_rect, _ = matched_lines[0]
    changed = True
    while changed:
        changed = False
        for r_l, n_l in matched_lines:
            if (total_rect.y0 - 60.0 <= r_l.y1 and r_l.y0 <= total_rect.y1 + 80.0) and not total_rect.contains(r_l):
                total_rect = total_rect | r_l
                changed = True

    return total_rect


def obtener_informacion_documento(grado, archivo, modo='old', hacer_enunciado=True,
                                  hacer_interior=True, hacer_colegio=True, hacer_internet=False):
    cache_key = generar_clave_memoria(grado, archivo, modo, hacer_enunciado, hacer_interior, hacer_colegio, hacer_internet)
    if cache_key in _DOC_INFO_MEM_CACHE:
        return _DOC_INFO_MEM_CACHE[cache_key]

    datos = leer_archivo_original(grado, archivo)
    if not datos: return {'error': 'no_encontrado'}

    try:
        doc = fitz.open(stream=datos, filetype='pdf')
        doc_orig = None
        if modo == 'new':
            try:
                datos_new = obtener_previsualizacion(grado, archivo, 'new', hacer_enunciado, hacer_interior, hacer_colegio, hacer_internet)
                if datos_new: doc = fitz.open(stream=datos_new, filetype='pdf')
                doc_orig = fitz.open(stream=datos, filetype='pdf')
            except Exception: doc_orig = None

        rev = cargar_revision()
        datos_rev = rev.get(clave_registro(grado, archivo), {})
        rec_man = datos_rev.get('recuadros', {})
        acc_img = datos_rev.get('imagenes', {}) if isinstance(datos_rev, dict) else {}

        rw_list = cargar_reescrituras(grado) or []
        it_rw = next((e for e in rw_list if os.path.basename(e.get('archivo', '')) == os.path.basename(archivo)), None)

        paginas_info = []
        for pno in range(len(doc)):
            try:
                p = doc[pno]
            except Exception:
                continue
            pw, ph = p.rect.width, p.rect.height
            p_orig = doc_orig[pno] if doc_orig is not None and pno < len(doc_orig) else None
            
            # 1. Nombres
            n_hot = []
            if not (modo == 'new' and hacer_interior):
                for i, rect in enumerate(buscar_rectangulos_nombres(p)):
                    n_hot.append({
                        'id': f'name_{pno}_{i}', 'left': (rect.x0 / pw) * 100, 'top': (rect.y0 / ph) * 100,
                        'width': (rect.width / pw) * 100, 'height': (rect.height / ph) * 100,
                        'page_num': pno, 'text': _texto_en_rect(p, rect),
                    })
                man_nom = (rec_man.get('nombre', {}) or {}).get(str(pno)) if isinstance(rec_man, dict) else None
                if man_nom and isinstance(man_nom, dict) and 'coords' in man_nom:
                    c = man_nom['coords']
                    if len(c) >= 4 and all(math.isfinite(float(v)) for v in c[:4]):
                        n_hot.append({
                            'id': f'name_manual_{pno}', 'left': float(c[0]), 'top': float(c[1]),
                            'width': float(c[2]), 'height': float(c[3]),
                            'page_num': pno, 'text': man_nom.get('text', ''), 'manual': True
                        })
            
            # 2. Colegios
            c_hot = []
            if not (modo == 'new' and hacer_colegio):
                for i, rect in enumerate(buscar_rectangulos_colegio(p, es_portada=(pno == 0))):
                    c_hot.append({
                        'id': f'school_{pno}_{i}', 'left': (rect.x0 / pw) * 100, 'top': (rect.y0 / ph) * 100,
                        'width': (rect.width / pw) * 100, 'height': (rect.height / ph) * 100,
                        'page_num': pno, 'text': _texto_en_rect(p, rect),
                    })
                man_col = (rec_man.get('colegio', {}) or {}).get(str(pno)) if isinstance(rec_man, dict) else None
                if man_col and isinstance(man_col, dict) and 'coords' in man_col:
                    c = man_col['coords']
                    if len(c) >= 4 and all(math.isfinite(float(v)) for v in c[:4]):
                        c_hot.append({
                            'id': f'school_manual_{pno}', 'left': float(c[0]), 'top': float(c[1]),
                            'width': float(c[2]), 'height': float(c[3]),
                            'page_num': pno, 'text': man_col.get('text', ''), 'manual': True
                        })
            
            # 3. Enunciados
            s_hot = []
            if it_rw:
                for idx_enc, enc in enumerate(it_rw.get('enunciados', [])):
                    if int(enc.get('page', 0)) != pno: continue
                    txt_new, txt_orig = str(enc.get('new', '') or ''), str(enc.get('start', '') or '')
                    if modo == 'new' and (not enc.get('include', True) or not txt_new.strip()):
                        continue
                    txt_busca = txt_new if (modo == 'new' and txt_new.strip()) else txt_orig
                    rect_total = None
                    ref_y = ((float(enc['pct_top'] or enc['top']) / 100.0) * ph) if (enc.get('pct_top') is not None or enc.get('top') is not None) else None
                    if modo == 'new' and txt_new.strip():
                        rect_total = _buscar_rect_fuzzy(p, txt_new, ref_y=ref_y)
                    elif 'left' in enc and 'top' in enc and float(enc.get('width', 0) or 0) > 0:
                        s_hot.append({
                            'id': enc.get('id', idx_enc), 'left': float(enc['left']), 'top': float(enc['top']),
                            'width': float(enc.get('width', 90.0)), 'height': float(enc.get('height', 7.5)),
                            'start': enc.get('start', ''), 'end': enc.get('end', ''), 'new': enc.get('new', ''),
                            'include': bool(enc.get('include', True)), 'custom': bool(enc.get('custom', False)), 'page': pno,
                        })
                        continue
                    elif txt_busca:
                        pag_src = p_orig if (modo == 'new' and not enc.get('include', True) and p_orig) else p
                        try:
                            for x in pag_src.search_for(txt_busca):
                                rect_total = x if rect_total is None else (rect_total | x)
                        except Exception: pass
                        if rect_total is None or rect_total.is_empty:
                            rect_total = _buscar_rect_fuzzy(pag_src, txt_busca)
                    
                    if rect_total is not None and not rect_total.is_empty:
                        r_pad = fitz.Rect(max(0.0, rect_total.x0 - 4.0), max(0.0, rect_total.y0 - 1.0),
                                          min(pw, rect_total.x1 + 4.0), min(ph, rect_total.y1 + 1.0))
                        nl, nt = (r_pad.x0 / pw) * 100.0, (r_pad.y0 / ph) * 100.0
                        nw, nh = (r_pad.width / pw) * 100.0, (r_pad.height / ph) * 100.0
                    else:
                        nt = float(enc.get('pct_top') or enc.get('top') or 5.0)
                        nl = float(enc.get('left') or 5.0)
                        nw = float(enc.get('width') or 90.0)
                        nh = float(enc.get('height') or 7.5)

                    if not any(abs(sh['left'] - nl) < 1.0 and abs(sh['top'] - nt) < 1.0 for sh in s_hot):
                        s_hot.append({
                            'id': enc.get('id', idx_enc), 'left': nl, 'top': nt,
                            'width': nw, 'height': nh,
                            'start': enc.get('start', ''), 'end': enc.get('end', ''), 'new': enc.get('new', ''),
                            'include': bool(enc.get('include', True)), 'custom': bool(enc.get('custom', False)), 'page': pno,
                        })

            # 4. Imagenes
            i_hot = []
            try:
                for idx_img, info_img in enumerate(p.get_image_info()):
                    bbox = info_img.get('bbox')
                    if bbox:
                        r = fitz.Rect(bbox)
                        if r.width > 5 and r.height > 5:
                            xref = info_img.get('xref', 0)
                            img_id = f'p{pno}_x{xref}' if xref else f'p{pno}_img{idx_img}'
                            acc_info = (acc_img.get(img_id) or acc_img.get(f'p{pno}_img{idx_img}') or {})
                            i_hot.append({
                                'id': img_id, 'left': (r.x0 / pw) * 100.0, 'top': (r.y0 / ph) * 100.0,
                                'width': (r.width / pw) * 100.0, 'height': (r.height / ph) * 100.0,
                                'page_num': pno, 'img_idx': idx_img, 'xref': xref,
                                'accion': acc_info.get('accion', ''), 'cita': acc_info.get('cita', ''),
                            })
            except Exception: pass

            # 5. Inicio de Reflujo
            ref_hot = []
            ini_ref = datos_rev.get('inicio_reflujo') if isinstance(datos_rev, dict) else None
            if ini_ref and int(ini_ref.get('page', -1)) == pno:
                ref_hot.append({
                    'id': f'reflow_{pno}',
                    'left': float(ini_ref.get('left', 5.0)),
                    'top': float(ini_ref.get('top', 10.0)),
                    'width': float(ini_ref.get('width', 90.0)),
                    'height': float(ini_ref.get('height', 8.0)),
                    'page_num': pno,
                })

            l_spans = []
            if pno < 3 or s_hot:
                for x0, y0, x1, y1, texto, _ in extraer_lineas_pagina(p):
                    l_spans.append({
                        'left': (x0 / pw) * 100, 'top': (y0 / ph) * 100,
                        'width': ((x1 - x0) / pw) * 100, 'height': ((y1 - y0) / ph) * 100,
                        'text': texto
                    })

            paginas_info.append({
                'page_num': pno, 'name_hotspots': n_hot, 'school_hotspots': c_hot,
                'statement_hotspots': s_hot, 'image_hotspots': i_hot,
                'reflow_hotspots': ref_hot,
                'hotspot': s_hot[0] if s_hot else None, 'line_spans': l_spans,
                'width': pw, 'height': ph,
            })

        info = {
            'paginas': doc.page_count, 'titulo': doc.metadata.get('title', ''),
            'autor': doc.metadata.get('author', ''), 'creado': doc.metadata.get('creationDate', ''),
            'pages': paginas_info
        }
        doc.close()
        if doc_orig:
            try: doc_orig.close()
            except Exception: pass
        _DOC_INFO_MEM_CACHE[cache_key] = info
        return info
    except Exception as exc:
        import traceback; traceback.print_exc()
        return {'error': 'pdf_invalido'}


def generar_miniatura_bytes(grado, rel_path):
    datos = leer_archivo_original(grado, os.path.basename(rel_path))
    if not datos: return None
    try:
        doc = fitz.open(stream=datos, filetype='pdf')
        if doc.page_count == 0:
            doc.close()
            return None
        pagina = doc[0]
        pix = pagina.get_pixmap(matrix=fitz.Matrix(0.5, 0.5))
        png_bytes = pix.tobytes('png')
        doc.close()
        return png_bytes
    except Exception:
        return None


def purgar_imagenes_cache():
    if not os.path.exists(DIRECTORIO_CACHE_IMAGENES): return 0
    eliminados = 0
    try:
        for fn in os.listdir(DIRECTORIO_CACHE_IMAGENES):
            ruta = os.path.join(DIRECTORIO_CACHE_IMAGENES, fn)
            if os.path.isfile(ruta):
                os.remove(ruta)
                eliminados += 1
    except Exception: pass
    return eliminados


def limpiar_cache_pdf(grado=None, archivo=None):
    limpiar_cache_memoria(grado, archivo)
    if os.path.exists(DIRECTORIO_CACHE):
        try:
            for fn in os.listdir(DIRECTORIO_CACHE):
                ruta = os.path.join(DIRECTORIO_CACHE, fn)
                if os.path.isfile(ruta) and fn.endswith('.pdf'):
                    try: os.remove(ruta)
                    except Exception: pass
        except Exception: pass
    if os.path.exists(DIRECTORIO_CACHE_IMAGENES):
        try:
            for fn in os.listdir(DIRECTORIO_CACHE_IMAGENES):
                ruta = os.path.join(DIRECTORIO_CACHE_IMAGENES, fn)
                if os.path.isfile(ruta):
                    try: os.remove(ruta)
                    except Exception: pass
        except Exception: pass


def precalentar_cache_segundo_plano():
    pass
