import os
from backend.configuracion import CONFIGURACION_GRADOS
from backend.procesador_pdf.operaciones_git.aplicar_logica_archivo import _aplicar_logica_archivo
from backend.procesador_pdf.operaciones_git.commit_git import _commit_git, _push_git
from backend.procesador_pdf.renderizado_cache import limpiar_cache_pdf

def aplicar_cambios_un_archivo(grado, archivo, subir_github=False):
    """Aplica los cambios confirmados a un único archivo (apunte o normal).

    Si subir_github=True, además de confirmar el commit local se intenta
    hacer 'git push' de la rama actual al remoto (GitHub).
    """
    if not grado or grado not in CONFIGURACION_GRADOS:
        return False, "Grado no especificado o inválido"
    fname = os.path.basename(archivo)
    res = _aplicar_logica_archivo(grado, fname)
    if res["ok"]:
        limpiar_cache_pdf(grado, fname)
        _commit_git(grado, f"Aplicar cambios: {fname}")
        if subir_github:
            push_ok, push_msg = _push_git(grado)
            if not push_ok:
                return True, f"{res.get('msg', '')} (aviso: no se pudo subir a GitHub: {push_msg})"
    return res["ok"], res.get("msg", "")
