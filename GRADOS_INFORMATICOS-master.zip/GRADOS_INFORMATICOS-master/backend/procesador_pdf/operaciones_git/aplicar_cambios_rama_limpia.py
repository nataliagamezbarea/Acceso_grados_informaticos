import os

from backend.configuracion import CONFIGURACION_GRADOS
from backend.procesador_pdf.operaciones_git.aplicar_logica_archivo import _aplicar_logica_archivo
from backend.procesador_pdf.operaciones_git.commit_git import _commit_git
from backend.procesador_pdf.renderizado_cache import limpiar_cache_pdf

def aplicar_cambios_rama_limpia(grado):
    """Aplica los cambios confirmados de todos los archivos del grado sobre GI."""
    if not grado or grado not in CONFIGURACION_GRADOS:
        return False, "Grado no especificado o inválido"
    dir_repo = CONFIGURACION_GRADOS[grado]["directorio"]

    todos = []
    for raiz, _, archivos in os.walk(dir_repo):
        if '.git' in raiz: continue
        for f in archivos:
            if f.lower().endswith(".pdf"):
                todos.append(f)

    apuntes_ok = 0
    reemplazados = 0
    renombrados = 0
    errores = []

    for fname in sorted(set(todos)):
        res = _aplicar_logica_archivo(grado, fname)
        if not res["ok"]:
            errores.append(res.get("msg", fname))
            continue
        if res["tipo"] == "apunte":
            apuntes_ok += 1
        else:
            if res.get("modificado"): reemplazados += 1
            if res.get("renombrado"): renombrados += 1
        limpiar_cache_pdf(grado, fname)

    _commit_git(grado, f"Aplicar cambios confirmados en {grado}")

    msg = (
        f"Cambios aplicados sobre GI/{grado}:\n"
        f"- Apuntes guardados en apuntes/: {apuntes_ok}\n"
        f"- Originales reemplazados: {reemplazados}\n"
        f"- Renombrados: {renombrados}"
    )
    if errores:
        msg += "\n- Avisos: " + "; ".join(errores[:5])
    return True, msg
