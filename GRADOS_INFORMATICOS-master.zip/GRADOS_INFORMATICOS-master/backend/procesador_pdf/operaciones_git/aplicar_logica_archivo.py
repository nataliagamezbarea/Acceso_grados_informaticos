import os
import shutil
import tempfile

from backend.configuracion import CONFIGURACION_GRADOS
from backend.gestor_datos import (
    leer_archivo_original, limpiar_nombre_archivo,
    cargar_revision, cargar_reescrituras, clave_registro
)
from backend.generador_apuntes import (
    sincronizar_registro_csv, preparar_apunte,
    generar_propuesta_nombre_apunte, limpiar_nombre_apunte
)
from backend.procesador_pdf.reescritura_pdf import reescribir_y_limpiar_pdf
from backend.procesador_pdf.operaciones_git.localizar_archivo_repo import _localizar_archivo_repo

def _aplicar_logica_archivo(grado, fname):
    """Aplica los cambios confirmados de un archivo según su tipo.
    Devuelve un dict: {tipo, ok, msg, modificado, renombrado}."""
    dir_repo = CONFIGURACION_GRADOS[grado]["directorio"]
    rev = cargar_revision()
    rw_mapa = {os.path.basename(x["archivo"]): x for x in cargar_reescrituras(grado)}
    item_rw = rw_mapa.get(fname)
    info_r = rev.get(clave_registro(grado, fname), {})
    es_apunte = bool(info_r.get("inc_apunte", False))

    if es_apunte:
        nombre_apunte = limpiar_nombre_apunte(info_r.get("nombre_apunte") or generar_propuesta_nombre_apunte(fname))
        # Entrega: copia TAL CUAL del PDF original en GI/<grado>/apuntes/ (su nombre).
        # El PDF APUNTE_* de LaTeX solo se genera en el flujo propio del TXT.
        destino = preparar_apunte(grado, fname, nombre_apunte, hacia_gi=True)
        if not destino:
            return {"tipo": "apunte", "ok": False, "msg": f"No se pudo copiar el PDF original de '{fname}'"}
        sincronizar_registro_csv(grado, fname, fname, es_apunte=True, nombre_apunte=nombre_apunte, apunte_compilado=True)
        return {"tipo": "apunte", "ok": True, "msg": f"Apunte guardado en apuntes/{os.path.basename(destino)}"}

    # No es apunte: limpiar y REEMPLAZAR el PDF original
    hacer_enc = bool(item_rw.get("include", True)) if item_rw else False
    hacer_nom = bool(info_r.get("inc_interior", False))
    hacer_col = bool(info_r.get("inc_colegio", True))
    hacer_ren = bool(info_r.get("inc_nombre", False))

    ruta_real = _localizar_archivo_repo(dir_repo, fname)
    if not ruta_real:
        return {"tipo": "archivo", "ok": False, "msg": f"'{fname}' no encontrado en el repositorio"}

    rel_real = os.path.relpath(ruta_real, dir_repo)
    datos = leer_archivo_original(grado, rel_real)
    if not datos:
        try: datos = open(ruta_real, "rb").read()
        except Exception: datos = None
    if not datos:
        return {"tipo": "archivo", "ok": False, "msg": f"Sin contenido para '{fname}'"}

    modificado = False
    if hacer_enc or hacer_nom or hacer_col:
        fd, tmp_pdf = tempfile.mkstemp(suffix=".pdf")
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(datos)
            ok = reescribir_y_limpiar_pdf(
                tmp_pdf, fname, item_reescritura=item_rw,
                limpiar_nombres=hacer_nom, limpiar_colegio=hacer_col,
                hacer_enunciado=hacer_enc, grado=grado
            )
            if ok:
                shutil.copy(tmp_pdf, ruta_real)
                modificado = True
        finally:
            try: os.remove(tmp_pdf)
            except Exception: pass

    nombre_final = fname
    if hacer_ren:
        nombre_limpio = limpiar_nombre_archivo(fname)
        if nombre_limpio != fname:
            nueva_ruta = os.path.join(os.path.dirname(ruta_real), nombre_limpio)
            try:
                os.replace(ruta_real, nueva_ruta)
                nombre_final = nombre_limpio
            except Exception:
                pass

    sincronizar_registro_csv(grado, fname, nombre_final, es_apunte=False)
    return {
        "tipo": "archivo", "ok": True,
        "msg": f"Original reemplazado ({fname})",
        "modificado": modificado, "renombrado": nombre_final != fname
    }
