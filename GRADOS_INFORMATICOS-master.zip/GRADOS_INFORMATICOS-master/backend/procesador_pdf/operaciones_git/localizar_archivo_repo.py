import os

def _localizar_archivo_repo(dir_repo, fname):
    for raiz, _, archivos in os.walk(dir_repo):
        if '.git' in raiz: continue
        if fname in archivos:
            return os.path.join(raiz, fname)
    return None
