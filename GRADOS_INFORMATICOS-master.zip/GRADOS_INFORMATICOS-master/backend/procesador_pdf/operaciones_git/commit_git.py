import subprocess

from backend.configuracion import CONFIGURACION_GRADOS

def _commit_git(grado, mensaje):
    """Commit de seguridad en la rama actual y actualización de la rama limpia."""
    cfg = CONFIGURACION_GRADOS[grado]
    dir_repo = cfg["directorio"]
    try:
        res = subprocess.run(["git", "-C", dir_repo, "status", "--porcelain"], capture_output=True, text=True)
        if res.returncode == 0 and not res.stdout.strip():
            return
        subprocess.run(["git", "-C", dir_repo, "add", "-A"], capture_output=True)
        subprocess.run(["git", "-C", dir_repo, "commit", "-m", mensaje], capture_output=True)
        subprocess.run(["git", "-C", dir_repo, "branch", "-f", cfg["rama_limpia"], "HEAD"], capture_output=True)
    except Exception:
        pass


def _push_git(grado):
    """Sube (git push) la rama actual del repositorio local del grado al remoto (GitHub)."""
    cfg = CONFIGURACION_GRADOS[grado]
    dir_repo = cfg["directorio"]
    try:
        rama_actual = subprocess.run(
            ["git", "-C", dir_repo, "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True
        ).stdout.strip()
        if not rama_actual or rama_actual == "HEAD":
            return False, "No se pudo determinar la rama actual"
        res = subprocess.run(
            ["git", "-C", dir_repo, "push", "origin", rama_actual],
            capture_output=True, text=True
        )
        if res.returncode == 0:
            return True, "Subido correctamente"
        return False, (res.stderr or res.stdout or "Error desconocido al hacer push").strip()
    except Exception as e:
        return False, str(e)
