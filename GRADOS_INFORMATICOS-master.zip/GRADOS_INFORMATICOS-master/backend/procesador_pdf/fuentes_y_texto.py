"""
Módulo de procesamiento tipográfico y de fuentes PDF.
"""

import re
import unicodedata
import pymupdf as fitz

def _normalizar_nfc(texto):
    """Normaliza texto a forma NFC de Unicode."""
    return unicodedata.normalize("NFC", texto or "")

def mapear_fuente_estandar(nombre_fuente, banderas):
    """Mapea fuentes PDF a familias tipográficas base estándar."""
    fn = (nombre_fuente or "").lower()
    es_negrita = ("bold" in fn) or bool(banderas & 16) or bool(banderas & 4) or bool(banderas & 2)
    es_cursiva = ("italic" in fn) or ("oblique" in fn)
    if any(s in fn for s in ["times", "georgia", "serif", "cambria", "garamond"]):
        if es_negrita and es_cursiva: return "times-bolditalic"
        if es_negrita: return "times-bold"
        if es_cursiva: return "times-italic"
        return "times-roman"
    # IMPORTANTE: usar solo nombres de familias monoespaciadas REALES, no una
    # subcadena genérica "code" (eso hacía que fuentes normales como "Encode Sans"
    # se detectaran como monoespaciadas/código por error, dando un texto verde
    # con pinta de código que no tiene nada que ver con el enunciado original).
    familias_monoespaciadas = [
        "courier", "consolas", "monaco", "menlo", "ubuntu mono", "roboto mono",
        "source code pro", "fira code", "jetbrains mono", "dejavu sans mono",
        "liberation mono", "pt mono", "inconsolata", "space mono", "ibm plex mono"
    ]
    if any(s in fn for s in familias_monoespaciadas) or fn.strip() in ("mono", "monospace"):
        if es_negrita: return "cobo"
        return "cour"
    else:
        if es_negrita and es_cursiva: return "hebi"
        if es_negrita: return "hebo"
        if es_cursiva: return "heit"
        return "helv"

def extraer_buffer_fuente(doc, num_pagina, nombre_fuente_objetivo):
    """Extrae el búfer de fuente incrustada para mantener la tipografía original."""
    fuentes = doc.get_page_fonts(num_pagina)
    tfn = (nombre_fuente_objetivo or "").lower()
    for f in fuentes:
        xref = f[0]
        fname = f[3].lower()
        if tfn in fname or fname.split("+")[-1] in tfn:
            try:
                buf = doc.extract_font(xref)[3]
                if buf: return buf
            except Exception:
                pass
    return None

def preservar_prefijo_enunciado(inicio, nuevo_texto):
    """Preserva prefijos numerados como '1)', 'Ejercicio 2:', etc."""
    if not inicio or not nuevo_texto: return nuevo_texto
    pat = r"^(\s*(?:Actividad|Ejercicio|Práctica|Practica|Pregunta|Task|Q|\d+|[a-z])\s*[\d\.\)\-:]*\s*)"
    m = re.match(pat, inicio.strip(), re.IGNORECASE)
    if m and not re.match(pat, nuevo_texto.strip(), re.IGNORECASE):
        return m.group(1) + nuevo_texto.strip()
    return nuevo_texto
