import pymupdf as fitz

from backend.procesador_pdf.fuentes_y_texto import _normalizar_nfc

def extraer_lineas_pagina(pagina):
    """Extrae las líneas con sus coordenadas bbox e información de spans."""
    lineas = []
    d = pagina.get_text("dict")
    for b in d.get("blocks", []):
        for l in b.get("lines", []):
            spans = l.get("spans", [])
            txt = "".join(s.get("text", "") for s in spans)
            txt_norm = _normalizar_nfc(txt).strip()
            if txt_norm:
                lineas.append((l["bbox"][0], l["bbox"][1], l["bbox"][2], l["bbox"][3], txt_norm, spans))
    return lineas
