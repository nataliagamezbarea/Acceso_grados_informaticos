import os
import tempfile
import pymupdf as fitz

from backend.gestor_datos import leer_archivo_original

def extraer_texto_de_recuadro(grado, archivo, num_pagina, pct_left, pct_top, pct_width, pct_height):
    """Extrae el texto delimitado por un recuadro porcentual dibujado en la UI.

    EXACTITUD: no se usa get_text(clip=...) porque PyMuPDF incluye CUALQUIER línea
    cuyo bbox roce el recuadro (p.ej. la primera fila de una tabla justo debajo o al
    lado, aunque el usuario no la haya seleccionado). En su lugar se trabaja palabra
    a palabra: solo se aceptan palabras cuyo CENTRO cae dentro del recuadro exacto
    dibujado (sin margen añadido) y se reconstruyen las líneas ordenadas por posición.
    """
    datos = leer_archivo_original(grado, f"archivos/{archivo}") or leer_archivo_original(grado, archivo)
    if not datos: return ""
    tf_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tf:
            tf.write(datos)
            tf_path = tf.name
        
        doc = fitz.open(tf_path)
        if num_pagina < 0 or num_pagina >= len(doc):
            doc.close()
            if os.path.exists(tf_path): os.remove(tf_path)
            return ""
        
        pagina = doc[num_pagina]
        pw, ph = pagina.rect.width, pagina.rect.height
        x0 = (float(pct_left) / 100.0) * pw
        y0 = (float(pct_top) / 100.0) * ph
        x1 = x0 + (float(pct_width) / 100.0) * pw
        y1 = y0 + (float(pct_height) / 100.0) * ph
        
        rect = fitz.Rect(min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1))
        
        # Palabras dentro del recuadro: SOLO si su centro está dentro (exacto).
        palabras_dentro = []
        for w in pagina.get_text("words"):
            wx0, wy0, wx1, wy1, texto = w[0], w[1], w[2], w[3], w[4]
            cx, cy = (wx0 + wx1) / 2.0, (wy0 + wy1) / 2.0
            if rect.x0 <= cx <= rect.x1 and rect.y0 <= cy <= rect.y1:
                palabras_dentro.append((wy0, wy1, wx0, texto))
        
        # Reconstruir líneas: dos palabras son la MISMA línea si sus centros verticales
        # están a menos de media altura de fuente de distancia (robusto para cualquier
        # tamaño de letra); dentro de la línea se ordenan por posición horizontal.
        palabras_dentro.sort(key=lambda t: ((t[0] + t[1]) / 2.0, t[2]))
        lineas = []
        linea_actual = []
        y_ref = None
        alto_ref = 0.0
        for wy0, wy1, wx0, texto in palabras_dentro:
            cy = (wy0 + wy1) / 2.0
            alto = max(2.0, wy1 - wy0)
            if y_ref is None or abs(cy - y_ref) <= max(alto, alto_ref) * 0.6:
                linea_actual.append((wx0, texto))
                y_ref = cy if y_ref is None else (y_ref + cy) / 2.0
                alto_ref = max(alto_ref, alto)
            else:
                lineas.append(linea_actual)
                linea_actual = [(wx0, texto)]
                y_ref = cy
                alto_ref = alto
        if linea_actual:
            lineas.append(linea_actual)
        
        partes = [" ".join(t for _, t in sorted(l, key=lambda p: p[0])) for l in lineas]
        txt = "\n".join(p for p in partes if p.strip())
        doc.close()
        if os.path.exists(tf_path): os.remove(tf_path)
        return txt.strip()
    except Exception:
        if tf_path and os.path.exists(tf_path):
            try: os.remove(tf_path)
            except Exception: pass
        return ""
