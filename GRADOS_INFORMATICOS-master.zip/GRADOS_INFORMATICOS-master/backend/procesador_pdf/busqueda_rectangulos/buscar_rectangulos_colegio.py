import unicodedata
import pymupdf as fitz

from backend.configuracion import PALABRAS_CLAVE_COLEGIO
from backend.configuracion.normalizar_palabra import normalizar_palabra


_VARIANTES_COLEGIO = tuple(PALABRAS_CLAVE_COLEGIO)


def _sin_tildes(texto):
    return "".join(
        c for c in unicodedata.normalize("NFD", texto or "")
        if unicodedata.category(c) != "Mn"
    )


def _buscar_texto_colegio(pagina):
    """Devuelve el bbox de la MENCION del colegio, no el bloque completo.

    Antes se usaba get_text('blocks') y se devolvía todo el bloque. Si una
    mención como 'SAN JOSÉ OBRERO' estaba dentro de un recuadro grande con
    fechas, curso, asignatura, etc., el hotspot morado cubría TODO ese recuadro
    y la redacción podía borrar contenido que no correspondía.
    """
    rectangulos = []
    vistos = set()
    for texto in _VARIANTES_COLEGIO:
        texto = str(texto or "").strip()
        if not texto:
            continue
        variantes = {texto, _sin_tildes(texto)}
        for variante in variantes:
            try:
                encontrados = pagina.search_for(variante, quads=False)
            except Exception:
                encontrados = []
            for r0 in encontrados:
                try:
                    r = fitz.Rect(r0)
                except Exception:
                    continue
                if r.width <= 0 or r.height <= 0:
                    continue
                # Pequeño margen visual, sin abarcar el bloque de texto entero.
                r = fitz.Rect(r.x0 - 2, r.y0 - 1, r.x1 + 2, r.y1 + 1)
                clave = tuple(round(v, 2) for v in (r.x0, r.y0, r.x1, r.y1))
                if clave not in vistos:
                    vistos.add(clave)
                    rectangulos.append(r)
    return rectangulos


def buscar_rectangulos_colegio(pagina, es_portada=False):
    """Encuentra menciones del colegio y el logotipo institucional.

    La parte textual se limita a la frase detectada. El logo de portada se
    añade por separado y solo si existe realmente una mención textual del
    colegio en esa portada.
    """
    rectangulos = _buscar_texto_colegio(pagina)
    tiene_texto_colegio = bool(rectangulos)

    if es_portada and tiene_texto_colegio:
        for img in pagina.get_images():
            try:
                for r0 in pagina.get_image_rects(img[0]):
                    r = fitz.Rect(r0)
                    es_cabecera = r.y0 < 130 and r.y1 < 220
                    es_tamano_logo = 20 < r.width < 280 and 20 < r.height < 120
                    if es_cabecera and es_tamano_logo:
                        clave = tuple(round(v, 2) for v in (r.x0, r.y0, r.x1, r.y1))
                        if not any(tuple(round(v, 2) for v in (x.x0, x.y0, x.x1, x.y1)) == clave for x in rectangulos):
                            rectangulos.append(r)
            except Exception:
                pass

    return rectangulos
