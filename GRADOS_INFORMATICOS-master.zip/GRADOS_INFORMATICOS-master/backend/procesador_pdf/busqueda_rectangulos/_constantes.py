_PALABRAS_VACIAS = {"de","la","el","los","las","un","una","unos","unas","y","o","u","a","en","que","con","por","para","del","al","lo","su","sus","es","son","se","le","les","ha","he","hi","hay"}
