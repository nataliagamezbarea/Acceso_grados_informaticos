from backend.procesador_pdf.busqueda_rectangulos._constantes import _PALABRAS_VACIAS
from backend.procesador_pdf.busqueda_rectangulos.buscar_rectangulos_nombres import buscar_rectangulos_nombres
from backend.procesador_pdf.busqueda_rectangulos.buscar_rectangulos_colegio import buscar_rectangulos_colegio
from backend.procesador_pdf.busqueda_rectangulos.extraer_lineas_pagina import extraer_lineas_pagina
from backend.procesador_pdf.busqueda_rectangulos.coincidencia_suficiente import _coincidencia_suficiente
from backend.procesador_pdf.busqueda_rectangulos.buscar_rango_lineas_enunciado import buscar_rango_lineas_enunciado
from backend.procesador_pdf.busqueda_rectangulos.extraer_texto_de_recuadro import extraer_texto_de_recuadro

__all__ = [
    "_PALABRAS_VACIAS",
    "buscar_rectangulos_nombres",
    "buscar_rectangulos_colegio",
    "extraer_lineas_pagina",
    "_coincidencia_suficiente",
    "buscar_rango_lineas_enunciado",
    "extraer_texto_de_recuadro",
]
