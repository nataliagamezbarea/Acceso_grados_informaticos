import re
import pymupdf as fitz

from backend.configuracion import NOMBRES_COMPLETOS, normalizar_palabra


def _tokens_nombre(nombre):
    return [normalizar_palabra(x) for x in re.split(r"\s+", str(nombre or "").strip()) if normalizar_palabra(x)]

# Precalcular tokens de nombres
_TOKENS_NOMBRES = [(n, _tokens_nombre(n)) for n in NOMBRES_COMPLETOS if _tokens_nombre(n)]

def buscar_rectangulos_nombres(pagina):
    """Busca los rectángulos de nombres extrayendo palabras una sola vez por página."""
    try:
        raw = pagina.get_text("words")
    except Exception:
        raw = []
    if not raw:
        return []

    palabras = []
    for w in raw:
        if len(w) < 5:
            continue
        texto = normalizar_palabra(w[4])
        if not texto:
            continue
        palabras.append({
            "x0": float(w[0]), "y0": float(w[1]),
            "x1": float(w[2]), "y1": float(w[3]),
            "txt": texto,
            "block": int(w[5]) if len(w) > 5 else -1,
            "line": int(w[6]) if len(w) > 6 else -1,
        })

    rects = []
    for _, objetivo in _TOKENS_NOMBRES:
        n = len(objetivo)
        for i in range(len(palabras)):
            if palabras[i]["txt"] != objetivo[0]:
                continue
            ultimo = palabras[i]
            grupo = [ultimo]
            for j in range(1, n):
                for k in range(i + j, min(len(palabras), i + j + 8)):
                    w = palabras[k]
                    if w["block"] == ultimo["block"] and w["line"] == ultimo["line"] and w["txt"] == objetivo[j]:
                        grupo.append(w)
                        ultimo = w
                        break
            if len(grupo) == n:
                rects.append(fitz.Rect(
                    min(p["x0"] for p in grupo),
                    min(p["y0"] for p in grupo),
                    max(p["x1"] for p in grupo),
                    max(p["y1"] for p in grupo)
                ))

    rects_dedup = []
    rects.sort(key=lambda r: r.width * r.height, reverse=True)
    for r in rects:
        if any(r.intersects(e) and (r & e).get_area() > 0.6 * r.get_area() for e in rects_dedup):
            continue
        rects_dedup.append(r)
    return rects_dedup

