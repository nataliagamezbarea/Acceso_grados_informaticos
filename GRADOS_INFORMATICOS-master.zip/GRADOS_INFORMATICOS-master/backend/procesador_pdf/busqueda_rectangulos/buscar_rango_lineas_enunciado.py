import re

from backend.procesador_pdf.fuentes_y_texto import _normalizar_nfc
from backend.procesador_pdf.busqueda_rectangulos.coincidencia_suficiente import _coincidencia_suficiente

def buscar_rango_lineas_enunciado(lineas, inicio, fin, ref_y=None):
    """Localiza de forma precisa el rango de líneas [i_s, i_e] de un enunciado.
    Matching estricto pero bidireccional; si se indica ref_y (posición real de la
    selección del usuario), elige SIEMPRE el candidato más cercano a esa posición."""
    if not lineas or not inicio: return None, None
    st_limpio = _normalizar_nfc(inicio.strip())
    st_lineas = [l.strip() for l in st_limpio.split("\n") if l.strip()]
    palabras = [w for w in re.split(r"\s+", st_limpio) if len(w) > 1]
    if not palabras: return None, None
    
    # 1. Coincidencia directa sustancial con la primera línea del enunciado
    candidatos = [i for i, l in enumerate(lineas) if _coincidencia_suficiente(l[4], primera_linea_st := (st_lineas[0] if st_lineas else st_limpio))]
            
    # 2. Respaldo: prefijo de palabras o normalización alfanumérica
    if not candidatos:
        for longitud in range(min(8, len(palabras)), 2, -1):
            trozo = " ".join(palabras[:longitud])
            if len(trozo) < 18: continue
            candidatos = [i for i, l in enumerate(lineas) if trozo in l[4]]
            if candidatos: break

    if not candidatos:
        st_alnum = re.sub(r'[^A-Z0-9]', '', st_limpio.upper())
        for i, l in enumerate(lineas):
            l_alnum = re.sub(r'[^A-Z0-9]', '', l[4].upper())
            if l_alnum and (l_alnum in st_alnum or st_alnum.startswith(l_alnum)):
                candidatos.append(i)

    if not candidatos: return None, None
    
    if ref_y is not None and len(candidatos) > 1:
        i_s = min(candidatos, key=lambda i: abs(lineas[i][1] - ref_y))
    else:
        i_s = candidatos[0]
    
    i_e = i_s
    fin_limpio = _normalizar_nfc((fin or "").strip())
    
    if not fin_limpio or fin_limpio == st_limpio:
        if len(st_lineas) > 1:
            ultima_linea_st = st_lineas[-1]
            for i in range(i_s, min(len(lineas), i_s + len(st_lineas) + 2)):
                if _coincidencia_suficiente(lineas[i][4], ultima_linea_st):
                    i_e = i
                    break
        else:
            # Si el string de inicio no tiene saltos explícitos pero abarca múltiples líneas físicas:
            st_normal = " ".join(st_limpio.split())
            texto_acum = lineas[i_s][4].strip()
            if not _coincidencia_suficiente(texto_acum, st_normal):
                for i in range(i_s + 1, min(len(lineas), i_s + 8)):
                    sig_linea = lineas[i][4].strip()
                    cand_acum = " ".join((texto_acum + " " + sig_linea).split())
                    if cand_acum in st_normal or st_normal.startswith(cand_acum):
                        texto_acum = cand_acum
                        i_e = i
                        if _coincidencia_suficiente(cand_acum, st_normal):
                            break
                    else:
                        break
    else:
        ed_lineas = [l.strip() for l in fin_limpio.split("\n") if l.strip()]
        ultima_linea_ed = ed_lineas[-1] if ed_lineas else fin_limpio
        for i in range(i_s, min(len(lineas), i_s + 15)):
            if _coincidencia_suficiente(lineas[i][4], ultima_linea_ed):
                i_e = i
                break
            palabras_ed = [w for w in re.split(r"\s+", ultima_linea_ed) if len(w) > 1]
            if len(palabras_ed) >= 3:
                trozo = " ".join(palabras_ed[-3:])
                if len(trozo) >= 18 and trozo in lineas[i][4]:
                    i_e = i
                    break

    return i_s, i_e
