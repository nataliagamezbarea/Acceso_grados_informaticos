import re

from backend.procesador_pdf.busqueda_rectangulos._constantes import _PALABRAS_VACIAS

def _coincidencia_suficiente(linea_txt, objetivo):
    """Comprueba si linea_txt corresponde al objetivo de forma sustancial.
    - El objetivo puede estar contenido en la línea (siempre válido).
    - La línea contenida en el objetivo SOLO si es sustancial Y ADEMÁS aparece
      pegada AL PRINCIPIO del objetivo (con muy poco margen). Antes se aceptaba
      la línea en CUALQUIER posición del objetivo, lo que provocaba falsos
      positivos graves: si el enunciado buscado terminaba, por ejemplo, en
      "...bits de paridad." y en la página había ANTES otra frase que también
      terminaba en "bits de paridad.", esa frase anterior (ajena al enunciado)
      se detectaba como si fuera su inicio real. Esto desplazaba el rango
      detectado varias líneas hacia arriba, arrastrando de paso tablas u otro
      contenido intermedio que no tenía nada que ver con el enunciado y que
      acababa borrándose por error.
    - Por palabras: la línea debe estar formada mayoritariamente por palabras del objetivo."""
    if not objetivo or not linea_txt: return False
    if objetivo in linea_txt: return True
    if len(linea_txt) >= 15:
        idx = objetivo.find(linea_txt)
        # Solo cuenta si linea_txt está pegada al inicio del objetivo (permitimos
        # un pequeño margen de 3 caracteres para numeraciones/viñetas sueltas).
        if 0 <= idx <= 3:
            return True
    pal_obj = [w for w in re.split(r"\s+", objetivo.lower()) if len(w) > 1 and w not in _PALABRAS_VACIAS]
    pal_lin = [w for w in re.split(r"\s+", linea_txt.lower()) if len(w) > 1 and w not in _PALABRAS_VACIAS]
    if not pal_obj or not pal_lin: return False
    # Igual que arriba: exigimos que las palabras comunes aparezcan como PREFIJO
    # de la lista de palabras del objetivo (no en cualquier parte), para evitar
    # que un fragmento que comparte vocabulario con el FINAL del objetivo (pero
    # que en realidad pertenece a otro párrafo anterior) se cuele como inicio.
    conjunto_obj_prefijo = set(pal_obj[:max(len(pal_lin) + 2, 6)])
    comunes = sum(1 for w in pal_lin if w in conjunto_obj_prefijo)
    return comunes >= 3 and comunes >= int(len(pal_lin) * 0.7)
