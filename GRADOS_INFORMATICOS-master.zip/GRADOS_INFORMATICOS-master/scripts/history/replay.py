from __future__ import annotations
import shutil,tempfile
from pathlib import Path
from git.auth import basic_header,run
from github.api import create_ref,branch_sha

def master_commits(work, master_dir, branch):
    # La fuente MAESTRO se recibe como ruta local; no dependemos de un remoto
    # llamado origin en el repositorio temporal.
    run(
        work,
        ['fetch', '--quiet', master_dir,
         f'+refs/remotes/origin/{branch}:refs/remotes/master/{branch}']
    )

    # GitHub Actions checkout deja las ramas del repositorio MAESTRO en
    # refs/remotes/origin/*, NO en refs/heads/*. Por eso intentar:
    #   git fetch <workspace> refs/heads/<rama>
    # falla con "couldn't find remote ref".
    #
    # Leemos directamente la referencia remota que actions/checkout ya trajo.
    origin_ref = f'refs/remotes/master/{branch}'
    result = run(work, ['rev-parse', '--verify', origin_ref], check=False)
    if result.returncode != 0:
        # Compatibilidad si el checkout tiene la rama como referencia local.
        local_ref = f'refs/heads/{branch}'
        result = run(work, ['rev-parse', '--verify', local_ref], check=False)
        if result.returncode != 0:
            raise RuntimeError(
                f'No se encuentra la rama MAESTRO {branch} en el checkout. '
                f'Referencias disponibles: {run(work, ["for-each-ref", "--format=%(refname)", "refs/remotes/origin/"]).stdout}'
            )
        origin_ref = local_ref

    # Obtener TODOS los commits de la rama, del más antiguo al más reciente.
    return run(
        work,
        ['rev-list', '--reverse', origin_ref]
    ).stdout.splitlines()

def metadata(work,sha):
    def show(fmt): return run(work,['show','-s',f'--format={fmt}',sha]).stdout.strip()
    return show('%B'),show('%an'),show('%ae'),show('%aI'),show('%cI')

def replay_commit(work,source,parent):
    run(work,['read-tree',f'{source}^{{tree}}'])
    # No trasladar workflows al repositorio privado: GitHub exige el scope
    # `workflow` del PAT para crear o modificar archivos dentro de esta carpeta.
    run(work,['rm','-r','--cached','--ignore-unmatch','--','.github/workflows'],check=False)
    tree=run(work,['write-tree']).stdout.strip()
    msg,name,email,adate,cdate=metadata(work,source)
    run(work,['config','user.name','grados-informaticos-sync']); run(work,['config','user.email','sync@grados-informaticos.local'])
    f=Path(work)/'message.txt'; f.write_text(msg,encoding='utf-8')
    env={'GIT_AUTHOR_NAME':name or 'MAESTRO','GIT_AUTHOR_EMAIL':email or 'sync@grados-informaticos.local','GIT_AUTHOR_DATE':adate,'GIT_COMMITTER_NAME':name or 'MAESTRO','GIT_COMMITTER_EMAIL':email or 'sync@grados-informaticos.local','GIT_COMMITTER_DATE':cdate}
    args=['commit-tree',tree,'-F',str(f)] + (['-p',parent] if parent else [])
    return run(work,args,env).stdout.strip()

def replay_history(token,private_repo,master_dir,branch,existing_sha=None):
    # SOLO se debe llamar para ramas que NO son la principal: la principal
    # nunca sincroniza (ver sync() en service.py, que corta antes de llegar
    # aquí cuando branch == principal).
    #
    # existing_sha: si la rama YA existe en PRIVADO, aquí llega su SHA actual.
    # En ese caso NO se reproduce el historial completo: se compara la
    # cantidad de commits de MAESTRO con la cantidad de commits que ya tiene
    # PRIVADO. Si coinciden, no se hace nada (ni un solo commit+push). Si a
    # PRIVADO le faltan commits al final, se reproducen y suben SOLO esos,
    # encadenados sobre existing_sha como padre.
    work=tempfile.mkdtemp(prefix='sync-private-')
    try:
        run(work,['init','-q'])
        auth=basic_header(token); url=f'https://github.com/{private_repo}.git'
        run(work,['remote','add','private',url])
        run(work,['-c',f'http.extraHeader={auth}','fetch','--quiet','private'],check=False)
        commits=master_commits(work,master_dir,branch)
        if not commits: raise RuntimeError(f'La rama MAESTRO {branch} no tiene commits.')

        if existing_sha:
            # La rama ya existe en PRIVADO: comprobar cuántos commits tiene ya
            # (el fetch de arriba trae su objeto, por eso rev-list funciona
            # directamente sobre existing_sha).
            private_count=int(run(work,['rev-list','--count',existing_sha]).stdout.strip())
            master_count=len(commits)
            if private_count>=master_count:
                print(f'[RAMA PRIVADA AL DÍA] {private_repo}:{branch} ya tiene {private_count} commit(s) (MAESTRO tiene {master_count}); no se hace ningún commit.')
                return existing_sha
            faltantes=commits[private_count:]
            parent=existing_sha
            for source in faltantes:
                parent=replay_commit(work,source,parent)
                run(work,['-c',f'http.extraHeader={auth}','push','--quiet','private',f'{parent}:refs/heads/{branch}'])
            print(f'[RAMA PRIVADA COMPLETADA] {private_repo}:{branch}: faltaban {len(faltantes)} de {master_count} commit(s); añadidos uno por uno (commit+push por cada commit).')
            return parent

        # Rama privada nueva: no existe todavía, se reproduce el historial
        # COMPLETO de MAESTRO, commit a commit (commit + push por cada commit).
        # IMPORTANTE: no intentamos leer master del repo destino. Puede estar completamente vacío.
        parent=None
        for source in commits:
            parent=replay_commit(work,source,parent)
            # Push de CADA commit individualmente, tal como se pidió:
            # traer el historial y hacer commit + push, uno a uno.
            run(work,['-c',f'http.extraHeader={auth}','push','--quiet','private',f'{parent}:refs/heads/{branch}'])
        print(f'[RAMA PRIVADA CREADA] {private_repo}:{branch} con {len(commits)} commits, uno por uno (commit+push por cada commit).')
        return parent
    finally: shutil.rmtree(work,ignore_errors=True)
