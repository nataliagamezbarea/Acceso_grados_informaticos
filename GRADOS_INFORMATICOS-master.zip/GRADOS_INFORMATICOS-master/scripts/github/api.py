from __future__ import annotations
import json
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

API='https://api.github.com'

def request(token, method, path, data=None):
    headers={'Authorization':f'Bearer {token}','Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'grados-informaticos-sync'}
    body=None
    if data is not None:
        body=json.dumps(data).encode(); headers['Content-Type']='application/json'
    try:
        with urlopen(Request(API+path,data=body,headers=headers,method=method),timeout=60) as r:
            raw=r.read().decode(); return r.status, json.loads(raw) if raw else {}
    except HTTPError as e:
        raw=e.read().decode(errors='replace')
        try: detail=json.loads(raw)
        except Exception: detail={'message':raw}
        if e.code in (404,409): return e.code,detail
        raise RuntimeError(f'GitHub API {method} {path} -> HTTP {e.code}: {detail.get("message",raw)}') from e

def repo(token, name):
    status,data=request(token,'GET',f'/repos/{name}')
    if status!=200: raise RuntimeError(f'No se puede acceder al repositorio {name}.')
    return data

def branches(token, name):
    # GitHub pagina las ramas. Recuperamos todas para no perder ramas
    # cuando el repositorio tiene más de 100.
    result = []
    page = 1
    while True:
        status, data = request(
            token,
            'GET',
            f'/repos/{name}/branches?per_page=100&page={page}'
        )
        if status != 200:
            raise RuntimeError(f'No se pudieron listar las ramas de {name}.')
        page_items = [
            x['name'] for x in data
            if isinstance(x, dict) and x.get('name')
        ]
        result.extend(page_items)
        if len(data) < 100:
            break
        page += 1
    return result

def branch_sha(token, name, branch):
    path=quote(branch,safe='')
    status,data=request(token,'GET',f'/repos/{name}/git/ref/heads/{path}')
    if status in (404,409): return None
    if status!=200: raise RuntimeError(f'No se pudo leer {name}:{branch}.')
    return data['object']['sha']

def contents(token,name,path,branch):
    path=quote(path.replace('\\','/').lstrip('/'),safe='/'); branch=quote(branch,safe='')
    status,data=request(token,'GET',f'/repos/{name}/contents/{path}?ref={branch}')
    if status==404: return None
    if status!=200: raise RuntimeError(f'No se pudo leer {name}:{branch}/{path}.')
    return data if isinstance(data,dict) and data.get('type')=='file' else None

def blob(token,name,content):
    import base64
    payload={'content':base64.b64encode(content).decode(),'encoding':'base64'}
    status,data=request(token,'POST',f'/repos/{name}/git/blobs',payload)
    if status not in (200,201): raise RuntimeError(f'No se pudo crear blob en {name}: {data}')
    return data['sha']

def tree(token,name,base_tree,entries):
    payload={'tree':entries}
    if base_tree: payload['base_tree']=base_tree
    status,data=request(token,'POST',f'/repos/{name}/git/trees',payload)
    if status not in (200,201): raise RuntimeError(f'No se pudo crear árbol en {name}: {data}')
    return data['sha']

def commit(token,name,tree_sha,message,parent=None):
    payload={'message':message,'tree':tree_sha}
    if parent: payload['parents']=[parent]
    status,data=request(token,'POST',f'/repos/{name}/git/commits',payload)
    if status not in (200,201): raise RuntimeError(f'No se pudo crear commit en {name}: {data}')
    return data['sha']

def create_ref(token,name,branch,sha):
    status,data=request(token,'POST',f'/repos/{name}/git/refs',{'ref':f'refs/heads/{branch}','sha':sha})
    if status not in (200,201): raise RuntimeError(f'No se pudo crear {name}:{branch}: {data}')
    return sha

def update_ref(token,name,branch,sha):
    path=quote(branch,safe='')
    status,data=request(token,'PATCH',f'/repos/{name}/git/refs/heads/{path}',{'sha':sha,'force':False})
    if status!=200: raise RuntimeError(f'No se pudo actualizar {name}:{branch}: {data}')
    return sha

def commit_tree(token,name,sha):
    status,data=request(token,'GET',f'/repos/{name}/git/commits/{sha}')
    if status!=200: raise RuntimeError(f'No se pudo leer commit {sha} de {name}.')
    return data['tree']['sha']
