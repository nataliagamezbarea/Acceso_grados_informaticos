from __future__ import annotations
from github.api import repo,branches,branch_sha,tree,commit,create_ref
from history.replay import replay_history

def ensure_empty(token,repo_name,branch):
    # Crea `branch` en `repo_name` con un commit raíz de árbol vacío (sin
    # historial, sin archivos). Se usa para PÚBLICO siempre, y para PRIVADO
    # SOLO en el caso especial de la rama principal (que nunca debe traer
    # historial ni archivos, pero sí debe poder existir como rama vacía).
    sha=branch_sha(token,repo_name,branch)
    if sha: return sha,False
    empty_tree=tree(token,repo_name,None,[])
    root=commit(token,repo_name,empty_tree,f'Crear rama {branch} vacía')
    create_ref(token,repo_name,branch,root)
    return root,True

def ensure_private(token,repo_name,master_dir,branch):
    # Nunca falla por 409: 409 significa repositorio vacío.
    # IMPORTANTE: esta función (con replay_history) NUNCA se llama para la
    # propia rama principal. Para la principal se usa ensure_empty() en su
    # lugar, que crea la rama vacía sin traer historial. Ver sync().
    sha=branch_sha(token,repo_name,branch)
    creada=sha is None
    if creada:
        # Rama privada nueva: se trae el historial COMPLETO de MAESTRO para
        # esta rama y se reproduce en PRIVADO commit a commit (commit + push
        # por cada commit del historial). Se llama tanto cuando se hace push
        # directo a esta rama, como cuando se hace push a la principal y esta
        # rama aún no existe en PRIVADO (ver sync() en service.py).
        sha=replay_history(token,repo_name,master_dir,branch)
        return sha,True
    # La rama YA existe en PRIVADO: en lugar de no tocar nada, se comprueba
    # cuántos commits tiene MAESTRO frente a los que ya tiene PRIVADO.
    # - Si la cantidad coincide, no se hace ningún commit (replay_history
    #   corta ahí mismo, sin commit+push).
    # - Si a PRIVADO le faltan commits al final del historial, se reproducen
    #   y suben SOLO esos, encadenados sobre el último commit ya existente
    #   (no se rehace todo el historial commit a commit desde cero).
    sha=replay_history(token,repo_name,master_dir,branch,existing_sha=sha)
    return sha,False

def ensure_public(token,repo_name,branch):
    sha,created=ensure_empty(token,repo_name,branch)
    if created: print(f'[RAMA PÚBLICA CREADA] {repo_name}:{branch} vacía.')
    return sha,created


def default_branch(token, repo_name):
    return repo(token, repo_name).get("default_branch")

def source_branches(token, repo_name):
    # Las ramas destino deben salir del MAESTRO (origen).
    # Antes se consultaba el repositorio privado, por lo que una rama que
    # existía en MAESTRO pero aún no en PRIVADO nunca se detectaba al hacer
    # un commit en la principal.
    return branches(token, repo_name)
