#!/usr/bin/env python3
import os
import sys

from config.supabase import load_git_config
from sync.service import sync


def main():
    cfg = load_git_config()
    branch = os.getenv("MAESTRO_BRANCH") or os.getenv("GITHUB_REF_NAME")
    if not branch:
        raise RuntimeError("No se pudo determinar la rama del MAESTRO.")

    changed_status = os.getenv("CHANGED_STATUS", "")

    print(f"[INFO] Rama MAESTRO: {branch}")
    print(f"[INFO] PRIVADO: {cfg.privado}")
    print(f"[INFO] PÚBLICO: {cfg.publico}")

    if not changed_status.strip():
        print("[INFO] No hay archivos modificados.")
        return

    sync(
        os.getenv("GITHUB_WORKSPACE", "."),
        cfg.token,
        cfg.privado,
        cfg.publico,
        changed_status,
        branch,
        master_repo=os.getenv('GITHUB_REPOSITORY'),
    )
    print("[OK] Sincronización completada.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}")
        sys.exit(1)
