from __future__ import annotations
from pathlib import Path
from urllib.parse import quote
from github.api import contents,request,blob,tree,commit_tree,commit,update_ref

def norm(p): return str(p).replace('\\','/').lstrip('/')

def locate(token,repo,master_path,branch):
    p=norm(master_path); direct=contents(token,repo,p,branch)
    if direct: return p,direct
    # Code Search no funciona de forma fiable en repos vacíos y no es necesario allí.
    q=quote(f'repo:{repo} filename:"{Path(p).name}"',safe='')
    status,data=request(token,'GET',f'/search/code?q={q}&per_page=100')
    if status!=200: return None,None
    matches=[]
    for item in data.get('items',[]):
        path=norm(item.get('path',''))
        if Path(path).name==Path(p).name:
            current=contents(token,repo,path,branch)
            if current: matches.append((path,current))
    if len(matches)>1: raise RuntimeError(f'AMBIGUO: {Path(p).name} aparece varias veces en {repo}:{branch}.')
    return matches[0] if matches else (None,None)

def apply_changes(token,repo,branch,changes,message):
    if not changes:return None
    head=__import__('scripts.github.api',fromlist=['branch_sha']).branch_sha(token,repo,branch)
    if not head: raise RuntimeError(f'No existe {repo}:{branch}.')
    base=commit_tree(token,repo,head); entries=[]
    for c in changes:
        p=norm(c['path'])
        if c['action']=='delete': entries.append({'path':p,'mode':'100644','type':'blob','sha':None})
        else: entries.append({'path':p,'mode':'100644','type':'blob','sha':blob(token,repo,Path(c['source']).read_bytes())})
    t=tree(token,repo,base,entries); new=commit(token,repo,t,message,head); update_ref(token,repo,branch,new)
    print(f'[COMMIT] {repo}:{branch} -> {new}')
    return new
