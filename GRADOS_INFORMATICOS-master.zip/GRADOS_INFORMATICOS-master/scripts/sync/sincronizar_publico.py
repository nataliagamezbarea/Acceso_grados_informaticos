#!/usr/bin/env python3
import os
import sys

# Permite ejecutar este archivo directamente desde GitHub Actions:
# python3 scripts/sync/sincronizar_publico.py
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

from sync.sincronizar_repos import main

if __name__ == "__main__":
    main()
