from __future__ import annotations
import os
from pathlib import Path
from sync.branches import ensure_private, ensure_public, ensure_empty, default_branch, source_branches
from sync.files import norm, locate, apply_changes


# Estados que implican que el archivo YA EXISTÍA antes del push y, por tanto,
# hay que localizar en qué repositorio está antes de modificarlo/eliminarlo.
LOCATE_STATUSES = {"M", "D", "R", "T", "C"}


def _status_entries(changed_status: str):
    """Convierte git diff --name-status en tuplas (estado, rutas)."""
    for line in (changed_status or "").splitlines():
        parts = line.split("\t")
        if not parts:
            continue
        status = parts[0].strip()
        kind = status[:1]
        paths = [norm(p) for p in parts[1:] if norm(p)]
        if kind == "R" and len(paths) >= 2:
            yield "R", paths[0], paths[1]
        elif paths:
            yield kind, paths[0], None


def _locate_once(token, private_repo, public_repo, path, branch):
    """Busca una sola vez por repositorio y devuelve dónde existe el archivo."""
    private_path, private_item = locate(token, private_repo, path, branch)
    if private_item:
        return "private", private_path

    public_path, public_item = locate(token, public_repo, path, branch)
    if public_item:
        return "public", public_path

    return None, None


def _queue_put(queue, repo_kind, path, source):
    queue[repo_kind].append({"action": "put", "path": path, "source": source})


def _queue_delete(queue, repo_kind, path):
    queue[repo_kind].append({"action": "delete", "path": path})


WORKFLOW_PREFIX = '.github/workflows/'

def _is_workflow_path(path):
    return norm(path).lower().startswith(WORKFLOW_PREFIX)


def _sync_one_branch(master_dir, token, private_repo, public_repo, changed_status, branch):
    _, private_created = ensure_private(token, private_repo, master_dir, branch)
    ensure_public(token, public_repo, branch)

    # Si la rama privada acaba de crearse, se crea VACÍA (sin historial de
    # MAESTRO). No salimos: el cambio que disparó el workflow debe aplicarse
    # igualmente a esta rama nueva, limitándose a lo subido en este push.
    if private_created:
        print(f"[OK] Rama privada nueva: {branch} creada vacía; aplicando solo el cambio de este push.")

    queue = {"private": [], "public": []}

    for status, path, new_path in _status_entries(changed_status):
        # Los workflows del repositorio origen nunca se copian al privado.
        # Así un PAT sin scope "workflow" puede sincronizar el resto del proyecto.
        if _is_workflow_path(path) or (new_path and _is_workflow_path(new_path)):
            print(f"[OMITIDO WORKFLOW] {branch}: {path}" + (f" -> {new_path}" if new_path else ""))
            continue

        source = Path(master_dir) / path

        if status == "A":
            if source.exists():
                _queue_put(queue, "private", path, str(source))
                print(f"[NUEVO -> PRIVADO DIRECTAMENTE] {branch}: {path}")
            continue

        if status == "R":
            repo_kind, old_dest = _locate_once(token, private_repo, public_repo, path, branch)
            if repo_kind is None:
                new_source = Path(master_dir) / new_path
                if new_source.exists():
                    _queue_put(queue, "private", new_path, str(new_source))
                continue
            new_source = Path(master_dir) / new_path
            if repo_kind == "private":
                _queue_delete(queue, "private", old_dest)
                if new_source.exists(): _queue_put(queue, "private", new_path, str(new_source))
            else:
                _queue_delete(queue, "public", old_dest)
                if new_source.exists(): _queue_put(queue, "public", new_path, str(new_source))
            continue

        if status in LOCATE_STATUSES:
            repo_kind, dest = _locate_once(token, private_repo, public_repo, path, branch)
            if repo_kind is None:
                if status != "D" and source.exists():
                    _queue_put(queue, "private", path, str(source))
                continue
            if status == "D":
                _queue_delete(queue, repo_kind, dest)
            elif source.exists():
                _queue_put(queue, repo_kind, dest, str(source))

    apply_changes(token, private_repo, branch, queue["private"], f"Sincronizar {branch} desde LA PRINCIPAL")
    apply_changes(token, public_repo, branch, queue["public"], f"Sincronizar {branch} desde LA PRINCIPAL")


def sync(master_dir, token, private_repo, public_repo, changed_status, branch, master_repo=None):
    # La rama principal SI dispara el workflow, pero NUNCA lleva SUS
    # archivos/commit a PRIVADO ni a PÚBLICO.
    # "Principal" NO es un nombre fijo ("master", "main"...): se detecta
    # dinámicamente leyendo el default_branch real del repo MAESTRO vía la
    # API de GitHub (ver default_branch() en branches.py).
    #
    # Lo que SÍ hace un push a la principal: recorre las DEMÁS ramas que
    # existen en MAESTRO y, SOLO las que todavía no existan en PRIVADO,
    # las crea trayendo su historial completo (commit + push por cada
    # commit, vía replay_history). Las ramas que ya existen no se tocan
    # (ensure_private/ensure_public no hacen nada si la rama ya existe).
    # El cambio que disparó el push en la principal NUNCA se aplica a
    # ninguna rama, ni siquiera a las recién creadas.
    #
    # EXCEPCIÓN: la propia rama principal SÍ se crea (VACÍA, sin historial
    # ni archivos) en PRIVADO y en PÚBLICO si todavía no existe ahí. Si ya
    # existe, no se toca nunca.
    source_repo = master_repo or os.getenv('GITHUB_REPOSITORY')
    if not source_repo:
        raise RuntimeError('No se pudo determinar el repositorio MAESTRO (GITHUB_REPOSITORY).')

    principal = default_branch(token, source_repo)
    if branch == principal:
        ramas = [b for b in source_branches(token, source_repo) if b != principal]
        print(f"[PRINCIPAL] Commit en {principal}: no se sincronizan archivos de la principal. "
              f"Se comprueban {len(ramas)} rama(s) más: {ramas} (solo se crean las que aún no existan en PRIVADO/PÚBLICO).")
        for destino in ramas:
            _, private_created = ensure_private(token, private_repo, master_dir, destino)
            _, public_created = ensure_public(token, public_repo, destino)
            if private_created:
                print(f"[OK] Rama privada nueva: {destino} creada con su historial completo.")
            if public_created:
                print(f"[OK] Rama pública nueva: {destino} creada vacía.")

        # EXCEPCIÓN para la propia principal: se crea VACÍA en PRIVADO y en
        # PÚBLICO si todavía no existe (para que el repo tenga al menos esa
        # rama por defecto), pero NUNCA trae historial ni archivos del push
        # que disparó este workflow. Si ya existe, no se toca.
        _, priv_principal_created = ensure_empty(token, private_repo, principal)
        _, pub_principal_created = ensure_empty(token, public_repo, principal)
        if priv_principal_created:
            print(f"[OK] Rama privada principal '{principal}' creada VACÍA (excepción: nunca recibe archivos ni historial).")
        if pub_principal_created:
            print(f"[OK] Rama pública principal '{principal}' creada VACÍA (excepción: nunca recibe archivos ni historial).")
        return

    _sync_one_branch(master_dir, token, private_repo, public_repo, changed_status, branch)
