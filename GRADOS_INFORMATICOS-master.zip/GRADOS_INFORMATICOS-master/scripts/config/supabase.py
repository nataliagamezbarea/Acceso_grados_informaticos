from __future__ import annotations
import json, os
from urllib.request import Request, urlopen
from dataclasses import dataclass

SCHEMA = 'grados-informaticos'

@dataclass(frozen=True)
class GitConfig:
    token: str
    privado: str
    publico: str

def _key() -> str:
    key = os.getenv('SUPABASE_SERVICE_ROLE_KEY') or os.getenv('SUPABASE_KEY')
    if not key: raise RuntimeError('Falta SUPABASE_SERVICE_ROLE_KEY (o SUPABASE_KEY).')
    return key.strip()

def read_rows(table: str, params: str) -> dict[str,str]:
    base = os.environ.get('SUPABASE_URL','').rstrip('/')
    if not base: raise RuntimeError('Falta SUPABASE_URL.')
    key = _key()
    req = Request(f'{base}/rest/v1/{table}?{params}', headers={
        'apikey': key, 'Authorization': f'Bearer {key}', 'Accept': 'application/json',
        'Accept-Profile': SCHEMA, 'Content-Profile': SCHEMA,
    })
    with urlopen(req, timeout=30) as r: rows = json.loads(r.read().decode())
    return {str(x['clave']): str(x['valor']).strip() for x in rows if x.get('clave') is not None}

def load_git_config() -> GitConfig:
    private = read_rows('configuracion_privada','select=clave,valor&clave=in.(gh_repo,gh_token)')
    public = read_rows('configuracion_publica','select=clave,valor&clave=eq.gh_repo')
    token, privado, publico = private.get('gh_token'), private.get('gh_repo'), public.get('gh_repo')
    if not token or not privado or not publico:
        raise RuntimeError('Faltan gh_token, gh_repo privado o gh_repo público en Supabase.')
    return GitConfig(token, privado, publico)
