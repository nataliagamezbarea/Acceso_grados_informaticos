from __future__ import annotations
import base64, os, subprocess

def basic_header(token):
    value=base64.b64encode(f'x-access-token:{token}'.encode()).decode()
    return f'Authorization: Basic {value}'

def run(cwd,args,extra_env=None,check=True):
    env=os.environ.copy(); env.update(extra_env or {})
    p=subprocess.run(['git',*args],cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if check and p.returncode: raise RuntimeError(f'Git {" ".join(args)} -> {p.returncode}: {p.stderr.strip()}')
    return p
