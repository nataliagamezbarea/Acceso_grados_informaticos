/* ALIASES GLOBALES PARA BOTONES DEL HTML */
function compileCurrentApunte() { return confirmGenerateApunteLatex(); }

function verApunteActual() {
  const it = ITEMS[POS];
  if (!it) return;
  window.open('/api/ver_apunte?grado=' + grad + '&archivo=' + it.archivo, '_blank');
}

async function compileAllApuntes() {
  if (typeof showBlocker === 'function') showBlocker('Compilando todos los apuntes del grado con LaTeX...');
  try {
    const res = await fetch('/api/compilar_todos_apuntes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ grado: grad })
    });
    const data = await res.json();
    if (typeof hideBlocker === 'function') hideBlocker();
    if (data.ok) {
      if (typeof showCustomAlert === 'function') {
        await showCustomAlert('Compilación Finalizada', `✓ Se han compilado ${data.compilados || 0} apuntes con éxito.`, '<i class="fa-solid fa-copy"></i>', '#10b981');
      }
      if (typeof load === 'function') await load();
    } else {
      if (typeof showCustomAlert === 'function') {
        await showCustomAlert('Error en Apuntes', data.error || 'Error al compilar apuntes.', '<i class="fa-solid fa-triangle-exclamation"></i>', '#ef4444');
      }
    }
  } catch (err) {
    if (typeof hideBlocker === 'function') hideBlocker();
    console.error('Error al compilar todos los apuntes:', err);
  }
}

