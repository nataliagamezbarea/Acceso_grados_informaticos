// Las ramas del ADMIN siempre se descubren dinamicamente desde el backend,
// que usa gh_repo_general + gh_token de configuracion_privada.
window.RamaAPI = (() => {
  const RAMAS_RESPALDO = [];

  const listarRamas = async () => {
    try {
      const res = await fetch("/api/ramas", {
        headers: { "Accept": "application/json" },
        cache: "no-store"
      });
      if (res.ok) {
        const ramas = await res.json();
        if (Array.isArray(ramas)) return ramas;
      }
    } catch (e) {}
    return RAMAS_RESPALDO;
  };

  return { listarRamas, RAMAS_RESPALDO };
})();
