// GESTIÓN DE RAMA SELECCIONADA (< 60 lineas)
window.RamaActual = (() => {
  const CLAVE_LOCAL = "rama_actual";

  const obtener = () => {
    const url = new URLSearchParams(window.location.search).get("rama");
    if (url && url.trim()) {
      guardar(url.trim());
      return url.trim();
    }
    return localStorage.getItem(CLAVE_LOCAL) || "";
  };

  const guardar = (rama) => {
    if (rama) localStorage.setItem(CLAVE_LOCAL, rama);
    else localStorage.removeItem(CLAVE_LOCAL);
  };

  const poblarSelector = async (select) => {
    if (!select) return;

    // 1. Obtener la rama conocida desde URL o localStorage ANTES de poblar
    const urlRama = new URLSearchParams(window.location.search).get("rama");
    const ramaGuardada = localStorage.getItem('rama_actual');
    const ramaConocida = urlRama || ramaGuardada || '';

    const ramas = window.RamaAPI ? await window.RamaAPI.listarRamas() : [];

    select.innerHTML = "";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = '-- Seleccionar rama --';
    select.appendChild(placeholder);

    ramas.forEach((rama) => {
      const opcion = document.createElement("option");
      opcion.value = rama;
      opcion.textContent = rama;
      select.appendChild(opcion);
    });

    // 2. Poner la rama conocida al instante
    if (ramaConocida) {
      select.value = ramaConocida;
    }
  };


  return {
    obtener,
    guardar,
    listarRamas: () => (window.RamaAPI ? window.RamaAPI.listarRamas() : Promise.resolve([])),
    poblarSelector
  };
})();
