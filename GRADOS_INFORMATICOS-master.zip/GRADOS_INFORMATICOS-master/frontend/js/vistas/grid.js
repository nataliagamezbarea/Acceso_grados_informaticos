/* SCROLL INFINITO Y GRID PROGRESIVO (< 60 lineas) */

function renderProgressiveGrid(gridEl, items, batchSize = 18) {
  let currentIndex = 0;

  function appendNextBatch() {
    const batch = items.slice(currentIndex, currentIndex + batchSize);
    batch.forEach(it => {
      const el = document.createElement('div');
      el.className = 'card' + (it.visto ? ' visited' : '');
      el.innerHTML = cardHTML(it);
      el.onclick = () => {
        POS = ITEMS.findIndex(x => x.archivo === it.archivo);
        localStorage.setItem('last_grado', grad);
        localStorage.setItem('last_pos', POS);
        localStorage.setItem('last_open', '1');
        openOv();
      };
      gridEl.appendChild(el);
    });
    currentIndex += batch.length;
  }

  appendNextBatch();

  if (currentIndex < items.length) {
    const sentinel = document.createElement('div');
    sentinel.className = 'infinite-sentinel';
    sentinel.style.width = '100%';
    sentinel.style.height = '20px';
    sentinel.style.gridColumn = '1 / -1';
    gridEl.appendChild(sentinel);

    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        sentinel.remove();
        appendNextBatch();
        if (currentIndex < items.length) {
          gridEl.appendChild(sentinel);
        } else {
          observer.disconnect();
        }
      }
    }, { rootMargin: '300px' });

    observer.observe(sentinel);
  }
}
