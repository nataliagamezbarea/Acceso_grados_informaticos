/* RENDERIZADO DE TARJETAS Y ETIQUETAS (< 60 lineas) */

function vbadge(v, decision) {
  if (decision === 'applied') return '<span class="badge v" style="background:#065f46;color:#34d399;font-weight:700"><i class="fa-solid fa-check-double"></i> ✓ Aplicado</span>';
  if (decision === 'original') return '<span class="badge v" style="background:#78350f;color:#fbbf24;font-weight:700"><i class="fa-solid fa-rotate-left"></i> ✓ Original</span>';
  return '';
}

function groupBySubfolder(items) {
  const groups = {};
  items.forEach(it => {
    let sub = 'archivos';
    if (it.archivo.includes('/')) {
      sub = it.archivo.split('/')[0];
    }
    if (!groups[sub]) groups[sub] = [];
    groups[sub].push(it);
  });
  return groups;
}

function cardHTML(it) {
  const tag = (it.type === 'e') ? '<span class="tag enc">Enunciado + Nombres</span>' : '<span class="tag nom">Solo Nombres</span>';
  const ren = (it.cambia_nombre && it.nombre_limpio) ? `<div style="font-size:11px;color:#c084fc;margin-top:4px">➔ ${it.nombre_limpio}</div>` : '';
  const apuTag = it.inc_apunte ? '<span class="badge apu" style="background:#065f46;color:#34d399;font-size:10px;margin-left:4px">Apunte</span>' : '';
  const orig = (it.type === 'e') ? `<div class="orig-txt">Original: ${it.start || it.old || '-'}</div>` : '<div class="orig-txt">Limpieza de nombres de profesores y escolares.</div>';
  const nuev = (it.type === 'e') ? `<div class="new-txt">Nuevo: ${it.new || '-'}</div>` : '';
  const thumbUrl = it.archivo ? `/api/thumb/${grad}?archivo=${encodeURIComponent(it.archivo)}` : (it.idx !== undefined ? `/api/thumb/${grad}/${it.idx}` : '');
  const fallbackImg = 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=300&auto=format&fit=crop&q=70';

  return `
    <div class="card-content-layout">
      <div class="card-thumb-box">
        <img src="${thumbUrl || fallbackImg}" class="card-thumb-img" alt="Vista Previa PDF" loading="lazy" onerror="this.onerror=null;this.src='${fallbackImg}';" />
      </div>
      <div class="card-info-box">
        <div style="font-weight:700;font-size:14px;word-break:break-all;color:#f3f4f6">${it.archivo}</div>
        <div style="margin-top:6px;display:flex;gap:6px;align-items:center;flex-wrap:wrap">${tag}${apuTag}${vbadge(it.visto, it.decision)}</div>
        ${ren}
        ${orig}
        ${nuev}
      </div>
    </div>
  `;
}

