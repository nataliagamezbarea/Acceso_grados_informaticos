/* MODALES DE ALERTA Y CONFIRMACION (< 80 lineas) */

function showBlocker(msg) {
  const b = document.getElementById('blocker');
  const t = document.getElementById('blockerText');
  if (t) t.textContent = msg || 'Procesando...';
  if (b) b.classList.add('on');
}

function hideBlocker() {
  const b = document.getElementById('blocker');
  if (b) b.classList.remove('on');
}

function showCustomAlert(title, message, icon = '<i class="fa-solid fa-circle-info"></i>', color = '#38bdf8') {
  return new Promise((resolve) => {
    const modal = document.getElementById('customAlertModal');
    if (!modal) {
      alert(`${title}

${message}`);
      resolve();
      return;
    }
    const iconEl = document.getElementById('customAlertIcon');
    const titleEl = document.getElementById('customAlertTitle');
    const msgEl = document.getElementById('customAlertMessage');
    const btn = document.getElementById('customAlertBtn');

    if (iconEl) {
      iconEl.innerHTML = icon;
      iconEl.style.color = color;
      iconEl.style.borderColor = color + '40';
      iconEl.style.backgroundColor = color + '15';
    }
    if (titleEl) titleEl.textContent = title;
    if (msgEl) msgEl.innerHTML = (message || '').replace(/\n/g, '<br/>');

    modal.classList.add('on');

    const cerrar = () => {
      modal.classList.remove('on');
      btn.removeEventListener('click', cerrar);
      resolve();
    };
    btn.addEventListener('click', cerrar);
  });
}

function showCustomConfirm(title, message, icon = '<i class="fa-solid fa-triangle-exclamation"></i>', color = '#ef4444') {
  return new Promise((resolve) => {
    const modal = document.getElementById('customConfirmModal');
    if (!modal) {
      resolve(confirm(`${title}

${message}`));
      return;
    }
    const iconEl = document.getElementById('customConfirmIcon');
    const titleEl = document.getElementById('customConfirmTitle');
    const msgEl = document.getElementById('customConfirmMessage');
    const btnOk = document.getElementById('customConfirmBtnOk');
    const btnCancel = document.getElementById('customConfirmBtnCancel');

    if (iconEl) {
      iconEl.innerHTML = icon;
      iconEl.style.color = color;
      iconEl.style.borderColor = color + '40';
      iconEl.style.backgroundColor = color + '15';
    }
    if (titleEl) titleEl.textContent = title;
    if (msgEl) msgEl.innerHTML = (message || '').replace(/\n/g, '<br/>');

    modal.classList.add('on');

    const cerrarOk = () => {
      modal.classList.remove('on');
      limpiar();
      resolve(true);
    };
    const cerrarCancel = () => {
      modal.classList.remove('on');
      limpiar();
      resolve(false);
    };
    const limpiar = () => {
      btnOk.removeEventListener('click', cerrarOk);
      btnCancel.removeEventListener('click', cerrarCancel);
    };

    btnOk.addEventListener('click', cerrarOk);
    btnCancel.addEventListener('click', cerrarCancel);
  });
}
