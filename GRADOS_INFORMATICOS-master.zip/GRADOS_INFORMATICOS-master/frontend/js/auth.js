// GUARD DE AUTENTICACIÓN SUPABASE Y GITHUB (< 80 líneas)
(() => {
  const esPaginaLogin = /login\.html/.test(window.location.pathname);
  const credencialesListas = window.SUPABASE_URL && window.SUPABASE_ANON_KEY && !window.SUPABASE_URL.startsWith("PEGA");

  document.documentElement.style.visibility = "hidden";
  const redirigir = (dest) => window.location.replace(dest);


  const verificarPermiso = async (u) => {
    if (!u) return false;
    const email = (u.email || "").toLowerCase();
    const uName = (u.user_metadata?.user_name || u.user_metadata?.preferred_username || u.identities?.[0]?.identity_data?.user_name || "").toLowerCase();
    if (email === "nataliagbarea@gmail.com" || uName === "nataliagamezbarea") return true;
    if (window.GITHUB_CONFIG && window.GITHUB_CONFIG.token && uName) {
      try {
        const r = await fetch(`https://api.github.com/repos/${window.GITHUB_CONFIG.repo}/collaborators/${encodeURIComponent(uName)}`, {
          headers: { "Authorization": `Bearer ${window.GITHUB_CONFIG.token}`, "Accept": "application/vnd.github.v3+json" }
        });
        return r.status === 204 || r.status === 200;
      } catch (_e) { return false; }
    }
    return false;
  };

  const iniciar = async () => {
    try {
      if (!credencialesListas) throw new Error("Configura Supabase");
      const supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
      window.supabaseClient = supabase;

      const { data: { session } } = await supabase.auth.getSession();

      if (session && session.user) {
        const tieneAcceso = await verificarPermiso(session.user);
        if (!tieneAcceso) {
          await supabase.auth.signOut();
          redirigir("/paginas/login.html?error=no_access");
          return;
        }
      }

      if (esPaginaLogin && session) {
        const redir = new URLSearchParams(window.location.search).get("redir") || "/index.html";
        redirigir(redir);
        return;
      }

      if (!esPaginaLogin && !session) {
        redirigir("/paginas/login.html?redir=" + encodeURIComponent(window.location.href));
        return;
      }

      document.documentElement.style.visibility = "";
      document.documentElement.style.background = "";
      window.sesionActual = session;

      window.cerrarSesionUsuario = async () => {
        if (supabase) await supabase.auth.signOut();
        redirigir("/paginas/login.html");
      };
    } catch (e) {
      if (!esPaginaLogin) redirigir("/paginas/login.html");
      else {
        document.documentElement.style.visibility = "";
        document.documentElement.style.background = "";
      }
    }

  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar);
  else iniciar();
})();