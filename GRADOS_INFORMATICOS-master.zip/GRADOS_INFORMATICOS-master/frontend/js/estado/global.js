/* ESTADO GLOBAL Y CARGA (< 65 lineas) */

var DATA = window.DATA || {};
var CONFIG = window.CONFIG || {};
var grad = window.grad || '';
var POS = window.POS || 0;
var ITEMS = window.ITEMS || [];
var TAB_KEY = 'e';
var NAV_SOLO_SELECCIONADOS = true;
var BUSQUEDA_ARCHIVO = '';
var ITEMS_BUSQUEDA = [];
window.BUSQUEDA_ARCHIVO = BUSQUEDA_ARCHIVO; window.ITEMS_BUSQUEDA = ITEMS_BUSQUEDA;
window.DATA = DATA; window.CONFIG = CONFIG; window.grad = grad; window.POS = POS; window.ITEMS = ITEMS;

async function load() {
  const r = await fetch('/api/datos');
  const d = await r.json();
  DATA = d || {};
  CONFIG = d || {};

  const degrees = Object.keys(CONFIG);
  if (degrees.length === 0) return;

  const urlRama = new URLSearchParams(window.location.search).get('rama');
  const estaAbierto = localStorage.getItem('last_open') === '1';
  const savedGrado = localStorage.getItem('last_grado');

  if (urlRama && degrees.includes(urlRama)) {
    grad = urlRama;
  } else if (estaAbierto && savedGrado && degrees.includes(savedGrado)) {
    grad = savedGrado;
  } else {
    grad = '';
  }

  const sel = document.getElementById('selectRamaGithub');
  if (sel && grad) sel.value = grad;

  if (grad && CONFIG[grad]) {
    if (typeof renderTabs === 'function') renderTabs();
    buildAllItems();
    if (typeof render === 'function') render();
    if (typeof precargarPrimerosOriginales === 'function') setTimeout(precargarPrimerosOriginales, 400);

    const openParam = new URLSearchParams(window.location.search).get('pos');
    if (openParam !== null) {
      const p = parseInt(openParam, 10);
      if (p >= 0 && p < ITEMS.length) { POS = p; openOv(); }
    } else if (estaAbierto) {
      const savedArch = localStorage.getItem('last_archivo');
      let idx = -1;
      if (savedArch) idx = ITEMS.findIndex(item => item.archivo === savedArch);
      if (idx === -1) {
        const savedPos = parseInt(localStorage.getItem('last_pos') || '0', 10);
        if (savedPos >= 0 && savedPos < ITEMS.length) idx = savedPos;
      }
      if (idx >= 0 && idx < ITEMS.length) { POS = idx; openOv(); }
    } else {
      // Si no hay parámetro pos y no está abierto, ir al inicio (POS 0)
      POS = 0;
    }
  } else {
    const content = document.getElementById('content');
    const stats = document.getElementById('stats');
    if (stats) stats.innerHTML = '';
    if (content) {
      content.innerHTML = `
        <div style="grid-column:1/-1;text-align:center;padding:80px 20px;color:#94a3b8">
          <i class="fa-brands fa-github" style="font-size:52px;color:#a78bfa;margin-bottom:16px;display:block"></i>
          <h2 style="font-size:20px;color:#f1f5f9;margin-bottom:8px">Selecciona una rama</h2>
          <p style="font-size:14px;color:#94a3b8;max-width:460px;margin:0 auto">Elige una rama en el selector superior para cargar y revisar sus documentos.</p>
        </div>`;
    }
  }
}


function buildAllItems() {
  ITEMS = [];
  if (!DATA[grad]) return;
  (DATA[grad].entries || []).forEach((e, idx) => ITEMS.push({ ...e, type: 'e', idx }));
  (DATA[grad].no_cambian || []).forEach((n, idx) => ITEMS.push({ ...n, type: 'n', idx }));
}


function _normalizarBusquedaArchivo(v) {
  return String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

function obtenerItemsBusqueda() {
  if (!BUSQUEDA_ARCHIVO) return Array.isArray(ITEMS) ? ITEMS : [];
  return (Array.isArray(ITEMS) ? ITEMS : []).filter(it => {
    const nombre = _normalizarBusquedaArchivo(it?.archivo || '');
    return nombre.includes(BUSQUEDA_ARCHIVO);
  });
}

function filtrarArchivos(valor) {
  BUSQUEDA_ARCHIVO = _normalizarBusquedaArchivo(valor);
  window.BUSQUEDA_ARCHIVO = BUSQUEDA_ARCHIVO;
  ITEMS_BUSQUEDA = obtenerItemsBusqueda();
  window.ITEMS_BUSQUEDA = ITEMS_BUSQUEDA;
  const count = document.getElementById('fileSearchCount');
  const clear = document.getElementById('btnLimpiarBusqueda');
  if (count) count.textContent = BUSQUEDA_ARCHIVO ? `${ITEMS_BUSQUEDA.length} encontrado${ITEMS_BUSQUEDA.length === 1 ? '' : 's'}` : '';
  if (clear) clear.style.display = BUSQUEDA_ARCHIVO ? 'inline-flex' : 'none';
  if (typeof render === 'function' && grad && DATA[grad]) render();
  if (typeof precargarPrimerosOriginales === 'function') {
    try { precargarPrimerosOriginales(); } catch (_) {}
  }
}

function limpiarBusquedaArchivos() {
  const input = document.getElementById('inputBuscarArchivo');
  if (input) input.value = '';
  filtrarArchivos('');
}
