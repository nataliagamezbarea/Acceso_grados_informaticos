/* INICIALIZADOR Y PUNTO DE ENTRADA PRINCIPAL */

function inicializarRamasGithub() {
  const sel = document.getElementById("selectRamaGithub");
  if (!sel) return;
  if (window.RamaActual && typeof window.RamaActual.poblarSelector === "function") {
    await window.RamaActual.poblarSelector(sel);
  }

    } else if (estaAbierto && ramaGuardada && sel.querySelector(`option[value="${ramaGuardada}"]`)) {
      sel.value = ramaGuardada;
    } else {
      sel.value = "";
    }
  }
}



function cambiarRamaGithub(rama) {
  if (window.RamaActual) window.RamaActual.guardar(rama);
  if (!rama) {
    grad = '';
    localStorage.removeItem('last_grado');
    localStorage.removeItem('last_open');
    localStorage.removeItem('last_archivo');
    if (typeof load === 'function') load();
    return;
  }
  if (typeof CONFIG !== 'undefined' && CONFIG[rama]) {
    grad = rama;
    POS = 0;
    localStorage.setItem('last_grado', grad);
    localStorage.setItem('last_pos', '0');
    if (typeof renderTabs === 'function') renderTabs();
    if (typeof buildAllItems === 'function') buildAllItems();
    if (typeof render === 'function') render();
  } else {
    window.location.search = `?rama=${encodeURIComponent(rama)}`;
  }
}


async function sincronizarGitHub() {
  if (typeof showBlocker === 'function') showBlocker('Sincronizando ramas y archivos con GitHub...');
  try {
    const res = await fetch('/api/github_pull', { method: 'POST' });
    const data = await res.json();
    if (typeof hideBlocker === 'function') hideBlocker();
    if (typeof showCustomAlert === 'function') {
      await showCustomAlert(
        'Sincronización GitHub',
        data.mensaje || 'Ramas y archivos sincronizados correctamente.',
        '<i class="fa-brands fa-github"></i>',
        '#2563eb'
      );
    }
    window.location.reload();
  } catch (e) {
    if (typeof hideBlocker === 'function') hideBlocker();
    console.error('Error sincronizando con GitHub:', e);
  }
}

async function cerrarSesionUsuario() {
  if (window.supabaseClient) {
    await window.supabaseClient.auth.signOut();
  }
  window.location.href = '/paginas/login.html';
}

document.addEventListener('DOMContentLoaded', async () => {
  if (typeof initKeyboardNavigation === 'function') initKeyboardNavigation();
  await inicializarRamasGithub();
  load();
  if (typeof initCacheToggle === 'function') initCacheToggle();
});

