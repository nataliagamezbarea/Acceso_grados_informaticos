// ============================================================
// CONFIG VÍA API (Vercel)
// Carga la configuración (Supabase + GitHub) desde /api/config
// usando los secretos guardados como variables de entorno.
// Reemplaza a supabase-config.js y github-config.js (no subidos).
// ============================================================
(function () {
  var config = {};

  try {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/api/config", false);
    xhr.setRequestHeader("Accept", "application/json");
    xhr.send(null);
    if (xhr.status >= 200 && xhr.status < 300) {
      config = JSON.parse(xhr.responseText) || {};
    }
  } catch (e) { /* se mantiene vacío */ }

  if (!window.SUPABASE_URL) window.SUPABASE_URL = config.SUPABASE_URL || "";
  if (!window.SUPABASE_ANON_KEY) window.SUPABASE_ANON_KEY = config.SUPABASE_ANON_KEY || "";

  if (!window.GITHUB_CONFIG) {
    window.GITHUB_CONFIG = {
      repo: config.GITHUB_REPO || "",
      token: config.GITHUB_TOKEN || "",
    };
  } else {
    if (!window.GITHUB_CONFIG.repo) window.GITHUB_CONFIG.repo = config.GITHUB_REPO || "";
    if (!window.GITHUB_CONFIG.token) window.GITHUB_CONFIG.token = config.GITHUB_TOKEN || "";
  }
})();
