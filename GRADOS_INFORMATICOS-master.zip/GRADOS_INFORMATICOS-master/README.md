# Repositorio de Materiales de Estudios de Informática

Este repositorio centraliza todos los archivos, apuntes, ejercicios, proyectos y recursos generados durante mis estudios de informática. Está diseñado para organizar y facilitar el acceso a todo el material académico, desde cursos universitarios hasta módulos específicos.

## Acceso y Navegación

Para acceder a los materiales y la estructura completa de los estudios, puedes visitar el siguiente portal:

[Portal de Acceso a Grados Informáticos](https://nataliagamezbarea.github.io/Acceso_grados_informaticos/modulos/login.html)