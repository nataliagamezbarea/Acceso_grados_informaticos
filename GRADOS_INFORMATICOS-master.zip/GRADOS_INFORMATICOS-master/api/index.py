import os
import sys
from http.server import BaseHTTPRequestHandler
import urllib.parse

# Añadir raíz al sys.path
DIRECTORIO_RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if DIRECTORIO_RAIZ not in sys.path:
    sys.path.insert(0, DIRECTORIO_RAIZ)

from backend.servidor.manejador_peticiones import ManejadorPeticiones

class handler(ManejadorPeticiones):
    pass
