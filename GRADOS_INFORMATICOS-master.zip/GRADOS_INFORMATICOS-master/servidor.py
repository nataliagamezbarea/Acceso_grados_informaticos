#!/usr/bin/env python3
"""
Punto de entrada principal para el servidor del Visor de Grados Informáticos.
Toda la lógica de rutas y controladores está modularizada en 'backend/servidor/'.
"""
import os
import sys

# Asegurar que el directorio base está en sys.path
DIR_BASE = os.path.dirname(os.path.abspath(__file__))
if DIR_BASE not in sys.path:
    sys.path.insert(0, DIR_BASE)

from backend.servidor import iniciar_servidor

if __name__ == "__main__":
    iniciar_servidor()