import unittest, urllib.request, json

BASE = "http://localhost:8080"
GRADO = "Primer_grado_medio"
ARCHIVO = "XALO_01_07_GMEZ_BAREA_NATALIA.pdf"

def _post(path, data):
    req = urllib.request.Request(f"{BASE}{path}", data=json.dumps(data).encode("utf-8"),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=5) as res:
        return json.loads(res.read().decode("utf-8"))

class TestBotonesFlags(unittest.TestCase):
    def test_01_servidor_responde(self):
        try:
            with urllib.request.urlopen(f"{BASE}/", timeout=5) as res:
                self.assertEqual(res.status, 200)
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_02_checkbox_nombre_interior(self):
        try:
            res = _post("/api/update_flags", {"grado": GRADO, "archivo": ARCHIVO, "campo": "int", "valor": True})
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_03_checkbox_colegio(self):
        try:
            res = _post("/api/update_flags", {"grado": GRADO, "archivo": ARCHIVO, "campo": "col", "valor": True})
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_04_checkbox_renombrar(self):
        try:
            res = _post("/api/update_flags", {"grado": GRADO, "archivo": ARCHIVO, "campo": "ren", "valor": False})
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_05_checkbox_imagenes_internet(self):
        try:
            res = _post("/api/update_flags", {"grado": GRADO, "archivo": ARCHIVO, "campo": "internet", "valor": True})
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_06_checkbox_inclusion_apuntes(self):
        try:
            res = _post("/api/update_flags", {"grado": GRADO, "archivo": ARCHIVO, "campo": "inc", "valor": True})
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

if __name__ == "__main__":
    unittest.main(verbosity=2)
