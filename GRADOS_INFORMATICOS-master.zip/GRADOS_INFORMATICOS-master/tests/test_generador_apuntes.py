import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend import generador_apuntes as gen

RUTA_ESTILO = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "bibliotecas_latex", "estilo.tex"
)


class TransformarLatexTest(unittest.TestCase):
    def test_usa_estilo_compatible(self):
        contenido = "TITULO: Texto real\nSECCION: Tema\n- item del txt\n"
        latex = gen.transformar_txt_a_latex(contenido, "Primer_grado_medio")
        self.assertIn("estilo.tex", latex)
        self.assertIn("\\paletaOceano", latex)
        self.assertNotIn("GUÍA DE ESTRUCTURA", latex)

    def test_secciones_con_sectionheader_fijo(self):
        contenido = "TITULO: Texto real\nSECCION: Tema\nSUBSECCION: Detalle\n"
        latex = gen.transformar_txt_a_latex(contenido, "Primer_grado_medio")
        self.assertIn("\\sectionheader{2.6cm}{Tema}", latex)
        self.assertIn("\\sectionheader{1.8cm}{Detalle}", latex)
        self.assertNotIn("\\tituloG", latex)

    def test_determinista(self):
        contenido = "TITULO: Texto real\nSECCION: Tema\n"
        l1 = gen.transformar_txt_a_latex(contenido, "Primer_grado_medio")
        l2 = gen.transformar_txt_a_latex(contenido, "Primer_grado_medio")
        self.assertEqual(l1, l2)

    def test_un_solo_titulo_grande(self):
        contenido = (
            "TITULO: Unico\nSECCION: A\nSECCION: B\n"
            "CUESTION: ¿Uno?\nDESARROLLO: ok\n"
            "| a | b |\n| - | - |\n| 1 | 2 |\n"
            "- x\n```\ncode\n```\n"
        )
        latex = gen.transformar_txt_a_latex(contenido, "Primer_grado_medio")
        lineas_titulo = [l for l in latex.splitlines() if "\\titulo" in l]
        self.assertEqual(len(lineas_titulo), 1)


class EstiloRealTest(unittest.TestCase):
    def test_componentes_reales_presentes(self):
        with open(RUTA_ESTILO, encoding="utf-8") as f:
            c = f.read()
        for fragmento in [
            "\\newcommand{\\sectionheader}[3][primary]",
            "\\newcommand{\\tituloA}",
            "\\newcommand{\\tituloQ}",
            "newenvironment{tablaminimal}",
            "\\newcommand{\\paletaOceano}",
            "barrule",
        ]:
            self.assertIn(fragmento, c)

    def test_tituloG_barra_lateral_izquierda(self):
        with open(RUTA_ESTILO, encoding="utf-8") as f:
            c = f.read()
        self.assertIn("rectangle (0.11,0.92)", c)


if __name__ == "__main__":
    unittest.main()
