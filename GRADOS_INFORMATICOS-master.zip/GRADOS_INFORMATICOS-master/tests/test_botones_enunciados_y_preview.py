import unittest, urllib.request, json

BASE = "http://localhost:8080"
GRADO = "Primer_grado_medio"
ARCHIVO = "XALO_01_07_GMEZ_BAREA_NATALIA.pdf"

def _post(path, data):
    req = urllib.request.Request(f"{BASE}{path}", data=json.dumps(data).encode("utf-8"),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=5) as res:
        return json.loads(res.read().decode("utf-8"))

class TestBotonesEnunciadosYPreview(unittest.TestCase):
    def test_01_boton_guardar_enunciado(self):
        try:
            res = _post("/api/guardar_enunciado", {
                "grado": GRADO, "archivo": ARCHIVO,
                "start": "1º PASO", "end": "VIRTUAL",
                "new": "1º PASO: DARLE A NUEVA MÁQUINA VIRTUAL.",
                "page": 4
            })
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_02_boton_preview_original_pdf(self):
        try:
            url = f"{BASE}/api/preview/{GRADO}?archivo={ARCHIVO}&mode=old"
            with urllib.request.urlopen(url, timeout=10) as res:
                self.assertEqual(res.status, 200)
                self.assertEqual(res.headers.get("Content-Type"), "application/pdf")
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_03_boton_preview_nuevo_pdf(self):
        try:
            url = f"{BASE}/api/preview/{GRADO}?archivo={ARCHIVO}&mode=new"
            with urllib.request.urlopen(url, timeout=15) as res:
                self.assertEqual(res.status, 200)
                self.assertEqual(res.headers.get("Content-Type"), "application/pdf")
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_04_boton_eliminar_enunciado(self):
        try:
            res = _post("/api/eliminar_enunciado", {
                "grado": GRADO, "archivo": ARCHIVO,
                "index": 0
            })
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

if __name__ == "__main__":
    unittest.main(verbosity=2)
