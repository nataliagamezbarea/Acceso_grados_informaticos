import unittest, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.gestor_datos.github_sync import (
    _obtener_config_github, descargar_json_de_github, subir_json_a_github
)

class TestGitHubSync(unittest.TestCase):
    def test_01_config_github_presente(self):
        token, repo = _obtener_config_github()
        self.assertTrue(bool(token), "Token de GitHub no configurado")
        self.assertTrue(bool(repo), "Repositorio de GitHub no configurado")

    def test_02_subir_y_descargar_json_github(self):
        token, repo = _obtener_config_github()
        if not token or not repo:
            self.skipTest("Credenciales de GitHub no disponibles")
        datos_prueba = {"test_sync": True, "servicio": "Visor-Grados"}
        ok = subir_json_a_github(datos_prueba, "almacen/datos/test_sync.json", rama="master", sincrono=True)
        if not ok:
            self.skipTest("No se pudo conectar a GitHub (red o permisos)")
        descargado = descargar_json_de_github("almacen/datos/test_sync.json", rama="master")
        self.assertIsInstance(descargado, dict)
        self.assertTrue(descargado.get("test_sync"))

if __name__ == "__main__":
    unittest.main(verbosity=2)
