import unittest, urllib.request, json

BASE = "http://localhost:8080"
GRADO = "Primer_grado_medio"
ARCHIVO = "XALO_01_07_GMEZ_BAREA_NATALIA.pdf"

def _post(path, data):
    req = urllib.request.Request(f"{BASE}{path}", data=json.dumps(data).encode("utf-8"),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as res:
        return json.loads(res.read().decode("utf-8"))

class TestBotonesRecuadros(unittest.TestCase):
    def test_01_boton_anadir_recuadro_nombre(self):
        try:
            res = _post("/api/recuadro", {
                "grado": GRADO, "archivo": ARCHIVO, "tipo": "nombre",
                "page_num": 0, "left": 15.0, "top": 20.0, "width": 70.0, "height": 8.0,
                "text": "NATALIA GÁMEZ BAREA"
            })
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_02_boton_anadir_recuadro_colegio(self):
        try:
            res = _post("/api/recuadro", {
                "grado": GRADO, "archivo": ARCHIVO, "tipo": "colegio",
                "page_num": 0, "left": 10.0, "top": 70.0, "width": 80.0, "height": 10.0,
                "text": "SANT JOSEP OBRER"
            })
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_03_boton_anadir_inicio_reflujo(self):
        try:
            res = _post("/api/recuadro", {
                "grado": GRADO, "archivo": ARCHIVO, "tipo": "reflujo",
                "page_num": 4, "left": 5.0, "top": 15.0, "width": 90.0, "height": 6.0
            })
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_04_boton_eliminar_inicio_reflujo(self):
        try:
            res = _post("/api/recuadro", {
                "grado": GRADO, "archivo": ARCHIVO, "tipo": "reflujo",
                "page_num": 4, "eliminar": True
            })
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_05_doc_info_incluye_todos_los_hotspots(self):
        try:
            url = f"{BASE}/api/doc_info/{GRADO}?archivo={ARCHIVO}&mode=old"
            with urllib.request.urlopen(url, timeout=5) as res:
                data = json.loads(res.read().decode("utf-8"))
                pages = data.get("pages", [])
                self.assertGreater(len(pages), 0)
                p0 = pages[0]
                self.assertIn("statement_hotspots", p0)
                self.assertIn("name_hotspots", p0)
                self.assertIn("school_hotspots", p0)
                self.assertIn("reflow_hotspots", p0)
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_06_boton_eliminar_de_inicio_total(self):
        try:
            res = _post("/api/reset_item", {"grado": GRADO, "archivo": ARCHIVO})
            self.assertTrue(res.get("ok"))
        except Exception:
            self.skipTest("Servidor no accesible")

if __name__ == "__main__":
    unittest.main(verbosity=2)
