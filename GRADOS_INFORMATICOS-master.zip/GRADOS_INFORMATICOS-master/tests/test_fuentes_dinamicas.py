"""Test de descarga dinámica de fuentes — sin tablas hardcodeadas."""
import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.procesador_pdf.reescritura.fuentes_descarga.find_in_env import (
    _substrings_dinamicos, find_in_env,
)
from backend.procesador_pdf.reescritura.fuentes_descarga.parse_font_family_and_style import (
    parse_font_family_and_style,
)


class TestSubstringsDinamicos(unittest.TestCase):
    def test_avenir(self):
        v = _substrings_dinamicos('AvenirNextLTPro')
        self.assertIn('avenirnextltpro', v)
        self.assertIn('avenir', v)
        self.assertTrue(len(v) >= 3)

    def test_mali(self):
        v = _substrings_dinamicos('Mali')
        self.assertEqual(v, ['mali'])

    def test_open_sans(self):
        v = _substrings_dinamicos('OpenSans')
        self.assertIn('opensans', v)
        self.assertIn('open', v)

    def test_empty(self):
        self.assertEqual(_substrings_dinamicos(''), [])


class TestParseFontFamilyAndStyle(unittest.TestCase):
    def test_light(self):
        fam, sty = parse_font_family_and_style('AvenirNextLTPro-Light')
        self.assertEqual(sty.lower(), 'light')

    def test_bold(self):
        fam, sty = parse_font_family_and_style('AvenirNextLTPro-Bold')
        self.assertIn('bold', sty.lower())

    def test_regular(self):
        fam, sty = parse_font_family_and_style('Mali-Regular')
        self.assertEqual(sty.lower(), 'regular')

    def test_no_style(self):
        fam, sty = parse_font_family_and_style('Helvetica')
        self.assertEqual(sty, 'Regular')


class TestFindInEnv(unittest.TestCase):
    def test_avenir_light_if_exists(self):
        """Si avenirnextltpro_light.ttf existe, find_in_env lo encuentra."""
        r = find_in_env('AvenirNextLTPro', 'Light')
        if r:
            self.assertIn('light', r.lower())

    def test_no_mezcla_bold_light(self):
        """Nunca devuelve Bold si pedimos Light."""
        r = find_in_env('AvenirNextLTPro', 'Light')
        if r:
            self.assertNotIn('bold', r.lower())


class TestResolucionCompleta(unittest.TestCase):
    def test_resolver_avenir_light(self):
        from backend.procesador_pdf.reescritura.fuentes_descarga.resolver_fuente_real import (
            resolver_fuente_real,
        )
        ruta = resolver_fuente_real('AvenirNextLTPro-Light')
        self.assertIsNotNone(ruta, "AvenirNextLTPro-Light debería resolverse")
        self.assertTrue(os.path.exists(ruta))

    def test_resolver_avenir_bold(self):
        from backend.procesador_pdf.reescritura.fuentes_descarga.resolver_fuente_real import (
            resolver_fuente_real,
        )
        ruta = resolver_fuente_real('AvenirNextLTPro-Bold')
        self.assertIsNotNone(ruta, "AvenirNextLTPro-Bold debería resolverse")
        self.assertTrue(os.path.exists(ruta))


if __name__ == '__main__':
    unittest.main(verbosity=2)
