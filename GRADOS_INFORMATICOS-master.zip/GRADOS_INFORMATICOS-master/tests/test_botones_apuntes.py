"""Tests para los botones de apuntes y flags ampliados (< 85 líneas)."""
import unittest, urllib.request, json

BASE = "http://localhost:8080"
GRADO = "Primer_grado_medio"
ARCHIVO = "XALO_01_07_GMEZ_BAREA_NATALIA.pdf"

def _post(path, data):
    req = urllib.request.Request(f"{BASE}{path}", data=json.dumps(data).encode("utf-8"),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as res:
        return json.loads(res.read().decode("utf-8"))

class TestBotonesApuntes(unittest.TestCase):
    def _skip_if_down(self):
        try:
            urllib.request.urlopen(f"{BASE}/", timeout=5)
        except Exception:
            self.skipTest("Servidor no accesible")

    def test_01_update_flags_apunte_true(self):
        self._skip_if_down()
        res = _post("/api/update_flags", {"grado": GRADO, "archivo": ARCHIVO, "campo": "apunte", "valor": True})
        self.assertTrue(res.get("ok"), f"Esperado ok, got: {res}")

    def test_02_update_flags_apunte_false(self):
        self._skip_if_down()
        res = _post("/api/update_flags", {"grado": GRADO, "archivo": ARCHIVO, "campo": "apunte", "valor": False})
        self.assertTrue(res.get("ok"), f"Esperado ok, got: {res}")

    def test_03_update_flags_nombre_apunte(self):
        self._skip_if_down()
        res = _post("/api/update_flags", {"grado": GRADO, "archivo": ARCHIVO, "campo": "nombre_apunte", "valor": "APUNTE_TEST"})
        self.assertTrue(res.get("ok"), f"Esperado ok, got: {res}")

    def test_04_update_flags_campo_invalido_da_400(self):
        self._skip_if_down()
        try:
            _post("/api/update_flags", {"grado": GRADO, "archivo": ARCHIVO, "campo": "INVALIDO", "valor": True})
            self.fail("Debería haber lanzado error 400")
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code, 400)

    def test_05_update_flags_sin_archivo_da_400(self):
        self._skip_if_down()
        try:
            _post("/api/update_flags", {"grado": GRADO, "campo": "apunte", "valor": True})
            self.fail("Debería haber lanzado error 400")
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code, 400)

    def test_06_update_flags_todos_los_campos_validos(self):
        self._skip_if_down()
        campos = ["int", "col", "ren", "internet", "inc", "apunte"]
        for campo in campos:
            res = _post("/api/update_flags", {"grado": GRADO, "archivo": ARCHIVO, "campo": campo, "valor": False})
            self.assertTrue(res.get("ok"), f"Campo {campo} devolvió: {res}")

    def test_07_compilar_apunte_endpoint_existe(self):
        self._skip_if_down()
        try:
            _post("/api/compilar_apunte", {"grado": GRADO, "archivo": ARCHIVO, "nombre_apunte": "TEST"})
        except urllib.error.HTTPError as e:
            # 404=no existe, 400=params, 500=LaTeX fallo. Solo 404 es inaceptable.
            self.assertNotEqual(e.code, 404, "El endpoint /api/compilar_apunte no existe (404)")
        except Exception:
            pass  # Error de red aceptable en test


if __name__ == "__main__":
    unittest.main(verbosity=2)
